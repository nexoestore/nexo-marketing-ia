rootProject.name = "NexoMarketingIA"
include(":app")
