# Nexo Marketing IA
Proyecto base.
