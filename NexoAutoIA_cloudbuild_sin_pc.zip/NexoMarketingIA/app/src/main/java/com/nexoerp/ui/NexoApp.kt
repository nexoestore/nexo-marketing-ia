package com.nexoerp.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.nexoerp.data.*

@Composable fun NexoApp(){ val store= remember{ NexoStore(LocalContext.current) }; val user by store.currentUser; if(user==null) AuthScreen(store) else MainContent(store) }

@Composable fun AuthScreen(store:NexoStore){ var reg by remember{ mutableStateOf(false) }; if(reg) RegisterScreen(store){reg=false} else LoginScreen(store){reg=true} }

@Composable fun LoginScreen(store:NexoStore,onRegister:()->Unit){
    var user by remember{ mutableStateOf("admin") }; var pass by remember{ mutableStateOf("1234") }; val err by store.loginError
    Surface(Modifier.fillMaxSize()){
        Column(Modifier.fillMaxSize().padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.Center){
            Text("Nexo ERP",style=MaterialTheme.typography.headlineLarge,fontWeight=FontWeight.Bold); Text("Administra. Vende. Crece."); Spacer(Modifier.height(24.dp))
            OutlinedTextField(user,{user=it},label={Text("Usuario")},modifier=Modifier.fillMaxWidth())
            OutlinedTextField(pass,{pass=it},label={Text("Clave")},visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth())
            if(err.isNotBlank()) Text(err,color=MaterialTheme.colorScheme.error)
            Spacer(Modifier.height(12.dp)); Button({store.login(user,pass)},Modifier.fillMaxWidth()){Text("Entrar")}
            TextButton(onRegister){Text("Crear usuario nuevo")}
            Text("Admin inicial: admin / 1234")
        }
    }
}

@Composable fun RegisterScreen(store:NexoStore,onBack:()->Unit){
    var u by remember{ mutableStateOf("") }; var n by remember{ mutableStateOf("") }; var p by remember{ mutableStateOf("") }; var c by remember{ mutableStateOf("") }; var admin by remember{ mutableStateOf(false) }; val msg by store.appMessage
    LazyColumn(Modifier.fillMaxSize().padding(24.dp),horizontalAlignment=Alignment.CenterHorizontally){
        item{
            Spacer(Modifier.height(40.dp)); Text("Crear usuario",style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold)
            OutlinedTextField(u,{u=it},label={Text("Usuario")},modifier=Modifier.fillMaxWidth())
            OutlinedTextField(n,{n=it},label={Text("Nombre")},modifier=Modifier.fillMaxWidth())
            OutlinedTextField(p,{p=it},label={Text("Clave")},visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth())
            OutlinedTextField(c,{c=it},label={Text("Confirmar clave")},visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth())
            Row(verticalAlignment=Alignment.CenterVertically){Checkbox(admin,{admin=it});Text("Administrador")}
            if(msg.isNotBlank()) Text(msg)
            Button({ if(store.registerUser(u,n,p,c,if(admin)UserRole.ADMIN else UserRole.WORKER)) onBack() },Modifier.fillMaxWidth()){Text("Crear usuario")}
            TextButton(onBack){Text("Volver al login")}
        }
    }
}

@Composable fun MainContent(store:NexoStore){
    val tab by store.selectedTab; val current by store.currentUser; val msg by store.appMessage
    Scaffold(
        topBar={ Surface(shadowElevation=2.dp){ Column(Modifier.fillMaxWidth().padding(12.dp)){ Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){ Column{Text("Nexo ERP 1.3",fontWeight=FontWeight.Bold);Text("${current?.displayName} • ${current?.role}")}; TextButton({store.logout()}){Text("Salir")} }; if(msg.isNotBlank()) AssistChip(onClick={},label={Text(msg)}) } } },
        bottomBar={ NavigationBar{
            NavigationBarItem(tab==AppTab.DASHBOARD,{store.selectedTab.value=AppTab.DASHBOARD},{Text("🏠")},label={Text("Inicio")})
            NavigationBarItem(tab==AppTab.INVENTORY,{store.selectedTab.value=AppTab.INVENTORY},{Text("📦")},label={Text("Inventario")})
            if(store.isAdmin()) NavigationBarItem(tab==AppTab.PURCHASES,{store.selectedTab.value=AppTab.PURCHASES},{Text("🧾")},label={Text("Compras")})
            if(store.isAdmin()) NavigationBarItem(tab==AppTab.SUPPLIERS,{store.selectedTab.value=AppTab.SUPPLIERS},{Text("🏭")},label={Text("Provee")})
            NavigationBarItem(tab==AppTab.SALES,{store.selectedTab.value=AppTab.SALES},{Text("💰")},label={Text("Ventas")})
            NavigationBarItem(tab==AppTab.AI,{store.selectedTab.value=AppTab.AI},{Text("🤖")},label={Text("IA")})
            NavigationBarItem(tab==AppTab.REPORTS,{store.selectedTab.value=AppTab.REPORTS},{Text("📊")},label={Text("Reportes")})
            if(store.isAdmin()) NavigationBarItem(tab==AppTab.USERS,{store.selectedTab.value=AppTab.USERS},{Text("👥")},label={Text("Usuarios")})
            NavigationBarItem(tab==AppTab.SETTINGS,{store.selectedTab.value=AppTab.SETTINGS},{Text("⚙️")},label={Text("Config")})
        }}
    ){p-> Box(Modifier.padding(p)){ when(tab){ AppTab.DASHBOARD->DashboardScreen(store); AppTab.INVENTORY->InventoryScreen(store); AppTab.PURCHASES->PurchasesScreen(store); AppTab.SUPPLIERS->SuppliersScreen(store); AppTab.SALES->SalesScreen(store); AppTab.AI->AiScreen(store); AppTab.REPORTS->ReportsScreen(store); AppTab.USERS->UsersScreen(store); AppTab.SETTINGS->SettingsScreen(store) } } }
}

@Composable fun Header(t:String,s:String){ Column(Modifier.fillMaxWidth().padding(16.dp)){ Text(t,style=MaterialTheme.typography.headlineMedium,fontWeight=FontWeight.Bold); Text(s) } }
@Composable fun MetricCard(t:String,v:String,e:String){ Card(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=6.dp)){ Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Text(e,style=MaterialTheme.typography.headlineMedium);Spacer(Modifier.width(12.dp));Column{Text(t,fontWeight=FontWeight.SemiBold);Text(v,style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold)}} } }
fun cop(v:Double)="$"+"%,.0f".format(v).replace(",",".")+" COP"

@Composable fun DashboardScreen(store:NexoStore){
    LazyColumn{
        item{Header("Dashboard","Resumen general de tu negocio")}
        item{MetricCard("Ventas registradas",cop(store.totalSales()),"💰")}
        item{MetricCard("Ganancia registrada",cop(store.totalProfit()),"📈")}
        item{MetricCard("Capital comprado",cop(store.purchasedCapital()),"🧾")}
        item{MetricCard("Capital en inventario",cop(store.investedCapital()),"🏦")}
        item{MetricCard("Capital recuperado",cop(store.recoveredCapital()),"✅")}
        item{MetricCard("Stock disponible","${store.totalStock()} prendas","📦")}
        val agotados=store.soldOutProducts(); if(agotados.isNotEmpty()){ item{Text("🚨 Productos agotados",Modifier.padding(16.dp),fontWeight=FontWeight.Bold)}; items(agotados){Card(Modifier.fillMaxWidth().padding(16.dp)){Text(it.name,Modifier.padding(16.dp))}} }
        val low=store.lowStockProducts(); if(low.isNotEmpty()){ item{Text("⚠️ Últimas unidades",Modifier.padding(16.dp),fontWeight=FontWeight.Bold)}; items(low){Card(Modifier.fillMaxWidth().padding(16.dp)){Text("${it.name}: ${it.stock}",Modifier.padding(16.dp))}} }
    }
}

@Composable fun InventoryScreen(store:NexoStore){
    var q by remember{ mutableStateOf("") }; var form by remember{ mutableStateOf(false) }
    LazyColumn{
        item{Header("Inventario","Búsqueda rápida, fotos y códigos")}
        item{OutlinedTextField(q,{q=it},label={Text("Buscar nombre, categoría o código")},modifier=Modifier.fillMaxWidth().padding(16.dp))}
        if(store.isAdmin()) item{Button({form=!form},Modifier.padding(16.dp).fillMaxWidth()){Text(if(form)"Cerrar" else "Agregar producto manual")}}
        if(form&&store.isAdmin()) item{AddProductForm(store)}
        items(store.filteredProducts(q)){ProductCard(it,store)}
    }
}

@Composable fun AddProductForm(store:NexoStore){
    var name by remember{ mutableStateOf("") }; var cat by remember{ mutableStateOf("Pijamas") }; var cost by remember{ mutableStateOf("") }; var price by remember{ mutableStateOf("") }; var stock by remember{ mutableStateOf("") }; var code by remember{ mutableStateOf("") }; var photo by remember{ mutableStateOf("") }
    Card(Modifier.fillMaxWidth().padding(16.dp)){Column(Modifier.padding(16.dp)){
        Text("Nuevo producto",fontWeight=FontWeight.Bold)
        OutlinedTextField(name,{name=it},label={Text("Producto")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(cat,{cat=it},label={Text("Categoría")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(cost,{cost=it.filter{c->c.isDigit()||c=='.'}},label={Text("Costo real")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(price,{price=it.filter{c->c.isDigit()||c=='.'}},label={Text("Precio venta")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(stock,{stock=it.filter{c->c.isDigit()}},label={Text("Stock")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(code,{code=it},label={Text("Código de barras")},modifier=Modifier.fillMaxWidth())
        OutlinedButton({code="BAR"+System.currentTimeMillis().toString().takeLast(6)}){Text("Escanear código demo")}
        OutlinedTextField(photo,{photo=it},label={Text("Foto / referencia imagen")},modifier=Modifier.fillMaxWidth())
        Button({ if(store.addProduct(name,cat,cost.toDoubleOrNull()?:-1.0,price.toDoubleOrNull()?:0.0,stock.toIntOrNull()?:-1,code,photo)){name="";cost="";price="";stock="";code="";photo=""} },Modifier.fillMaxWidth()){Text("Guardar producto")}
    }}
}

@Composable fun ProductCard(p:Product,store:NexoStore){
    val admin=store.isAdmin(); val label=when{p.stock<=0->"Agotado";p.stock<=p.minStock->"Última unidad";p.stock<=3->"Stock bajo";else->"Disponible"}
    Card(Modifier.fillMaxWidth().padding(horizontal=16.dp,vertical=6.dp)){Column(Modifier.padding(16.dp)){
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text(p.name,fontWeight=FontWeight.Bold);AssistChip(onClick={},label={Text(label)})}
        Text(p.category); Text("Precio venta: ${cop(p.salePrice)}"); Text("Stock: ${p.stock}")
        if(p.barcode.isNotBlank())Text("Código: ${p.barcode}")
        if(p.photoUri.isNotBlank())Text("Foto/ref: ${p.photoUri}")
        if(admin){ Text("Costo real: ${cop(p.realCost)}"); Text("Margen: ${"%.1f".format(p.marginPercent)}%"); Text("Ganancia tú: ${cop(p.profitOwner)}"); Text("Ganancia trabajador: ${cop(p.profitWorker)}"); Row{OutlinedButton({store.adjustStock(p,1)}){Text("+1")};Spacer(Modifier.width(8.dp));OutlinedButton({store.adjustStock(p,-1)}){Text("-1")};Spacer(Modifier.width(8.dp));OutlinedButton({store.deleteProduct(p)}){Text("Eliminar")}} }
    }}
}

@Composable fun PurchasesScreen(store:NexoStore){
    val draft= remember{ mutableStateListOf<DraftItem>() }
    var supplier by remember{ mutableStateOf("") }; var invoice by remember{ mutableStateOf("") }; var shipping by remember{ mutableStateOf("") }
    var product by remember{ mutableStateOf("") }; var category by remember{ mutableStateOf("Pijamas") }; var qty by remember{ mutableStateOf("") }; var cost by remember{ mutableStateOf("") }; var price by remember{ mutableStateOf("") }; var code by remember{ mutableStateOf("") }; var photo by remember{ mutableStateOf("") }
    LazyColumn{
        item{Header("Compras","Factura completa con varios productos")}
        item{Card(Modifier.fillMaxWidth().padding(16.dp)){Column(Modifier.padding(16.dp)){
            Text("Encabezado compra",fontWeight=FontWeight.Bold)
            OutlinedTextField(supplier,{supplier=it},label={Text("Proveedor")},modifier=Modifier.fillMaxWidth())
            OutlinedTextField(invoice,{invoice=it},label={Text("Factura / nota")},modifier=Modifier.fillMaxWidth())
            OutlinedTextField(shipping,{shipping=it.filter{c->c.isDigit()||c=='.'}},label={Text("Envío total")},modifier=Modifier.fillMaxWidth())
            Divider(Modifier.padding(vertical=8.dp))
            Text("Agregar producto a la compra",fontWeight=FontWeight.Bold)
            OutlinedTextField(product,{product=it},label={Text("Producto")},modifier=Modifier.fillMaxWidth())
            OutlinedTextField(category,{category=it},label={Text("Categoría")},modifier=Modifier.fillMaxWidth())
            OutlinedTextField(qty,{qty=it.filter{c->c.isDigit()}},label={Text("Cantidad")},modifier=Modifier.fillMaxWidth())
            OutlinedTextField(cost,{cost=it.filter{c->c.isDigit()||c=='.'}},label={Text("Costo unitario proveedor")},modifier=Modifier.fillMaxWidth())
            OutlinedTextField(price,{price=it.filter{c->c.isDigit()||c=='.'}},label={Text("Precio de venta")},modifier=Modifier.fillMaxWidth())
            OutlinedTextField(code,{code=it},label={Text("Código de barras")},modifier=Modifier.fillMaxWidth())
            OutlinedButton({code="BAR"+System.currentTimeMillis().toString().takeLast(6)}){Text("Escanear código demo")}
            OutlinedTextField(photo,{photo=it},label={Text("Foto / referencia imagen")},modifier=Modifier.fillMaxWidth())
            Button({ val q=qty.toIntOrNull()?:0; val c=cost.toDoubleOrNull()?:0.0; val p=price.toDoubleOrNull()?:0.0; if(product.isNotBlank()&&q>0&&c>0&&p>0){draft.add(DraftItem(product,category,q,c,p,code,photo));product="";qty="";cost="";price="";code="";photo=""} },Modifier.fillMaxWidth()){Text("Agregar a factura")}
            Button({ if(store.savePurchaseBatch(supplier,invoice,shipping.toDoubleOrNull()?:0.0,draft)){draft.clear();supplier="";invoice="";shipping=""} },Modifier.fillMaxWidth()){Text("Guardar compra completa")}
        }}}
        item{Text("Productos pendientes en factura",Modifier.padding(16.dp),fontWeight=FontWeight.Bold)}
        items(draft){d->Card(Modifier.fillMaxWidth().padding(16.dp)){Text("${d.productName} x${d.quantity} - Costo ${cop(d.unitCost)} - Venta ${cop(d.salePrice)}",Modifier.padding(16.dp))}}
        item{Text("Historial de compras",Modifier.padding(16.dp),fontWeight=FontWeight.Bold)}
        items(store.purchases.reversed()){line->Card(Modifier.fillMaxWidth().padding(16.dp)){Column(Modifier.padding(16.dp)){Text("#${line.batchId} ${line.productName}",fontWeight=FontWeight.Bold);Text("Proveedor: ${line.supplier}");Text("Factura: ${line.invoice}");Text("Cantidad: ${line.quantity}");Text("Costo real unitario: ${cop(line.realUnitCost)}");Text("Total: ${cop(line.total)}");Row{OutlinedButton({store.editPurchaseQuantity(line,1)}){Text("+1")};Spacer(Modifier.width(8.dp));OutlinedButton({store.editPurchaseQuantity(line,-1)}){Text("-1")};Spacer(Modifier.width(8.dp));OutlinedButton({store.deletePurchaseLine(line)}){Text("Eliminar")}}}}}
    }
}

@Composable fun SuppliersScreen(store:NexoStore){ LazyColumn{ item{Header("Proveedores","Historial e inversión por proveedor")}; items(store.supplierSummaries()){s->Card(Modifier.fillMaxWidth().padding(16.dp)){Column(Modifier.padding(16.dp)){Text(s.supplier,fontWeight=FontWeight.Bold);Text("Invertido: ${cop(s.totalInvested)}");Text("Unidades: ${s.totalUnits}");Text("Líneas de compra: ${s.purchasesCount}")}}} } }

@Composable fun SalesScreen(store:NexoStore){ var q by remember{ mutableStateOf("") }; LazyColumn{ item{Header("Ventas","Registra ventas rápidas")}; item{OutlinedTextField(q,{q=it},label={Text("Buscar producto")},modifier=Modifier.fillMaxWidth().padding(16.dp))}; items(store.filteredProducts(q).filter{it.stock>0}){p->Card(Modifier.fillMaxWidth().padding(16.dp)){Column(Modifier.padding(16.dp)){Text(p.name,fontWeight=FontWeight.Bold);Text("Precio: ${cop(p.salePrice)}");Text("Stock: ${p.stock}");if(store.isAdmin()) Row{Button({store.registerSale(p,SellerType.OWNER)}){Text("Vendí yo")};Spacer(Modifier.width(8.dp));OutlinedButton({store.registerSale(p,SellerType.WORKER)}){Text("Trabajador")}} else Button({store.registerSale(p,SellerType.WORKER)},Modifier.fillMaxWidth()){Text("Registrar mi venta")}}}}; item{Text("Historial",Modifier.padding(16.dp),fontWeight=FontWeight.Bold)}; items(store.sales.reversed()){s->Card(Modifier.fillMaxWidth().padding(16.dp)){Column(Modifier.padding(16.dp)){Text(s.productName,fontWeight=FontWeight.Bold);Text("Precio: ${cop(s.price)}");Text("Vendedor: ${s.sellerType}");if(store.isAdmin())Text("Utilidad: ${cop(s.profit)}")}}} } }

@Composable fun AiScreen(store:NexoStore){ val low=store.lowStockProducts().firstOrNull(); val best=store.products.maxByOrNull{it.profitOwner}; LazyColumn{ item{Header("Nexo IA","Recomendaciones")}; item{Card(Modifier.fillMaxWidth().padding(16.dp)){Text(when{low!=null->"Publica ${low.name} como ÚLTIMA UNIDAD."; best!=null->"Publica ${best.name}, tiene buena ganancia."; else->"Agrega productos al inventario."},Modifier.padding(16.dp))}} } }

@Composable fun ReportsScreen(store:NexoStore){ val cb=LocalClipboardManager.current; var report by remember{ mutableStateOf("Selecciona reporte") }; LazyColumn{ item{Header("Reportes","Exportación")}; item{MetricCard("Capital comprado",cop(store.purchasedCapital()),"🧾")}; item{MetricCard("Ventas",cop(store.totalSales()),"💰")}; item{Card(Modifier.fillMaxWidth().padding(16.dp)){Column(Modifier.padding(16.dp)){Button({report=store.exportPurchasesCsv()},Modifier.fillMaxWidth()){Text("CSV compras")};Button({report=store.exportInventoryCsv()},Modifier.fillMaxWidth()){Text("CSV inventario")};Button({report=store.exportSalesCsv()},Modifier.fillMaxWidth()){Text("CSV ventas")};OutlinedButton({report=store.backupText()},Modifier.fillMaxWidth()){Text("Backup")};OutlinedButton({cb.setText(AnnotatedString(report))},Modifier.fillMaxWidth()){Text("Copiar")}}}}; item{Card(Modifier.fillMaxWidth().padding(16.dp)){Text(report,Modifier.padding(16.dp))}} } }

@Composable fun UsersScreen(store:NexoStore){ var form by remember{ mutableStateOf(false) }; LazyColumn{ item{Header("Usuarios","Administradores y trabajadores")}; item{Button({form=!form},Modifier.padding(16.dp).fillMaxWidth()){Text("Crear usuario")}}; if(form)item{CreateUserCard(store)}; items(store.users){u->Card(Modifier.fillMaxWidth().padding(16.dp)){Column(Modifier.padding(16.dp)){Text(u.displayName,fontWeight=FontWeight.Bold);Text("Usuario: ${u.username}");Text("Rol: ${u.role}");Text("Estado: ${if(u.active)"Activo" else "Inactivo"}");if(u.username!="admin")OutlinedButton({store.toggleUser(u.username)}){Text(if(u.active)"Desactivar" else "Activar")}}}} } }

@Composable fun CreateUserCard(store:NexoStore){ var u by remember{ mutableStateOf("") }; var n by remember{ mutableStateOf("") }; var p by remember{ mutableStateOf("") }; var c by remember{ mutableStateOf("") }; var admin by remember{ mutableStateOf(false) }; Card(Modifier.fillMaxWidth().padding(16.dp)){Column(Modifier.padding(16.dp)){OutlinedTextField(u,{u=it},label={Text("Usuario")},modifier=Modifier.fillMaxWidth());OutlinedTextField(n,{n=it},label={Text("Nombre")},modifier=Modifier.fillMaxWidth());OutlinedTextField(p,{p=it},label={Text("Clave")},visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth());OutlinedTextField(c,{c=it},label={Text("Confirmar")},visualTransformation=PasswordVisualTransformation(),modifier=Modifier.fillMaxWidth());Row(verticalAlignment=Alignment.CenterVertically){Checkbox(admin,{admin=it});Text("Administrador")};Button({store.registerUser(u,n,p,c,if(admin)UserRole.ADMIN else UserRole.WORKER)},Modifier.fillMaxWidth()){Text("Crear")}}} }

@Composable fun SettingsScreen(store:NexoStore){ LazyColumn{ item{Header("Configuración","Sistema")}; item{Card(Modifier.fillMaxWidth().padding(16.dp)){Column(Modifier.padding(16.dp)){Text("Usuario: ${store.currentUser.value?.displayName}");Text("Versión: 1.3.0");Button({store.logout()},Modifier.fillMaxWidth()){Text("Cerrar sesión")}}}} } }
