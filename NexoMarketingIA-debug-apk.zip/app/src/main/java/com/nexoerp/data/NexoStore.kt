package com.nexoerp.data

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf

class NexoStore(context: Context) {
    private val storage = LocalStorage(context)

    val products = mutableStateListOf<Product>()
    val sales = mutableStateListOf<Sale>()
    val selectedTab = mutableStateOf(AppTab.DASHBOARD)
    val currentUser = mutableStateOf<AppUser?>(storage.loadCurrentUser())
    val loginError = mutableStateOf("")
    val appMessage = mutableStateOf("")

    init {
        val savedProducts = storage.loadProducts()
        val savedSales = storage.loadSales()

        if (savedProducts.isEmpty()) {
            products.addAll(defaultProducts())
            persistProducts()
        } else {
            products.addAll(savedProducts)
        }

        sales.addAll(savedSales)
    }

    private fun defaultProducts(): List<Product> = listOf(
        Product(1, "Pijama Stitch Azul", "Pijamas", 27694.0, 38000.0, 6),
        Product(2, "Pijama Daisy Rosada", "Pijamas", 34694.0, 45000.0, 1),
        Product(3, "Pijama Garfield", "Pijamas", 31694.0, 40000.0, 1)
    )

    fun login(username: String, password: String): Boolean {
        val normalized = username.trim().lowercase()
        val user = when {
            normalized == "admin" && password == "1234" ->
                AppUser("admin", "Administrador", UserRole.ADMIN)
            normalized == "trabajador" && password == "1234" ->
                AppUser("trabajador", "Trabajador", UserRole.WORKER)
            else -> null
        }

        return if (user != null) {
            currentUser.value = user
            loginError.value = ""
            appMessage.value = "Bienvenido ${user.displayName}"
            storage.saveCurrentUser(user)
            true
        } else {
            loginError.value = "Usuario o clave incorrectos"
            false
        }
    }

    fun logout() {
        currentUser.value = null
        selectedTab.value = AppTab.DASHBOARD
        storage.saveCurrentUser(null)
    }

    fun isAdmin(): Boolean = currentUser.value?.role == UserRole.ADMIN

    fun addProduct(name: String, category: String, realCost: Double, salePrice: Double, stock: Int): Boolean {
        if (!isAdmin()) {
            appMessage.value = "Solo administrador puede agregar productos"
            return false
        }
        if (name.trim().length < 3) {
            appMessage.value = "El nombre debe tener mínimo 3 caracteres"
            return false
        }
        if (realCost < 0.0 || salePrice <= 0.0 || stock < 0) {
            appMessage.value = "Revisa costo, precio y stock"
            return false
        }
        if (salePrice <= realCost) {
            appMessage.value = "El precio de venta debe ser mayor al costo"
            return false
        }

        val nextId = (products.maxOfOrNull { it.id } ?: 0) + 1
        products.add(Product(nextId, name.trim(), category.trim().ifBlank { "General" }, realCost, salePrice, stock))
        persistProducts()
        appMessage.value = "Producto guardado correctamente"
        return true
    }

    fun registerSale(product: Product, sellerType: SellerType): Boolean {
        if (product.stock <= 0) {
            appMessage.value = "No hay stock disponible"
            return false
        }

        val forcedSeller = if (currentUser.value?.role == UserRole.WORKER) SellerType.WORKER else sellerType
        val commission = if (forcedSeller == SellerType.WORKER) 5000.0 else 0.0
        val profit = product.salePrice - product.realCost - commission

        sales.add(
            Sale(
                id = sales.size + 1,
                productName = product.name,
                price = product.salePrice,
                realCost = product.realCost,
                sellerType = forcedSeller,
                profit = profit
            )
        )

        val index = products.indexOfFirst { it.id == product.id }
        if (index >= 0) {
            val current = products[index]
            products[index] = current.copy(stock = (current.stock - 1).coerceAtLeast(0))
        }

        persistProducts()
        persistSales()
        appMessage.value = "Venta registrada: ${product.name}"
        return true
    }

    fun resetDemo() {
        if (!isAdmin()) return
        products.clear()
        sales.clear()
        products.addAll(defaultProducts())
        persistProducts()
        persistSales()
        appMessage.value = "Demo reiniciada"
    }

    fun filteredProducts(query: String): List<Product> {
        val q = query.trim().lowercase()
        if (q.isBlank()) return products
        return products.filter {
            it.name.lowercase().contains(q) || it.category.lowercase().contains(q)
        }
    }

    fun totalSales(): Double = sales.sumOf { it.price }
    fun totalProfit(): Double = sales.sumOf { it.profit }
    fun totalStock(): Int = products.sumOf { it.stock }
    fun investedCapital(): Double = products.sumOf { it.realCost * it.stock }
    fun recoveredCapital(): Double = sales.sumOf { it.realCost }
    fun lowStockProducts(): List<Product> = products.filter { it.stock <= it.minStock }
    fun workerCommissions(): Double = sales.count { it.sellerType == SellerType.WORKER } * 5000.0
    fun netProfit(): Double = totalProfit()
    fun averageMargin(): Double = if (products.isEmpty()) 0.0 else products.map { it.marginPercent }.average()

    fun exportInventoryCsv(): String {
        return buildString {
            appendLine("id,nombre,categoria,costo_real,precio_venta,stock,margen,ganancia_dueno,ganancia_trabajador")
            products.forEach {
                appendLine("${it.id},${it.name},${it.category},${it.realCost},${it.salePrice},${it.stock},${it.marginPercent},${it.profitOwner},${it.profitWorker}")
            }
        }
    }

    fun exportSalesCsv(): String {
        return buildString {
            appendLine("id,producto,precio,costo_real,vendedor,utilidad")
            sales.forEach {
                appendLine("${it.id},${it.productName},${it.price},${it.realCost},${it.sellerType},${it.profit}")
            }
        }
    }

    fun backupText(): String {
        return buildString {
            appendLine("=== NEXO ERP BACKUP ===")
            appendLine("PRODUCTOS")
            appendLine(exportInventoryCsv())
            appendLine("VENTAS")
            appendLine(exportSalesCsv())
            appendLine("RESUMEN")
            appendLine("Ventas: ${totalSales()}")
            appendLine("Utilidad neta: ${netProfit()}")
            appendLine("Capital inventario: ${investedCapital()}")
            appendLine("Capital recuperado: ${recoveredCapital()}")
        }
    }

    private fun persistProducts() = storage.saveProducts(products)
    private fun persistSales() = storage.saveSales(sales)
}
