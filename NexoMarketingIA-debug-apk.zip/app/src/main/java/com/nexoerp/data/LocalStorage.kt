package com.nexoerp.data

import android.content.Context

class LocalStorage(context: Context) {
    private val prefs = context.getSharedPreferences("nexo_erp_storage", Context.MODE_PRIVATE)

    fun saveProducts(products: List<Product>) {
        val text = products.joinToString("\n") {
            listOf(
                it.id,
                clean(it.name),
                clean(it.category),
                it.realCost,
                it.salePrice,
                it.stock,
                it.minStock
            ).joinToString("|")
        }
        prefs.edit().putString("products", text).apply()
    }

    fun loadProducts(): List<Product> {
        val text = prefs.getString("products", null) ?: return emptyList()
        return text.lines().filter { it.isNotBlank() }.mapNotNull { line ->
            val p = line.split("|")
            try {
                Product(
                    id = p[0].toInt(),
                    name = p[1],
                    category = p[2],
                    realCost = p[3].toDouble(),
                    salePrice = p[4].toDouble(),
                    stock = p[5].toInt(),
                    minStock = p[6].toInt()
                )
            } catch (_: Exception) {
                null
            }
        }
    }

    fun saveSales(sales: List<Sale>) {
        val text = sales.joinToString("\n") {
            listOf(
                it.id,
                clean(it.productName),
                it.price,
                it.realCost,
                it.sellerType.name,
                it.profit
            ).joinToString("|")
        }
        prefs.edit().putString("sales", text).apply()
    }

    fun loadSales(): List<Sale> {
        val text = prefs.getString("sales", null) ?: return emptyList()
        return text.lines().filter { it.isNotBlank() }.mapNotNull { line ->
            val p = line.split("|")
            try {
                Sale(
                    id = p[0].toInt(),
                    productName = p[1],
                    price = p[2].toDouble(),
                    realCost = p[3].toDouble(),
                    sellerType = SellerType.valueOf(p[4]),
                    profit = p[5].toDouble()
                )
            } catch (_: Exception) {
                null
            }
        }
    }

    fun saveCurrentUser(user: AppUser?) {
        if (user == null) {
            prefs.edit().remove("current_user").apply()
        } else {
            val text = listOf(user.username, user.displayName, user.role.name).joinToString("|")
            prefs.edit().putString("current_user", text).apply()
        }
    }

    fun loadCurrentUser(): AppUser? {
        val text = prefs.getString("current_user", null) ?: return null
        val p = text.split("|")
        return try {
            AppUser(
                username = p[0],
                displayName = p[1],
                role = UserRole.valueOf(p[2])
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun clean(value: String): String {
        return value.replace("|", " ").replace("\n", " ")
    }
}
