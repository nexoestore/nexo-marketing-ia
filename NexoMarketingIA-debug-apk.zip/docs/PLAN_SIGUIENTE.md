# Próximas mejoras recomendadas

## Versión 1.1
- Migrar SharedPreferences a Room.
- Separar pantallas en archivos.
- Agregar edición y eliminación de productos.
- Agregar clientes.
- Agregar compras con distribución automática de envío.

## Versión 1.2
- Exportación real de CSV a archivo.
- Copia de seguridad importable.
- Historial por cliente.
- Reportes por fecha.

## Versión 2.0
- Supabase/Firebase.
- Sincronización en la nube.
- Usuarios reales.
- IA conectada a Gemini/OpenAI.
- Generador avanzado de marketing.
