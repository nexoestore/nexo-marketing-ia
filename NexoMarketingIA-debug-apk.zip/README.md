# Nexo ERP - Generación 18

Versión 1.0 inicial de Nexo ERP.

Esta entrega consolida el proyecto Android real construido desde la Generación 12.

## Funciones principales

- Login local con roles:
  - ADMIN
  - WORKER

- Dashboard:
  - Ventas registradas
  - Ganancia registrada
  - Comisiones
  - Stock disponible
  - Capital en inventario
  - Capital recuperado
  - Margen promedio

- Inventario:
  - Buscar productos
  - Agregar productos
  - Validaciones
  - Stock
  - Costo real
  - Precio de venta
  - Ganancia si vende el administrador
  - Ganancia si vende trabajador
  - Etiquetas: disponible, stock bajo, última unidad, agotado

- Ventas:
  - Registrar venta como administrador
  - Registrar venta como trabajador
  - Descontar stock
  - Calcular comisión
  - Calcular utilidad
  - Historial de ventas

- Nexo IA:
  - Recomendación de qué publicar
  - Copy para Facebook
  - Prompt para Veo 3

- Reportes:
  - Exportar inventario CSV
  - Exportar ventas CSV
  - Copia de seguridad textual
  - Copiar reporte

- Configuración:
  - Cerrar sesión
  - Reiniciar demo

## Usuarios demo

Administrador:
- Usuario: admin
- Clave: 1234

Trabajador:
- Usuario: trabajador
- Clave: 1234

## Cómo compilar

1. Descomprime el ZIP.
2. Sube el proyecto a GitHub.
3. Ejecuta GitHub Actions: `Build Android APK`.
4. Descarga el APK generado desde Artifacts.

## Nota honesta

Esta es una versión funcional local inicial. Todavía no usa Room, Firebase ni Supabase.
Para producción real, el siguiente paso recomendado sería migrar almacenamiento a Room y añadir exportación real de archivos.
