plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.nexo.marketingpro"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.nexo.marketingpro"
        minSdk = 23
        targetSdk = 35
        versionCode = 6
        versionName = "1.0-pro"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions { jvmTarget = "17" }
}
