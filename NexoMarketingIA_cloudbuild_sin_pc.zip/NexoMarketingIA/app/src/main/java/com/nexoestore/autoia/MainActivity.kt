
package com.nexoestore.autoia

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var content: LinearLayout
    private val bg = Color.rgb(4, 7, 8)
    private val card = Color.rgb(16, 26, 29)
    private val card2 = Color.rgb(23, 38, 41)
    private val accent = Color.rgb(22, 242, 226)
    private val white = Color.WHITE
    private val muted = Color.rgb(160, 176, 180)
    private val danger = Color.rgb(222, 70, 70)
    private val prefs by lazy { getSharedPreferences("nexo_marketing_ia_personal", Context.MODE_PRIVATE) }

    data class Product(val name:String,val price:String,val category:String,val desc:String)
    data class CopyItem(val title:String,val category:String,val text:String,var used:Int=0)
    data class GroupItem(val name:String,val platform:String,val link:String,val last:String="Pendiente")
    data class ClientItem(val name:String,val phone:String,val product:String,val status:String,val note:String)
    data class QuickReply(val title:String,val text:String)

    private val products = mutableListOf(
        Product("Amazon Prime","US$2.00","Streaming","Cuenta 1 mes · entrega automática"),
        Product("Max Platino 4K","US$4.50","Streaming","Acceso Max Platino UHD 30 días"),
        Product("Disney+ Premium","US$8.00","Streaming","Cuenta Disney Premium 30 días"),
        Product("Plan PRO","US$5.00","Membresía","30% dscto. en compras streaming + soporte prioritario")
    )

    private val quickReplies = mutableListOf(
        QuickReply("Registro y recarga", "¡Hola! 😊\n\nIngresa a www.nexoestore.com\n\n✅ Regístrate gratis\n✅ Recarga saldo\n✅ Envíame el ID o comprobante\n✅ Valido y apruebo tu saldo\n✅ Compras con entrega automática"),
        QuickReply("Stock en web", "Sí, tenemos disponibilidad. Todo el stock se consulta directamente en nuestra web:\n\n🌐 www.nexoestore.com\n\nAllí puedes verificar disponibilidad, registrarte gratis y comprar con entrega automática."),
        QuickReply("Plan PRO", "🚀 PLAN PRO – US$5\n\n🎬 30% de descuento en compras de servicios Streaming a precio proveedor.\n⚡ Prioridad en soporte por WhatsApp durante el horario de atención.\n🛒 Descuentos aplicados automáticamente mientras esté activo."),
        QuickReply("Revendedor", "Entiendo que trabajas como revendedor. Puedes configurar nombre de perfil y PIN cuando sea necesario. Lo importante es no cambiar correo principal, contraseña maestra ni datos de recuperación para mantener la garantía.")
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showMain()
    }

    private fun showMain(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(bg)}
        val header=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(22,28,22,12)}
        header.addView(TextView(this).apply{text="Nexo Marketing IA";setTextColor(accent);textSize=26f;typeface=Typeface.DEFAULT_BOLD})
        header.addView(TextView(this).apply{text="App personal para publicar, captar prospectos y hacer seguimiento";setTextColor(muted);textSize=14f})
        root.addView(header)
        val tabs1=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(8,0,8,0)}
        val tabs2=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(8,0,8,8)}
        tabs1.addView(tab("HOY"){showHoy()}); tabs1.addView(tab("PRODUCTOS"){showProductos()}); tabs1.addView(tab("COPYS"){showCopys()})
        tabs2.addView(tab("GRUPOS"){showGrupos()}); tabs2.addView(tab("CLIENTES"){showClientes()}); tabs2.addView(tab("RESPUESTAS"){showRespuestas()})
        root.addView(tabs1);root.addView(tabs2)
        val scroll=ScrollView(this)
        content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,10,16,32)}
        scroll.addView(content)
        root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
        showHoy()
    }

    private fun showHoy(){
        content.removeAllViews()
        title("Tareas de hoy")
        val groups=loadGroups(); val clients=loadClients(); val copies=loadCopies()
        val pendientes=clients.count{it.status=="Nuevo"||it.status=="Interesado"}
        val stats=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        stats.addView(stat("Grupos",groups.size.toString()))
        stats.addView(stat("Copys",copies.size.toString()))
        stats.addView(stat("Clientes",clients.size.toString()))
        stats.addView(stat("Pendientes",pendientes.toString()))
        content.addView(stats)
        cardView("Plan diario recomendado","1. Publica en 5 a 10 grupos.\n2. Copia un texto corto.\n3. Registra cada interesado.\n4. Responde antes de dormir."){
            addView(button("COPIAR COPY PRINCIPAL"){ copy(firstCopy()) })
            addView(button("VER GRUPOS"){ showGrupos() })
            addView(button("REGISTRAR CLIENTE"){ dialogClient(null) })
        }.also{content.addView(it)}
        cardView("Web de venta","Usa este enlace para mover prospectos a la compra automática:\nwww.nexoestore.com"){
            addView(button("COPIAR WEB"){ copy("www.nexoestore.com") })
            addView(button("ABRIR WEB"){ openUrl("https://www.nexoestore.com") })
        }.also{content.addView(it)}
    }

    private fun showProductos(){
        content.removeAllViews(); title("Catálogo y promociones")
        products.forEach{p->
            val text="🔥 ${p.name}\n\n${p.desc}\nPrecio proveedor: ${p.price}\n\n✅ Entrega automática\n✅ Stock en web\n✅ Registro gratuito\n\n🌐 www.nexoestore.com"
            cardView(p.name,"${p.desc}\nPrecio: ${p.price}\nCategoría: ${p.category}"){
                addView(button("COPIAR PROMOCIÓN"){copy(text)})
                addView(button("COPIAR PARA PROVEEDORES"){copy("🚀 Stock disponible para revendedores\n\n✅ ${p.name}\n\n⚡ Entrega automática\n⚡ Panel web propio\n⚡ Registro gratuito\n\n🌐 www.nexoestore.com")})
            }.also{content.addView(it)}
        }
    }

    private fun showCopys(){
        content.removeAllViews(); title("Biblioteca de copys")
        content.addView(button("+ CREAR COPY"){ dialogCopy(null) })
        loadCopies().forEachIndexed{idx,c->
            cardView(c.title,"${c.category} · usado ${c.used} veces\n\n${c.text}"){
                addView(button("COPIAR"){ c.used++; saveCopies(loadCopies().toMutableList().also{it[idx]=c}); copy(c.text); showCopys() })
                addView(button("EDITAR"){ dialogCopy(idx) })
                addView(redButton("BORRAR"){ val list=loadCopies().toMutableList(); list.removeAt(idx); saveCopies(list); showCopys() })
            }.also{content.addView(it)}
        }
    }

    private fun showGrupos(){
        content.removeAllViews(); title("Gestor de grupos")
        content.addView(button("+ AGREGAR GRUPO"){ dialogGroup(null) })
        loadGroups().forEachIndexed{idx,g->
            cardView(g.name,"${g.platform}\nÚltima publicación: ${g.last}\n${g.link}"){
                addView(button("ABRIR GRUPO"){ openUrl(g.link) })
                addView(button("MARCAR PUBLICADO HOY"){ val list=loadGroups().toMutableList(); list[idx]=g.copy(last=today()); saveGroups(list); showGrupos() })
                addView(button("EDITAR"){ dialogGroup(idx) })
                addView(redButton("BORRAR"){ val list=loadGroups().toMutableList(); list.removeAt(idx); saveGroups(list); showGrupos() })
            }.also{content.addView(it)}
        }
    }

    private fun showClientes(){
        content.removeAllViews(); title("Clientes / CRM personal")
        content.addView(button("+ AGREGAR CLIENTE"){ dialogClient(null) })
        loadClients().forEachIndexed{idx,c->
            cardView(c.name,"Estado: ${c.status}\nProducto: ${c.product}\nWhatsApp: ${c.phone}\nNotas: ${c.note}"){
                addView(button("ABRIR WHATSAPP"){ if(c.phone.isBlank()) toast("Sin número") else openUrl("https://wa.me/${c.phone.filter{it.isDigit()}}") })
                addView(button("COPIAR RESPUESTA"){ copy(quickReplies.first().text) })
                val row=LinearLayout(this@MainActivity).apply{orientation=LinearLayout.HORIZONTAL}
                listOf("Nuevo","Interesado","Registrado","Compró","Perdido").forEach{st-> row.addView(smallButton(st){ val list=loadClients().toMutableList(); list[idx]=c.copy(status=st); saveClients(list); showClientes() }) }
                addView(row)
                addView(button("EDITAR"){ dialogClient(idx) })
                addView(redButton("BORRAR"){ val list=loadClients().toMutableList(); list.removeAt(idx); saveClients(list); showClientes() })
            }.also{content.addView(it)}
        }
    }

    private fun showRespuestas(){
        content.removeAllViews(); title("Respuestas rápidas")
        quickReplies.forEach{r-> cardView(r.title,r.text){ addView(button("COPIAR RESPUESTA"){copy(r.text)}) }.also{content.addView(it)} }
    }

    private fun dialogCopy(index:Int?){
        val item=index?.let{loadCopies()[it]} ?: CopyItem("","","")
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,8,24,0)}
        val t=input("Título",item.title); val cat=input("Categoría",item.category); val txt=input("Texto",item.text,true)
        box.addView(t);box.addView(cat);box.addView(txt)
        AlertDialog.Builder(this).setTitle(if(index==null)"Crear copy" else "Editar copy").setView(box).setPositiveButton("Guardar"){_,_->
            val list=loadCopies().toMutableList(); val new=CopyItem(t.text.toString(),cat.text.toString(),txt.text.toString(), item.used)
            if(index==null) list.add(0,new) else list[index]=new
            saveCopies(list); showCopys()
        }.setNegativeButton("Cancelar",null).show()
    }
    private fun dialogGroup(index:Int?){
        val item=index?.let{loadGroups()[it]} ?: GroupItem("","Facebook","")
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,8,24,0)}
        val n=input("Nombre",item.name); val p=input("Plataforma",item.platform); val l=input("Link",item.link)
        box.addView(n);box.addView(p);box.addView(l)
        AlertDialog.Builder(this).setTitle(if(index==null)"Agregar grupo" else "Editar grupo").setView(box).setPositiveButton("Guardar"){_,_->
            val list=loadGroups().toMutableList(); val new=GroupItem(n.text.toString(),p.text.toString(),l.text.toString(), item.last)
            if(index==null) list.add(0,new) else list[index]=new
            saveGroups(list); showGrupos()
        }.setNegativeButton("Cancelar",null).show()
    }
    private fun dialogClient(index:Int?){
        val item=index?.let{loadClients()[it]} ?: ClientItem("","","","Nuevo","")
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,8,24,0)}
        val n=input("Nombre",item.name); val ph=input("WhatsApp",item.phone); val pr=input("Producto",item.product); val note=input("Notas",item.note,true)
        box.addView(n);box.addView(ph);box.addView(pr);box.addView(note)
        AlertDialog.Builder(this).setTitle(if(index==null)"Agregar cliente" else "Editar cliente").setView(box).setPositiveButton("Guardar"){_,_->
            val list=loadClients().toMutableList(); val new=ClientItem(n.text.toString(),ph.text.toString(),pr.text.toString(),item.status,note.text.toString())
            if(index==null) list.add(0,new) else list[index]=new
            saveClients(list); showClientes()
        }.setNegativeButton("Cancelar",null).show()
    }

    private fun loadCopies():List<CopyItem>{
        val raw=prefs.getString("copies",null) ?: return listOf(
            CopyItem("Proveedor streaming","Revendedores","🚀 Stock disponible para revendedores\n\n✅ Amazon Prime\n✅ Max Platino 4K\n✅ Disney+ Premium\n\n⚡ Entrega automática\n⚡ Panel web propio\n⚡ Registro gratuito\n\n🌐 www.nexoestore.com",0),
            CopyItem("Menos es más","Grupos","🔥 Proveedor de Streaming\n\nStock disponible.\n\n🌐 www.nexoestore.com\n\nRegistro gratis.",0)
        )
        return raw.lines().filter{it.isNotBlank()}.mapNotNull{line-> val a=line.split("|"); if(a.size<4)null else CopyItem(dec(a[0]),dec(a[1]),dec(a[2]),a[3].toIntOrNull()?:0) }
    }
    private fun saveCopies(list:List<CopyItem>){ prefs.edit().putString("copies",list.joinToString("\n"){ listOf(enc(it.title),enc(it.category),enc(it.text),it.used.toString()).joinToString("|") }).apply() }
    private fun loadGroups():List<GroupItem>{ val raw=prefs.getString("groups",null) ?: return emptyList(); return raw.lines().filter{it.isNotBlank()}.mapNotNull{val a=it.split("|"); if(a.size<4)null else GroupItem(dec(a[0]),dec(a[1]),dec(a[2]),dec(a[3]))} }
    private fun saveGroups(list:List<GroupItem>){ prefs.edit().putString("groups",list.joinToString("\n"){ listOf(enc(it.name),enc(it.platform),enc(it.link),enc(it.last)).joinToString("|") }).apply() }
    private fun loadClients():List<ClientItem>{ val raw=prefs.getString("clients",null) ?: return emptyList(); return raw.lines().filter{it.isNotBlank()}.mapNotNull{val a=it.split("|"); if(a.size<5)null else ClientItem(dec(a[0]),dec(a[1]),dec(a[2]),dec(a[3]),dec(a[4]))} }
    private fun saveClients(list:List<ClientItem>){ prefs.edit().putString("clients",list.joinToString("\n"){ listOf(enc(it.name),enc(it.phone),enc(it.product),enc(it.status),enc(it.note)).joinToString("|") }).apply() }

    private fun enc(s:String)=Base64.encodeToString(s.toByteArray(Charsets.UTF_8),Base64.NO_WRAP)
    private fun dec(s:String)=String(Base64.decode(s,Base64.NO_WRAP),Charsets.UTF_8)
    private fun firstCopy()=loadCopies().firstOrNull()?.text ?: "🚀 Stock disponible\n🌐 www.nexoestore.com"
    private fun today()=java.text.SimpleDateFormat("dd/MM/yyyy",java.util.Locale.getDefault()).format(java.util.Date())
    private fun copy(text:String){ val cm=getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager; cm.setPrimaryClip(ClipData.newPlainText("Nexo Marketing IA",text)); toast("Copiado") }
    private fun openUrl(url:String){ val u=if(url.startsWith("http"))url else "https://$url"; startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(u))) }
    private fun toast(t:String)=Toast.makeText(this,t,Toast.LENGTH_SHORT).show()

    private fun title(t:String){ content.addView(TextView(this).apply{text=t;setTextColor(white);textSize=23f;typeface=Typeface.DEFAULT_BOLD;setPadding(0,6,0,14)}) }
    private fun tab(t:String,onClick:()->Unit)=Button(this).apply{text=t;setTextColor(white);setBackgroundColor(card2);textSize=11f;setOnClickListener{onClick()};layoutParams=LinearLayout.LayoutParams(0,58,1f).apply{setMargins(4,4,4,4)}}
    private fun stat(label:String,value:String)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(card);setPadding(12,12,12,12);layoutParams=LinearLayout.LayoutParams(0,-2,1f).apply{setMargins(4,4,4,12)};addView(TextView(this@MainActivity).apply{text=value;setTextColor(accent);textSize=24f;typeface=Typeface.DEFAULT_BOLD});addView(TextView(this@MainActivity).apply{text=label;setTextColor(muted);textSize=11f})}
    private fun cardView(title:String,body:String,extra:LinearLayout.()->Unit):LinearLayout=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(card);setPadding(18,16,18,16);layoutParams=LinearLayout.LayoutParams(-1,-2).apply{setMargins(0,0,0,14)};addView(TextView(this@MainActivity).apply{text=title;setTextColor(white);textSize=18f;typeface=Typeface.DEFAULT_BOLD});addView(TextView(this@MainActivity).apply{text=body;setTextColor(muted);textSize=14f;setPadding(0,8,0,10)});extra()}
    private fun button(t:String,onClick:()->Unit)=Button(this).apply{text=t;setTextColor(Color.BLACK);setBackgroundColor(accent);setOnClickListener{onClick()};layoutParams=LinearLayout.LayoutParams(-1,54).apply{setMargins(0,6,0,6)}}
    private fun redButton(t:String,onClick:()->Unit)=Button(this).apply{text=t;setTextColor(white);setBackgroundColor(danger);setOnClickListener{onClick()};layoutParams=LinearLayout.LayoutParams(-1,54).apply{setMargins(0,6,0,6)}}
    private fun smallButton(t:String,onClick:()->Unit)=Button(this).apply{text=t;setTextColor(white);textSize=10f;setBackgroundColor(card2);setOnClickListener{onClick()};layoutParams=LinearLayout.LayoutParams(0,46,1f).apply{setMargins(2,4,2,4)}}
    private fun input(hint:String,value:String,multi:Boolean=false)=EditText(this).apply{setText(value);this.hint=hint;setTextColor(Color.BLACK);setHintTextColor(Color.GRAY);if(multi){minLines=4;gravity=Gravity.TOP}}
}
