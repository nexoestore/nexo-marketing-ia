package com.nexoerp.data

import android.content.Context

class LocalStorage(context: Context) {
    private val prefs = context.getSharedPreferences("nexo_erp_storage", Context.MODE_PRIVATE)

    fun saveProducts(products: List<Product>) {
        val text = products.joinToString("\n") {
            listOf(it.id, clean(it.name), clean(it.category), it.realCost, it.salePrice, it.stock, it.minStock).joinToString("|")
        }
        prefs.edit().putString("products", text).apply()
    }

    fun loadProducts(): List<Product> {
        val text = prefs.getString("products", null) ?: return emptyList()
        return text.lines().filter { it.isNotBlank() }.mapNotNull { line ->
            val p = line.split("|")
            try {
                Product(p[0].toInt(), p[1], p[2], p[3].toDouble(), p[4].toDouble(), p[5].toInt(), p[6].toInt())
            } catch (_: Exception) { null }
        }
    }

    fun saveSales(sales: List<Sale>) {
        val text = sales.joinToString("\n") {
            listOf(it.id, clean(it.productName), it.price, it.realCost, it.sellerType.name, it.profit).joinToString("|")
        }
        prefs.edit().putString("sales", text).apply()
    }

    fun loadSales(): List<Sale> {
        val text = prefs.getString("sales", null) ?: return emptyList()
        return text.lines().filter { it.isNotBlank() }.mapNotNull { line ->
            val p = line.split("|")
            try {
                Sale(p[0].toInt(), p[1], p[2].toDouble(), p[3].toDouble(), SellerType.valueOf(p[4]), p[5].toDouble())
            } catch (_: Exception) { null }
        }
    }

    fun savePurchases(purchases: List<Purchase>) {
        val text = purchases.joinToString("\n") {
            listOf(it.id, clean(it.supplier), clean(it.productName), it.quantity, it.unitCost, it.shippingCost, it.realUnitCost, it.salePrice, it.total, clean(it.date)).joinToString("|")
        }
        prefs.edit().putString("purchases", text).apply()
    }

    fun loadPurchases(): List<Purchase> {
        val text = prefs.getString("purchases", null) ?: return emptyList()
        return text.lines().filter { it.isNotBlank() }.mapNotNull { line ->
            val p = line.split("|")
            try {
                Purchase(p[0].toInt(), p[1], p[2], p[3].toInt(), p[4].toDouble(), p[5].toDouble(), p[6].toDouble(), p[7].toDouble(), p[8].toDouble(), p[9])
            } catch (_: Exception) { null }
        }
    }

    fun saveMovements(movements: List<StockMovement>) {
        val text = movements.joinToString("\n") {
            listOf(it.id, clean(it.productName), it.quantityChange, clean(it.type), clean(it.reason), clean(it.date)).joinToString("|")
        }
        prefs.edit().putString("movements", text).apply()
    }

    fun loadMovements(): List<StockMovement> {
        val text = prefs.getString("movements", null) ?: return emptyList()
        return text.lines().filter { it.isNotBlank() }.mapNotNull { line ->
            val p = line.split("|")
            try {
                StockMovement(p[0].toInt(), p[1], p[2].toInt(), p[3], p[4], p[5])
            } catch (_: Exception) { null }
        }
    }

    fun saveUsers(users: List<AppUser>) {
        val text = users.joinToString("\n") {
            listOf(clean(it.username), clean(it.displayName), clean(it.password), it.role.name, it.active).joinToString("|")
        }
        prefs.edit().putString("users", text).apply()
    }

    fun loadUsers(): List<AppUser> {
        val text = prefs.getString("users", null) ?: return emptyList()
        return text.lines().filter { it.isNotBlank() }.mapNotNull { line ->
            val p = line.split("|")
            try {
                AppUser(p[0], p[1], p[2], UserRole.valueOf(p[3]), p[4].toBoolean())
            } catch (_: Exception) { null }
        }
    }

    fun saveCurrentUsername(username: String?) {
        if (username == null) prefs.edit().remove("current_username").apply()
        else prefs.edit().putString("current_username", username).apply()
    }

    fun loadCurrentUsername(): String? = prefs.getString("current_username", null)

    private fun clean(value: String): String {
        return value.replace("|", " ").replace("\n", " ")
    }
}
