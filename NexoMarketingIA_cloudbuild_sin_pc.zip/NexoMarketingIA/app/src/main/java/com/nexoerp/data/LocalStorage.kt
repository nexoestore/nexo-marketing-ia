package com.nexoerp.data

import android.content.Context

class LocalStorage(context: Context) {
    private val prefs = context.getSharedPreferences("nexo_erp_storage", Context.MODE_PRIVATE)

    fun saveProducts(products: List<Product>) {
        val text = products.joinToString("\n") {
            listOf(it.id, clean(it.name), clean(it.category), it.realCost, it.salePrice, it.stock, it.minStock).joinToString("|")
        }
        prefs.edit().putString("products", text).apply()
    }

    fun loadProducts(): List<Product> {
        val text = prefs.getString("products", null) ?: return emptyList()
        return text.lines().filter { it.isNotBlank() }.mapNotNull { line ->
            val p = line.split("|")
            try { Product(p[0].toInt(), p[1], p[2], p[3].toDouble(), p[4].toDouble(), p[5].toInt(), p[6].toInt()) } catch (_: Exception) { null }
        }
    }

    fun saveSales(sales: List<Sale>) {
        val text = sales.joinToString("\n") {
            listOf(it.id, clean(it.productName), it.price, it.realCost, it.sellerType.name, it.profit).joinToString("|")
        }
        prefs.edit().putString("sales", text).apply()
    }

    fun loadSales(): List<Sale> {
        val text = prefs.getString("sales", null) ?: return emptyList()
        return text.lines().filter { it.isNotBlank() }.mapNotNull { line ->
            val p = line.split("|")
            try { Sale(p[0].toInt(), p[1], p[2].toDouble(), p[3].toDouble(), SellerType.valueOf(p[4]), p[5].toDouble()) } catch (_: Exception) { null }
        }
    }

    fun saveUsers(users: List<AppUser>) {
        val text = users.joinToString("\n") {
            listOf(clean(it.username), clean(it.displayName), clean(it.password), it.role.name, it.active).joinToString("|")
        }
        prefs.edit().putString("users", text).apply()
    }

    fun loadUsers(): List<AppUser> {
        val text = prefs.getString("users", null) ?: return emptyList()
        return text.lines().filter { it.isNotBlank() }.mapNotNull { line ->
            val p = line.split("|")
            try { AppUser(p[0], p[1], p[2], UserRole.valueOf(p[3]), p[4].toBoolean()) } catch (_: Exception) { null }
        }
    }

    fun saveCurrentUsername(username: String?) {
        if (username == null) prefs.edit().remove("current_username").apply()
        else prefs.edit().putString("current_username", username).apply()
    }

    fun loadCurrentUsername(): String? = prefs.getString("current_username", null)

    private fun clean(value: String): String = value.replace("|", " ").replace("\n", " ")
}
