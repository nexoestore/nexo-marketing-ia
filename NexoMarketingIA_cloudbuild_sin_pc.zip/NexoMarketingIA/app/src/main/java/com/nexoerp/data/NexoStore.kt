package com.nexoerp.data

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NexoStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("nexo_manager_gen27", Context.MODE_PRIVATE)

    val products = mutableStateListOf<Product>()
    val sales = mutableStateListOf<Sale>()
    val users = mutableStateListOf<AppUser>()

    val selectedTab = mutableStateOf(AppTab.DASHBOARD)
    val currentUser = mutableStateOf<AppUser?>(null)
    val loginError = mutableStateOf("")
    val appMessage = mutableStateOf("")

    init {
        loadAll()

        if (users.isEmpty()) {
            users.add(AppUser("admin", "Administrador", "1234", UserRole.ADMIN, true))
            users.add(AppUser("trabajador", "Trabajador", "1234", UserRole.WORKER, true))
        }

        if (products.isEmpty()) {
            products.add(Product(1, "Pijama Stitch Azul", "Pijamas", "P118", "770000000118", 30694.0, 42000.0, 16, ""))
            products.add(Product(2, "Pijama Daisy Rosada", "Pijamas", "P119", "770000000119", 34694.0, 45000.0, 1, ""))
            products.add(Product(3, "Pijama Garfield", "Pijamas", "P120", "770000000120", 31694.0, 40000.0, 0, ""))
        }

        saveAll()
    }

    private fun now(): String = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())

    fun login(username: String, password: String): Boolean {
        val user = users.firstOrNull {
            it.username.equals(username.trim(), ignoreCase = true) && it.password == password && it.active
        }

        return if (user != null) {
            currentUser.value = user
            loginError.value = ""
            appMessage.value = "Bienvenido ${user.displayName}"
            true
        } else {
            loginError.value = "Usuario, clave incorrectos o usuario inactivo"
            false
        }
    }

    fun logout() {
        currentUser.value = null
        selectedTab.value = AppTab.DASHBOARD
    }

    fun isAdmin(): Boolean = currentUser.value?.role == UserRole.ADMIN
    fun isWorker(): Boolean = currentUser.value?.role == UserRole.WORKER

    fun registerUser(username: String, name: String, pass: String, confirm: String, role: UserRole): Boolean {
        val clean = username.trim().lowercase()
        if (clean.length < 3) { appMessage.value = "Usuario mínimo 3 caracteres"; return false }
        if (name.trim().length < 3) { appMessage.value = "Nombre mínimo 3 caracteres"; return false }
        if (pass.length < 4) { appMessage.value = "Clave mínimo 4 caracteres"; return false }
        if (pass != confirm) { appMessage.value = "Las claves no coinciden"; return false }
        if (users.any { it.username == clean }) { appMessage.value = "Ese usuario ya existe"; return false }

        users.add(AppUser(clean, name.trim(), pass, role, true))
        saveAll()
        appMessage.value = "Usuario creado"
        return true
    }

    fun toggleUser(username: String) {
        if (!isAdmin()) return
        val i = users.indexOfFirst { it.username == username }
        if (i >= 0 && users[i].username != "admin") {
            users[i] = users[i].copy(active = !users[i].active)
            saveAll()
        }
    }

    fun addProduct(
        name: String,
        category: String,
        internalCode: String,
        barcode: String,
        cost: Double,
        price: Double,
        stock: Int,
        photo: String
    ): Boolean {
        if (!isAdmin()) { appMessage.value = "Solo administrador"; return false }
        if (name.trim().length < 3 || price <= 0 || cost < 0 || stock < 0) {
            appMessage.value = "Revisa los datos"
            return false
        }

        val id = (products.maxOfOrNull { it.id } ?: 0) + 1
        products.add(Product(id, name.trim(), category.ifBlank { "General" }, internalCode.trim(), barcode.trim(), cost, price, stock, photo))
        saveAll()
        appMessage.value = "Producto guardado"
        return true
    }

    fun filteredProducts(query: String): List<Product> {
        val q = query.trim().lowercase()
        if (q.isBlank()) return products

        return products.filter {
            it.name.lowercase().contains(q) ||
            it.category.lowercase().contains(q) ||
            it.internalCode.lowercase().contains(q) ||
            it.barcode.lowercase().contains(q)
        }
    }


    fun updateProduct(id: Int, name: String, category: String, internalCode: String, barcode: String, cost: Double, price: Double, stock: Int, photo: String): Boolean {
        if (!isAdmin()) { appMessage.value = "Solo administrador"; return false }
        if (name.trim().length < 3 || price <= 0 || cost < 0 || stock < 0) { appMessage.value = "Revisa los datos"; return false }
        val i = products.indexOfFirst { it.id == id }
        if (i < 0) { appMessage.value = "Producto no encontrado"; return false }
        products[i] = products[i].copy(name = name.trim(), category = category.ifBlank { "General" }, internalCode = internalCode.trim(), barcode = barcode.trim(), realCost = cost, salePrice = price, stock = stock, photoUri = photo)
        saveAll()
        appMessage.value = "Producto actualizado"
        return true
    }

    fun adjustStock(product: Product, amount: Int): Boolean {
        if (!isAdmin()) { appMessage.value = "Solo administrador"; return false }
        val i = products.indexOfFirst { it.id == product.id }
        if (i < 0) return false
        products[i] = products[i].copy(stock = (products[i].stock + amount).coerceAtLeast(0))
        saveAll()
        appMessage.value = "Stock actualizado"
        return true
    }

    fun deleteProduct(product: Product): Boolean {
        if (!isAdmin()) { appMessage.value = "Solo administrador"; return false }
        products.removeAll { it.id == product.id }
        saveAll()
        appMessage.value = "Producto eliminado"
        return true
    }

    fun registerSale(product: Product, seller: SellerType): Boolean {
        if (product.stock <= 0) { appMessage.value = "No hay stock"; return false }

        val current = currentUser.value
        val type = if (isWorker()) SellerType.WORKER else seller
        val commission = if (type == SellerType.WORKER) 5000.0 else 0.0
        val sellerName = when {
            isWorker() -> current?.displayName ?: "Trabajador"
            type == SellerType.WORKER -> "Trabajador"
            else -> current?.displayName ?: "Administrador"
        }
        val sellerUser = when {
            isWorker() -> current?.username ?: "trabajador"
            type == SellerType.WORKER -> "trabajador"
            else -> current?.username ?: "admin"
        }

        sales.add(
            Sale(
                id = (sales.maxOfOrNull { it.id } ?: 0) + 1,
                productName = product.name,
                price = product.salePrice,
                realCost = product.realCost,
                sellerType = type,
                sellerDisplayName = sellerName,
                sellerUsername = sellerUser,
                commission = commission,
                commissionPaid = false,
                profit = product.salePrice - product.realCost - commission,
                date = now()
            )
        )

        val i = products.indexOfFirst { it.id == product.id }
        if (i >= 0) products[i] = products[i].copy(stock = (products[i].stock - 1).coerceAtLeast(0))

        saveAll()
        appMessage.value = "Venta registrada"
        return true
    }

    fun payCommission(workerUsername: String): Boolean {
        if (!isAdmin()) return false

        val pending = sales.filter {
            it.sellerUsername == workerUsername && it.sellerType == SellerType.WORKER && !it.commissionPaid
        }

        if (pending.isEmpty()) {
            appMessage.value = "Sin comisión pendiente"
            return false
        }

        pending.forEach { sale ->
            val i = sales.indexOfFirst { it.id == sale.id }
            if (i >= 0) sales[i] = sales[i].copy(commissionPaid = true)
        }

        saveAll()
        appMessage.value = "Comisión pagada"
        return true
    }

    fun commissionUsers(): List<String> =
        sales.filter { it.sellerType == SellerType.WORKER && !it.commissionPaid }
            .map { it.sellerUsername }
            .distinct()

    fun commissionAmount(username: String): Double =
        sales.filter { it.sellerUsername == username && it.sellerType == SellerType.WORKER && !it.commissionPaid }
            .sumOf { it.commission }

    fun commissionSales(username: String): Int =
        sales.count { it.sellerUsername == username && it.sellerType == SellerType.WORKER && !it.commissionPaid }

    fun sellerName(username: String): String =
        sales.firstOrNull { it.sellerUsername == username }?.sellerDisplayName ?: username

    fun productAvailabilityText(product: Product): String {
        return when {
            product.stock <= 0 -> "Agotado por el momento"
            product.stock <= 1 -> "Última unidad disponible"
            else -> "Disponible para entrega inmediata"
        }
    }

    fun whatsappMessage(product: Product): String {
        return """✨ Nexo Moda

🛍 ${product.name}

💰 ${cop(product.salePrice)}

📦 ${productAvailabilityText(product)}

🚚 Envíos a todo Colombia.

📲 Haz tu pedido aquí:
https://wa.me/573052154226

🛡 Compra con confianza.
Atención personalizada y garantía en cada pedido."""
    }

    fun whatsappOfferMessage(product: Product): String {
        val urgency = when {
            product.stock <= 0 -> "Producto agotado por el momento"
            product.stock <= 1 -> "¡Última unidad disponible!"
            else -> "Disponible para entrega inmediata"
        }

        return """🔥 OFERTA ESPECIAL 🔥

✨ Nexo Moda

🛍 ${product.name}

💰 Solo ${cop(product.salePrice)}

📦 $urgency

🚚 Envíos a todo Colombia.

📲 Pídelo ahora:
https://wa.me/573052154226

🛡 Compra segura y atención personalizada."""
    }

    fun shareProduct(product: Product) {
        shareProductWithMessage(product, whatsappMessage(product))
    }

    fun shareProductOffer(product: Product) {
        shareProductWithMessage(product, whatsappOfferMessage(product))
    }

    fun copyProductText(product: Product) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Producto Nexo Moda", whatsappMessage(product)))
        appMessage.value = "Texto copiado"
    }

    private fun shareProductWithMessage(product: Product, message: String) {
        val firstPhoto = product.photoUri.split(";;").firstOrNull { it.isNotBlank() }

        if (firstPhoto != null) {
            val imageIntent = Intent(Intent.ACTION_SEND).apply {
                type = "image/*"
                putExtra(Intent.EXTRA_TEXT, message)
                putExtra(Intent.EXTRA_STREAM, Uri.parse(firstPhoto))
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                setPackage("com.whatsapp")
            }

            try {
                context.startActivity(imageIntent)
                return
            } catch (_: Exception) {
                try {
                    val chooser = Intent.createChooser(imageIntent.apply { setPackage(null) }, "Compartir producto")
                    chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(chooser)
                    return
                } catch (_: Exception) {}
            }
        }

        val textIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, message)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            setPackage("com.whatsapp")
        }

        try {
            context.startActivity(textIntent)
        } catch (_: Exception) {
            val fallback = Intent.createChooser(textIntent.apply { setPackage(null) }, "Compartir producto")
            fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(fallback)
        }
    }

    fun totalSales(): Double = sales.sumOf { it.price }
    fun totalProfit(): Double = sales.sumOf { it.profit }
    fun totalStock(): Int = products.sumOf { it.stock }
    fun investedCapital(): Double = products.sumOf { it.realCost * it.stock }
    fun recoveredCapital(): Double = sales.sumOf { it.realCost }
    fun workerCommissions(): Double = sales.filter { !it.commissionPaid }.sumOf { it.commission }
    fun soldOutProducts(): List<Product> = products.filter { it.stock <= 0 }
    fun lowStockProducts(): List<Product> = products.filter { it.stock in 1..it.minStock }

    private fun cop(value: Double): String = "$" + "%,.0f".format(value).replace(",", ".") + " COP"

    private fun saveAll() {
        prefs.edit()
            .putString("products", products.joinToString("\n") {
                listOf(it.id, it.name, it.category, it.internalCode, it.barcode, it.realCost, it.salePrice, it.stock, it.photoUri, it.minStock).joinToString("|")
            })
            .putString("sales", sales.joinToString("\n") {
                listOf(it.id, it.productName, it.price, it.realCost, it.sellerType.name, it.sellerDisplayName, it.sellerUsername, it.commission, it.commissionPaid, it.profit, it.date).joinToString("|")
            })
            .putString("users", users.joinToString("\n") {
                listOf(it.username, it.displayName, it.password, it.role.name, it.active).joinToString("|")
            })
            .apply()
    }

    private fun loadAll() {
        prefs.getString("products", "")!!.lines().filter { it.isNotBlank() }.forEach {
            val a = it.split("|")
            try {
                products.add(Product(a[0].toInt(), a[1], a[2], a[3], a[4], a[5].toDouble(), a[6].toDouble(), a[7].toInt(), a.getOrNull(8) ?: "", a.getOrNull(9)?.toIntOrNull() ?: 1))
            } catch (_: Exception) {}
        }

        prefs.getString("sales", "")!!.lines().filter { it.isNotBlank() }.forEach {
            val a = it.split("|")
            try {
                sales.add(Sale(a[0].toInt(), a[1], a[2].toDouble(), a[3].toDouble(), SellerType.valueOf(a[4]), a[5], a[6], a[7].toDouble(), a[8].toBoolean(), a[9].toDouble(), a[10]))
            } catch (_: Exception) {}
        }

        prefs.getString("users", "")!!.lines().filter { it.isNotBlank() }.forEach {
            val a = it.split("|")
            try {
                users.add(AppUser(a[0], a[1], a[2], UserRole.valueOf(a[3]), a[4].toBoolean()))
            } catch (_: Exception) {}
        }
    }
}
