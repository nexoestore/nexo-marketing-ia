package com.nexoerp.data

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NexoStore(context: Context){
    private val prefs=context.getSharedPreferences("nexo_erp_gen23",Context.MODE_PRIVATE)
    val products= mutableStateListOf<Product>()
    val sales= mutableStateListOf<Sale>()
    val purchases= mutableStateListOf<PurchaseLine>()
    val commissionPayments= mutableStateListOf<CommissionPayment>()
    val users= mutableStateListOf<AppUser>()
    val selectedTab= mutableStateOf(AppTab.DASHBOARD)
    val currentUser= mutableStateOf<AppUser?>(null)
    val loginError= mutableStateOf("")
    val appMessage= mutableStateOf("")

    init{
        loadAll()
        if(users.isEmpty()){
            users.add(AppUser("admin","Administrador","1234",UserRole.ADMIN,true))
            users.add(AppUser("trabajador","Trabajador","1234",UserRole.WORKER,true))
        }
        if(products.isEmpty()){
            products.add(Product(1,"Pijama Stitch Azul","Pijamas",27694.0,38000.0,6,1,"STITCH001",""))
            products.add(Product(2,"Pijama Daisy Rosada","Pijamas",34694.0,45000.0,1,1,"DAISY001",""))
            products.add(Product(3,"Pijama Garfield","Pijamas",31694.0,40000.0,1,1,"GARFIELD001",""))
        }
        saveAll()
    }

    private fun now():String=SimpleDateFormat("dd/MM/yyyy HH:mm",Locale.getDefault()).format(Date())

    fun login(username:String,password:String):Boolean{
        val u=users.firstOrNull{it.username.equals(username.trim(),true)&&it.password==password&&it.active}
        return if(u!=null){
            currentUser.value=u
            loginError.value=""
            appMessage.value="Bienvenido ${u.displayName}"
            true
        }else{
            loginError.value="Usuario, clave incorrectos o usuario inactivo"
            false
        }
    }

    fun logout(){currentUser.value=null;selectedTab.value=AppTab.DASHBOARD}
    fun isAdmin()=currentUser.value?.role==UserRole.ADMIN
    fun isWorker()=currentUser.value?.role==UserRole.WORKER

    fun registerUser(username:String,name:String,pass:String,confirm:String,role:UserRole):Boolean{
        val u=username.trim().lowercase()
        if(u.length<3){appMessage.value="Usuario mínimo 3 caracteres";return false}
        if(name.trim().length<3){appMessage.value="Nombre mínimo 3 caracteres";return false}
        if(pass.length<4){appMessage.value="Clave mínimo 4 caracteres";return false}
        if(pass!=confirm){appMessage.value="Las claves no coinciden";return false}
        if(users.any{it.username==u}){appMessage.value="Ese usuario ya existe";return false}
        users.add(AppUser(u,name.trim(),pass,role,true))
        saveAll()
        appMessage.value="Usuario creado"
        return true
    }

    fun toggleUser(username:String){
        if(!isAdmin())return
        val i=users.indexOfFirst{it.username==username}
        if(i>=0&&users[i].username!="admin"){
            users[i]=users[i].copy(active=!users[i].active)
            saveAll()
            appMessage.value="Usuario actualizado"
        }
    }

    fun addProduct(name:String,category:String,cost:Double,price:Double,stock:Int,barcode:String="",photo:String=""):Boolean{
        if(!isAdmin()){appMessage.value="Solo administrador";return false}
        if(name.trim().length<3||price<=0||cost<0||stock<0){appMessage.value="Revisa los datos";return false}
        val id=(products.maxOfOrNull{it.id}?:0)+1
        products.add(Product(id,name.trim(),category.ifBlank{"General"},cost,price,stock,1,barcode,photo))
        saveAll()
        appMessage.value="Producto guardado"
        return true
    }

    fun savePurchaseBatch(supplier:String,invoice:String,shipping:Double,items:List<DraftItem>):Boolean{
        if(!isAdmin()){appMessage.value="Solo administrador";return false}
        if(supplier.trim().length<2||items.isEmpty()){appMessage.value="Agrega proveedor y productos";return false}
        val totalUnits=items.sumOf{it.quantity}
        if(totalUnits<=0){appMessage.value="Cantidad inválida";return false}
        val shipPerUnit=shipping/totalUnits
        val batch=(purchases.maxOfOrNull{it.batchId}?:0)+1
        items.forEach{item->
            if(item.quantity>0&&item.unitCost>0&&item.salePrice>0&&item.productName.isNotBlank()){
                val real=item.unitCost+shipPerUnit
                val line=PurchaseLine(
                    id=(purchases.maxOfOrNull{it.id}?:0)+1,
                    batchId=batch,
                    supplier=supplier.trim(),
                    invoice=invoice.trim(),
                    productName=item.productName.trim(),
                    category=item.category.ifBlank{"General"},
                    quantity=item.quantity,
                    unitCost=item.unitCost,
                    shippingAssigned=shipPerUnit*item.quantity,
                    realUnitCost=real,
                    salePrice=item.salePrice,
                    total=(item.unitCost*item.quantity)+(shipPerUnit*item.quantity),
                    barcode=item.barcode,
                    photoUri=item.photoUri,
                    date=now()
                )
                purchases.add(line)
                upsertProductFromPurchase(line,item.quantity)
            }
        }
        saveAll()
        appMessage.value="Compra guardada y stock actualizado"
        return true
    }

    private fun upsertProductFromPurchase(line:PurchaseLine,qtyDelta:Int){
        val i=products.indexOfFirst{it.name.equals(line.productName,true) || (line.barcode.isNotBlank()&&it.barcode==line.barcode)}
        if(i>=0){
            val p=products[i]
            val newStock=(p.stock+qtyDelta).coerceAtLeast(0)
            val newCost=if(newStock>0)((p.realCost*p.stock)+(line.realUnitCost*qtyDelta))/newStock else line.realUnitCost
            products[i]=p.copy(category=line.category,realCost=newCost,salePrice=line.salePrice,stock=newStock,barcode=line.barcode.ifBlank{p.barcode},photoUri=line.photoUri.ifBlank{p.photoUri})
        }else{
            products.add(Product((products.maxOfOrNull{it.id}?:0)+1,line.productName,line.category,line.realUnitCost,line.salePrice,qtyDelta.coerceAtLeast(0),1,line.barcode,line.photoUri))
        }
    }

    fun editPurchaseQuantity(line:PurchaseLine,delta:Int):Boolean{
        if(!isAdmin())return false
        val i=purchases.indexOfFirst{it.id==line.id}
        if(i<0)return false
        val old=purchases[i]
        val newQty=old.quantity+delta
        if(newQty<=0)return deletePurchaseLine(old)
        val shipPerUnit=if(old.quantity>0)old.shippingAssigned/old.quantity else 0.0
        purchases[i]=old.copy(quantity=newQty,shippingAssigned=shipPerUnit*newQty,realUnitCost=old.unitCost+shipPerUnit,total=(old.unitCost*newQty)+(shipPerUnit*newQty))
        adjustProductStock(old.productName,delta)
        saveAll()
        appMessage.value="Compra editada"
        return true
    }

    fun deletePurchaseLine(line:PurchaseLine):Boolean{
        if(!isAdmin())return false
        purchases.removeAll{it.id==line.id}
        adjustProductStock(line.productName,-line.quantity)
        saveAll()
        appMessage.value="Producto eliminado de compra"
        return true
    }

    private fun adjustProductStock(name:String,delta:Int){
        val i=products.indexOfFirst{it.name.equals(name,true)}
        if(i>=0){
            val p=products[i]
            products[i]=p.copy(stock=(p.stock+delta).coerceAtLeast(0))
        }
    }

    fun adjustStock(p:Product,delta:Int):Boolean{
        if(!isAdmin())return false
        val i=products.indexOfFirst{it.id==p.id}
        if(i>=0){
            products[i]=products[i].copy(stock=(products[i].stock+delta).coerceAtLeast(0))
            saveAll()
            return true
        }
        return false
    }

    fun deleteProduct(p:Product):Boolean{
        if(!isAdmin())return false
        products.removeAll{it.id==p.id}
        saveAll()
        appMessage.value="Producto eliminado"
        return true
    }

    fun registerSale(p:Product,seller:SellerType):Boolean{
        if(p.stock<=0){appMessage.value="No hay stock";return false}
        val current=currentUser.value
        val type=if(isWorker())SellerType.WORKER else seller
        val sellerName=when{
            isWorker() -> current?.displayName ?: "Trabajador"
            type==SellerType.WORKER -> "Trabajador"
            else -> current?.displayName ?: "Administrador"
        }
        val sellerUser=when{
            isWorker() -> current?.username ?: "trabajador"
            type==SellerType.WORKER -> "trabajador"
            else -> current?.username ?: "admin"
        }
        val commission=if(type==SellerType.WORKER)5000.0 else 0.0
        val profit=p.salePrice-p.realCost-commission
        sales.add(Sale(
            id=(sales.maxOfOrNull{it.id}?:0)+1,
            productName=p.name,
            price=p.salePrice,
            realCost=p.realCost,
            sellerType=type,
            profit=profit,
            sellerUsername=sellerUser,
            sellerDisplayName=sellerName,
            commission=commission,
            commissionPaid=false,
            date=now()
        ))
        adjustProductStock(p.name,-1)
        saveAll()
        appMessage.value="Venta registrada"
        return true
    }

    fun payCommission(workerUsername:String):Boolean{
        if(!isAdmin())return false
        val pending=sales.filter{it.sellerUsername==workerUsername && it.sellerType==SellerType.WORKER && !it.commissionPaid}
        if(pending.isEmpty()){
            appMessage.value="No hay comisión pendiente"
            return false
        }
        val amount=pending.sumOf{it.commission}
        val name=pending.first().sellerDisplayName
        val pay=CommissionPayment(
            id=(commissionPayments.maxOfOrNull{it.id}?:0)+1,
            workerUsername=workerUsername,
            workerDisplayName=name,
            amount=amount,
            salesPaid=pending.size,
            date=now(),
            paidBy=currentUser.value?.displayName ?: "Administrador"
        )
        commissionPayments.add(pay)
        pending.forEach{sale->
            val i=sales.indexOfFirst{it.id==sale.id}
            if(i>=0)sales[i]=sales[i].copy(commissionPaid=true)
        }
        saveAll()
        appMessage.value="Comisión pagada a $name"
        return true
    }

    fun commissionSummaries():List<CommissionSummary>{
        return sales.filter{it.sellerType==SellerType.WORKER && !it.commissionPaid}
            .groupBy{it.sellerUsername}
            .map{(user,list)->CommissionSummary(user,list.first().sellerDisplayName,list.size,list.sumOf{it.commission})}
            .sortedByDescending{it.pendingAmount}
    }

    fun filteredProducts(q:String):List<Product>{
        val x=q.trim().lowercase()
        if(x.isBlank())return products
        return products.filter{it.name.lowercase().contains(x)||it.category.lowercase().contains(x)||it.barcode.lowercase().contains(x)}
    }

    fun supplierSummaries():List<SupplierSummary> = purchases.groupBy{it.supplier}.map{(s,ls)->SupplierSummary(s,ls.sumOf{it.total},ls.sumOf{it.quantity},ls.size)}.sortedByDescending{it.totalInvested}
    fun totalSales()=sales.sumOf{it.price}
    fun totalProfit()=sales.sumOf{it.profit}
    fun totalStock()=products.sumOf{it.stock}
    fun purchasedCapital()=purchases.sumOf{it.total}
    fun investedCapital()=products.sumOf{it.realCost*it.stock}
    fun recoveredCapital()=sales.sumOf{it.realCost}
    fun workerCommissions()=sales.filter{!it.commissionPaid}.sumOf{it.commission}
    fun paidCommissions()=commissionPayments.sumOf{it.amount}
    fun netProfit()=totalProfit()
    fun averageMargin()=if(products.isEmpty())0.0 else products.map{it.marginPercent}.average()
    fun lowStockProducts()=products.filter{it.stock in 1..it.minStock}
    fun soldOutProducts()=products.filter{it.stock<=0}

    fun exportPurchasesCsv()=buildString{appendLine("id,lote,proveedor,factura,producto,cantidad,costo,envio,costo_real,venta,total,barcode");purchases.forEach{appendLine("${it.id},${it.batchId},${it.supplier},${it.invoice},${it.productName},${it.quantity},${it.unitCost},${it.shippingAssigned},${it.realUnitCost},${it.salePrice},${it.total},${it.barcode}")}}
    fun exportInventoryCsv()=buildString{appendLine("id,nombre,categoria,costo,precio,stock,barcode,foto");products.forEach{appendLine("${it.id},${it.name},${it.category},${it.realCost},${it.salePrice},${it.stock},${it.barcode},${it.photoUri}")}}
    fun exportSalesCsv()=buildString{appendLine("id,producto,precio,costo,vendedor,usuario,comision,estado_comision,utilidad,fecha");sales.forEach{appendLine("${it.id},${it.productName},${it.price},${it.realCost},${it.sellerDisplayName},${it.sellerUsername},${it.commission},${if(it.commissionPaid)"PAGADA" else "PENDIENTE"},${it.profit},${it.date}")}}
    fun backupText()="COMPRAS\n${exportPurchasesCsv()}\nINVENTARIO\n${exportInventoryCsv()}\nVENTAS\n${exportSalesCsv()}"

    private fun saveAll(){
        prefs.edit()
            .putString("products",products.joinToString("\n"){listOf(it.id,it.name,it.category,it.realCost,it.salePrice,it.stock,it.minStock,it.barcode,it.photoUri).joinToString("|")})
            .putString("sales",sales.joinToString("\n"){listOf(it.id,it.productName,it.price,it.realCost,it.sellerType.name,it.profit,it.sellerUsername,it.sellerDisplayName,it.commission,it.commissionPaid,it.date).joinToString("|")})
            .putString("purchases",purchases.joinToString("\n"){listOf(it.id,it.batchId,it.supplier,it.invoice,it.productName,it.category,it.quantity,it.unitCost,it.shippingAssigned,it.realUnitCost,it.salePrice,it.total,it.barcode,it.photoUri,it.date).joinToString("|")})
            .putString("users",users.joinToString("\n"){listOf(it.username,it.displayName,it.password,it.role.name,it.active).joinToString("|")})
            .putString("payments",commissionPayments.joinToString("\n"){listOf(it.id,it.workerUsername,it.workerDisplayName,it.amount,it.salesPaid,it.date,it.paidBy).joinToString("|")})
            .apply()
    }

    private fun loadAll(){
        prefs.getString("products","")!!.lines().filter{it.isNotBlank()}.forEach{val a=it.split("|");try{products.add(Product(a[0].toInt(),a[1],a[2],a[3].toDouble(),a[4].toDouble(),a[5].toInt(),a.getOrNull(6)?.toIntOrNull()?:1,a.getOrNull(7)?:"",a.getOrNull(8)?:""))}catch(_:Exception){}}
        prefs.getString("sales","")!!.lines().filter{it.isNotBlank()}.forEach{val a=it.split("|");try{sales.add(Sale(a[0].toInt(),a[1],a[2].toDouble(),a[3].toDouble(),SellerType.valueOf(a[4]),a[5].toDouble(),a.getOrNull(6)?:"",a.getOrNull(7)?:a.getOrNull(6)?:"",a.getOrNull(8)?.toDoubleOrNull()?:0.0,a.getOrNull(9)?.toBoolean()?:false,a.getOrNull(10)?:""))}catch(_:Exception){}}
        prefs.getString("purchases","")!!.lines().filter{it.isNotBlank()}.forEach{val a=it.split("|");try{purchases.add(PurchaseLine(a[0].toInt(),a[1].toInt(),a[2],a[3],a[4],a[5],a[6].toInt(),a[7].toDouble(),a[8].toDouble(),a[9].toDouble(),a[10].toDouble(),a[11].toDouble(),a.getOrNull(12)?:"",a.getOrNull(13)?:"",a.getOrNull(14)?:""))}catch(_:Exception){}}
        prefs.getString("users","")!!.lines().filter{it.isNotBlank()}.forEach{val a=it.split("|");try{users.add(AppUser(a[0],a[1],a[2],UserRole.valueOf(a[3]),a[4].toBoolean()))}catch(_:Exception){}}
        prefs.getString("payments","")!!.lines().filter{it.isNotBlank()}.forEach{val a=it.split("|");try{commissionPayments.add(CommissionPayment(a[0].toInt(),a[1],a[2],a[3].toDouble(),a[4].toInt(),a[5],a[6]))}catch(_:Exception){}}
    }
}
