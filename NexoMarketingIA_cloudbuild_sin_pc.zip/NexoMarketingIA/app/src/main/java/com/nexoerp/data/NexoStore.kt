package com.nexoerp.data

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf

class NexoStore(context: Context) {
    private val storage = LocalStorage(context)

    val products = mutableStateListOf<Product>()
    val sales = mutableStateListOf<Sale>()
    val users = mutableStateListOf<AppUser>()
    val selectedTab = mutableStateOf(AppTab.DASHBOARD)
    val currentUser = mutableStateOf<AppUser?>(null)
    val loginError = mutableStateOf("")
    val appMessage = mutableStateOf("")

    init {
        val savedProducts = storage.loadProducts()
        val savedSales = storage.loadSales()
        val savedUsers = storage.loadUsers()
        products.addAll(if (savedProducts.isEmpty()) defaultProducts() else savedProducts)
        sales.addAll(savedSales)
        if (savedUsers.isEmpty()) {
            users.add(AppUser("admin", "Administrador", "1234", UserRole.ADMIN, true))
            users.add(AppUser("trabajador", "Trabajador", "1234", UserRole.WORKER, true))
            persistUsers()
        } else users.addAll(savedUsers)
        val last = storage.loadCurrentUsername()
        currentUser.value = users.firstOrNull { it.username == last && it.active }
        persistProducts()
    }

    private fun defaultProducts() = listOf(
        Product(1, "Pijama Stitch Azul", "Pijamas", 27694.0, 38000.0, 6),
        Product(2, "Pijama Daisy Rosada", "Pijamas", 34694.0, 45000.0, 1),
        Product(3, "Pijama Garfield", "Pijamas", 31694.0, 40000.0, 1)
    )

    fun login(username: String, password: String): Boolean {
        val u = username.trim().lowercase()
        val user = users.firstOrNull { it.username.lowercase() == u && it.password == password && it.active }
        return if (user != null) {
            currentUser.value = user; loginError.value = ""; appMessage.value = "Bienvenido ${user.displayName}"; storage.saveCurrentUsername(user.username); true
        } else { loginError.value = "Usuario, clave incorrectos o usuario inactivo"; false }
    }

    fun registerUser(username: String, displayName: String, password: String, confirmPassword: String, role: UserRole): Boolean {
        val cleanUser = username.trim().lowercase()
        if (cleanUser.length < 3) { appMessage.value = "El usuario debe tener mínimo 3 caracteres"; return false }
        if (displayName.trim().length < 3) { appMessage.value = "El nombre debe tener mínimo 3 caracteres"; return false }
        if (password.length < 4) { appMessage.value = "La clave debe tener mínimo 4 caracteres"; return false }
        if (password != confirmPassword) { appMessage.value = "Las claves no coinciden"; return false }
        if (users.any { it.username.lowercase() == cleanUser }) { appMessage.value = "Ese usuario ya existe"; return false }
        users.add(AppUser(cleanUser, displayName.trim(), password, role, true)); persistUsers(); appMessage.value = "Usuario creado correctamente"; return true
    }

    fun toggleUser(username: String) {
        if (!isAdmin()) return
        val i = users.indexOfFirst { it.username == username }
        if (i >= 0 && users[i].username != "admin") { users[i] = users[i].copy(active = !users[i].active); persistUsers(); appMessage.value = "Usuario actualizado" }
    }

    fun logout() { currentUser.value = null; selectedTab.value = AppTab.DASHBOARD; storage.saveCurrentUsername(null) }
    fun isAdmin() = currentUser.value?.role == UserRole.ADMIN
    fun isWorker() = currentUser.value?.role == UserRole.WORKER

    fun addProduct(name: String, category: String, realCost: Double, salePrice: Double, stock: Int): Boolean {
        if (!isAdmin()) { appMessage.value = "Solo administrador puede agregar productos"; return false }
        if (name.trim().length < 3) { appMessage.value = "El nombre debe tener mínimo 3 caracteres"; return false }
        if (realCost < 0.0 || salePrice <= 0.0 || stock < 0) { appMessage.value = "Revisa costo, precio y stock"; return false }
        if (salePrice <= realCost) { appMessage.value = "El precio de venta debe ser mayor al costo"; return false }
        val nextId = (products.maxOfOrNull { it.id } ?: 0) + 1
        products.add(Product(nextId, name.trim(), category.trim().ifBlank { "General" }, realCost, salePrice, stock))
        persistProducts(); appMessage.value = "Producto guardado correctamente"; return true
    }

    fun registerSale(product: Product, sellerType: SellerType): Boolean {
        if (product.stock <= 0) { appMessage.value = "No hay stock disponible"; return false }
        val forcedSeller = if (isWorker()) SellerType.WORKER else sellerType
        val commission = if (forcedSeller == SellerType.WORKER) 5000.0 else 0.0
        val profit = product.salePrice - product.realCost - commission
        sales.add(Sale(sales.size + 1, product.name, product.salePrice, product.realCost, forcedSeller, profit))
        val i = products.indexOfFirst { it.id == product.id }
        if (i >= 0) products[i] = products[i].copy(stock = (products[i].stock - 1).coerceAtLeast(0))
        persistProducts(); persistSales(); appMessage.value = "Venta registrada: ${product.name}"; return true
    }

    fun resetDemo() { if (!isAdmin()) return; products.clear(); sales.clear(); products.addAll(defaultProducts()); persistProducts(); persistSales(); appMessage.value = "Demo reiniciada" }
    fun filteredProducts(query: String): List<Product> { val q=query.trim().lowercase(); return if(q.isBlank()) products else products.filter { it.name.lowercase().contains(q)||it.category.lowercase().contains(q) } }
    fun totalSales()=sales.sumOf{it.price}
    fun totalProfit()=sales.sumOf{it.profit}
    fun totalStock()=products.sumOf{it.stock}
    fun investedCapital()=products.sumOf{it.realCost*it.stock}
    fun recoveredCapital()=sales.sumOf{it.realCost}
    fun lowStockProducts()=products.filter{it.stock<=it.minStock}
    fun workerCommissions()=sales.count{it.sellerType==SellerType.WORKER}*5000.0
    fun netProfit()=totalProfit()
    fun averageMargin()=if(products.isEmpty())0.0 else products.map{it.marginPercent}.average()
    fun exportInventoryCsv()=buildString{ appendLine("id,nombre,categoria,costo_real,precio_venta,stock,margen,ganancia_dueno,ganancia_trabajador"); products.forEach{appendLine("${it.id},${it.name},${it.category},${it.realCost},${it.salePrice},${it.stock},${it.marginPercent},${it.profitOwner},${it.profitWorker}")} }
    fun exportSalesCsv()=buildString{ appendLine("id,producto,precio,costo_real,vendedor,utilidad"); sales.forEach{appendLine("${it.id},${it.productName},${it.price},${it.realCost},${it.sellerType},${it.profit}")} }
    fun backupText()=buildString{ appendLine("=== NEXO ERP BACKUP ==="); appendLine("PRODUCTOS"); appendLine(exportInventoryCsv()); appendLine("VENTAS"); appendLine(exportSalesCsv()); appendLine("RESUMEN"); appendLine("Ventas: ${totalSales()}"); appendLine("Utilidad neta: ${netProfit()}"); appendLine("Capital inventario: ${investedCapital()}"); appendLine("Capital recuperado: ${recoveredCapital()}") }
    private fun persistProducts()=storage.saveProducts(products)
    private fun persistSales()=storage.saveSales(sales)
    private fun persistUsers()=storage.saveUsers(users)
}
