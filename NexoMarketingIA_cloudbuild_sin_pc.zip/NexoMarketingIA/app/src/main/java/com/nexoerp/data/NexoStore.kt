package com.nexoerp.data

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf

class NexoStore(context: Context) {
    private val storage = LocalStorage(context)

    val products = mutableStateListOf<Product>()
    val sales = mutableStateListOf<Sale>()
    val purchases = mutableStateListOf<Purchase>()
    val movements = mutableStateListOf<StockMovement>()
    val users = mutableStateListOf<AppUser>()

    val selectedTab = mutableStateOf(AppTab.DASHBOARD)
    val currentUser = mutableStateOf<AppUser?>(null)
    val loginError = mutableStateOf("")
    val appMessage = mutableStateOf("")

    init {
        val savedProducts = storage.loadProducts()
        val savedSales = storage.loadSales()
        val savedUsers = storage.loadUsers()
        val savedPurchases = storage.loadPurchases()
        val savedMovements = storage.loadMovements()

        products.addAll(if (savedProducts.isEmpty()) defaultProducts() else savedProducts)
        sales.addAll(savedSales)
        purchases.addAll(savedPurchases)
        movements.addAll(savedMovements)

        if (savedUsers.isEmpty()) {
            users.add(AppUser("admin", "Administrador", "1234", UserRole.ADMIN, true))
            users.add(AppUser("trabajador", "Trabajador", "1234", UserRole.WORKER, true))
            persistUsers()
        } else {
            users.addAll(savedUsers)
        }

        val lastUsername = storage.loadCurrentUsername()
        currentUser.value = users.firstOrNull { it.username == lastUsername && it.active }
        persistProducts()
    }

    private fun defaultProducts(): List<Product> = listOf(
        Product(1, "Pijama Stitch Azul", "Pijamas", 27694.0, 38000.0, 6),
        Product(2, "Pijama Daisy Rosada", "Pijamas", 34694.0, 45000.0, 1),
        Product(3, "Pijama Garfield", "Pijamas", 31694.0, 40000.0, 1)
    )

    private fun today(): String = System.currentTimeMillis().toString()

    fun login(username: String, password: String): Boolean {
        val normalized = username.trim().lowercase()
        val user = users.firstOrNull { it.username.lowercase() == normalized && it.password == password && it.active }
        return if (user != null) {
            currentUser.value = user
            loginError.value = ""
            appMessage.value = "Bienvenido ${user.displayName}"
            storage.saveCurrentUsername(user.username)
            true
        } else {
            loginError.value = "Usuario, clave incorrectos o usuario inactivo"
            false
        }
    }

    fun registerUser(username: String, displayName: String, password: String, confirmPassword: String, role: UserRole): Boolean {
        val cleanUser = username.trim().lowercase()
        if (cleanUser.length < 3) {
            appMessage.value = "El usuario debe tener mínimo 3 caracteres"
            return false
        }
        if (displayName.trim().length < 3) {
            appMessage.value = "El nombre debe tener mínimo 3 caracteres"
            return false
        }
        if (password.length < 4) {
            appMessage.value = "La clave debe tener mínimo 4 caracteres"
            return false
        }
        if (password != confirmPassword) {
            appMessage.value = "Las claves no coinciden"
            return false
        }
        if (users.any { it.username.lowercase() == cleanUser }) {
            appMessage.value = "Ese usuario ya existe"
            return false
        }

        users.add(AppUser(cleanUser, displayName.trim(), password, role, true))
        persistUsers()
        appMessage.value = "Usuario creado correctamente"
        return true
    }

    fun toggleUser(username: String) {
        if (!isAdmin()) return
        val index = users.indexOfFirst { it.username == username }
        if (index >= 0 && users[index].username != "admin") {
            val current = users[index]
            users[index] = current.copy(active = !current.active)
            persistUsers()
            appMessage.value = "Usuario actualizado"
        }
    }

    fun logout() {
        currentUser.value = null
        selectedTab.value = AppTab.DASHBOARD
        storage.saveCurrentUsername(null)
    }

    fun isAdmin(): Boolean = currentUser.value?.role == UserRole.ADMIN
    fun isWorker(): Boolean = currentUser.value?.role == UserRole.WORKER

    fun addProduct(name: String, category: String, realCost: Double, salePrice: Double, stock: Int): Boolean {
        if (!isAdmin()) {
            appMessage.value = "Solo administrador puede agregar productos"
            return false
        }
        if (name.trim().length < 3) {
            appMessage.value = "El nombre debe tener mínimo 3 caracteres"
            return false
        }
        if (realCost < 0.0 || salePrice <= 0.0 || stock < 0) {
            appMessage.value = "Revisa costo, precio y stock"
            return false
        }
        if (salePrice <= realCost) {
            appMessage.value = "El precio de venta debe ser mayor al costo"
            return false
        }

        val nextId = (products.maxOfOrNull { it.id } ?: 0) + 1
        products.add(Product(nextId, name.trim(), category.trim().ifBlank { "General" }, realCost, salePrice, stock))
        if (stock > 0) addMovement(name.trim(), stock, "ENTRADA", "Creación manual")
        persistProducts()
        appMessage.value = "Producto guardado correctamente"
        return true
    }

    fun registerPurchase(supplier: String, productName: String, category: String, quantity: Int, unitCost: Double, shippingCost: Double, salePrice: Double): Boolean {
        if (!isAdmin()) {
            appMessage.value = "Solo administrador puede registrar compras"
            return false
        }
        if (productName.trim().length < 3 || supplier.trim().length < 2) {
            appMessage.value = "Completa proveedor y producto"
            return false
        }
        if (quantity <= 0 || unitCost <= 0.0 || shippingCost < 0.0 || salePrice <= 0.0) {
            appMessage.value = "Revisa cantidad, costo, envío y precio"
            return false
        }

        val realUnitCost = unitCost + (shippingCost / quantity)
        val total = (unitCost * quantity) + shippingCost
        val purchase = Purchase(
            id = (purchases.maxOfOrNull { it.id } ?: 0) + 1,
            supplier = supplier.trim(),
            productName = productName.trim(),
            quantity = quantity,
            unitCost = unitCost,
            shippingCost = shippingCost,
            realUnitCost = realUnitCost,
            salePrice = salePrice,
            total = total,
            date = today()
        )
        purchases.add(purchase)

        val index = products.indexOfFirst { it.name.trim().lowercase() == productName.trim().lowercase() }
        if (index >= 0) {
            val current = products[index]
            val newStock = current.stock + quantity
            val weightedCost = if (newStock > 0) ((current.realCost * current.stock) + (realUnitCost * quantity)) / newStock else realUnitCost
            products[index] = current.copy(
                category = category.trim().ifBlank { current.category },
                realCost = weightedCost,
                salePrice = salePrice,
                stock = newStock
            )
        } else {
            val nextId = (products.maxOfOrNull { it.id } ?: 0) + 1
            products.add(Product(nextId, productName.trim(), category.trim().ifBlank { "General" }, realUnitCost, salePrice, quantity))
        }

        addMovement(productName.trim(), quantity, "COMPRA", "Compra a ${supplier.trim()}")
        persistPurchases()
        persistProducts()
        appMessage.value = "Compra registrada y stock actualizado"
        return true
    }

    fun adjustStock(product: Product, change: Int, reason: String): Boolean {
        if (!isAdmin()) {
            appMessage.value = "Solo administrador puede ajustar stock"
            return false
        }
        val index = products.indexOfFirst { it.id == product.id }
        if (index < 0) return false
        val current = products[index]
        val newStock = current.stock + change
        if (newStock < 0) {
            appMessage.value = "No puedes dejar stock negativo"
            return false
        }
        products[index] = current.copy(stock = newStock)
        addMovement(current.name, change, if (change >= 0) "AJUSTE_ENTRADA" else "AJUSTE_SALIDA", reason)
        persistProducts()
        appMessage.value = "Stock actualizado"
        return true
    }

    fun deleteProduct(product: Product): Boolean {
        if (!isAdmin()) {
            appMessage.value = "Solo administrador puede eliminar productos"
            return false
        }
        products.removeAll { it.id == product.id }
        addMovement(product.name, -product.stock, "ELIMINADO", "Producto eliminado")
        persistProducts()
        appMessage.value = "Producto eliminado"
        return true
    }

    private fun addMovement(productName: String, quantity: Int, type: String, reason: String) {
        movements.add(StockMovement((movements.maxOfOrNull { it.id } ?: 0) + 1, productName, quantity, type, reason, today()))
        persistMovements()
    }

    fun registerSale(product: Product, sellerType: SellerType): Boolean {
        if (product.stock <= 0) {
            appMessage.value = "No hay stock disponible"
            return false
        }

        val forcedSeller = if (isWorker()) SellerType.WORKER else sellerType
        val commission = if (forcedSeller == SellerType.WORKER) 5000.0 else 0.0
        val profit = product.salePrice - product.realCost - commission

        sales.add(Sale(sales.size + 1, product.name, product.salePrice, product.realCost, forcedSeller, profit))

        val index = products.indexOfFirst { it.id == product.id }
        if (index >= 0) {
            val current = products[index]
            products[index] = current.copy(stock = (current.stock - 1).coerceAtLeast(0))
        }

        addMovement(product.name, -1, "VENTA", "Venta registrada")
        persistProducts()
        persistSales()
        appMessage.value = "Venta registrada: ${product.name}"
        return true
    }

    fun resetDemo() {
        if (!isAdmin()) return
        products.clear()
        sales.clear()
        purchases.clear()
        movements.clear()
        products.addAll(defaultProducts())
        persistProducts()
        persistSales()
        persistPurchases()
        persistMovements()
        appMessage.value = "Demo reiniciada"
    }

    fun filteredProducts(query: String): List<Product> {
        val q = query.trim().lowercase()
        if (q.isBlank()) return products
        return products.filter { it.name.lowercase().contains(q) || it.category.lowercase().contains(q) }
    }

    fun totalSales(): Double = sales.sumOf { it.price }
    fun totalProfit(): Double = sales.sumOf { it.profit }
    fun totalStock(): Int = products.sumOf { it.stock }
    fun purchasedCapital(): Double = purchases.sumOf { it.total }
    fun investedCapital(): Double = products.sumOf { it.realCost * it.stock }
    fun recoveredCapital(): Double = sales.sumOf { it.realCost }
    fun lowStockProducts(): List<Product> = products.filter { it.stock <= it.minStock }
    fun workerCommissions(): Double = sales.count { it.sellerType == SellerType.WORKER } * 5000.0
    fun netProfit(): Double = totalProfit()
    fun averageMargin(): Double = if (products.isEmpty()) 0.0 else products.map { it.marginPercent }.average()

    fun exportInventoryCsv(): String = buildString {
        appendLine("id,nombre,categoria,costo_real,precio_venta,stock,margen,ganancia_dueno,ganancia_trabajador")
        products.forEach {
            appendLine("${it.id},${it.name},${it.category},${it.realCost},${it.salePrice},${it.stock},${it.marginPercent},${it.profitOwner},${it.profitWorker}")
        }
    }

    fun exportSalesCsv(): String = buildString {
        appendLine("id,producto,precio,costo_real,vendedor,utilidad")
        sales.forEach { appendLine("${it.id},${it.productName},${it.price},${it.realCost},${it.sellerType},${it.profit}") }
    }

    fun exportPurchasesCsv(): String = buildString {
        appendLine("id,proveedor,producto,cantidad,costo_unitario,envio,costo_real_unitario,precio_venta,total,fecha")
        purchases.forEach { appendLine("${it.id},${it.supplier},${it.productName},${it.quantity},${it.unitCost},${it.shippingCost},${it.realUnitCost},${it.salePrice},${it.total},${it.date}") }
    }

    fun backupText(): String = buildString {
        appendLine("=== NEXO ERP BACKUP ===")
        appendLine("COMPRAS")
        appendLine(exportPurchasesCsv())
        appendLine("PRODUCTOS")
        appendLine(exportInventoryCsv())
        appendLine("VENTAS")
        appendLine(exportSalesCsv())
        appendLine("RESUMEN")
        appendLine("Capital comprado: ${purchasedCapital()}")
        appendLine("Capital en inventario: ${investedCapital()}")
        appendLine("Capital recuperado: ${recoveredCapital()}")
        appendLine("Ventas: ${totalSales()}")
        appendLine("Utilidad neta: ${netProfit()}")
    }

    private fun persistProducts() = storage.saveProducts(products)
    private fun persistSales() = storage.saveSales(sales)
    private fun persistPurchases() = storage.savePurchases(purchases)
    private fun persistMovements() = storage.saveMovements(movements)
    private fun persistUsers() = storage.saveUsers(users)
}
