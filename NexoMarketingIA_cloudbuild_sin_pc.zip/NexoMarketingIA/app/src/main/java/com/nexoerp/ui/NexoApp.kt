package com.nexoerp.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.nexoerp.data.*

@Composable
fun NexoApp() {
    val context = LocalContext.current
    val store = remember { NexoStore(context) }
    val user by store.currentUser
    if (user == null) AuthScreen(store) else MainContent(store)
}

@Composable
fun AuthScreen(store: NexoStore) {
    var registerMode by remember { mutableStateOf(false) }
    if (registerMode) RegisterScreen(store) { registerMode = false }
    else LoginScreen(store) { registerMode = true }
}

@Composable
fun LoginScreen(store: NexoStore, onRegister: () -> Unit) {
    var username by remember { mutableStateOf("admin") }
    var password by remember { mutableStateOf("1234") }
    val error by store.loginError
    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("Nexo ERP", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Text("Administra. Vende. Crece.")
            Spacer(Modifier.height(24.dp))
            OutlinedTextField(username, { username = it }, label = { Text("Usuario") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(password, { password = it }, label = { Text("Clave") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp))
            Spacer(Modifier.height(16.dp))
            Button(onClick = { store.login(username, password) }, modifier = Modifier.fillMaxWidth()) { Text("Entrar") }
            TextButton(onClick = onRegister) { Text("Crear usuario nuevo") }
            Spacer(Modifier.height(12.dp))
            Text("Admin inicial: admin / 1234")
        }
    }
}

@Composable
fun RegisterScreen(store: NexoStore, onBack: () -> Unit) {
    var username by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var admin by remember { mutableStateOf(false) }
    val msg by store.appMessage
    Surface(Modifier.fillMaxSize()) {
        LazyColumn(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            item {
                Spacer(Modifier.height(40.dp))
                Text("Crear usuario", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                Text("Registra un administrador o trabajador")
                Spacer(Modifier.height(16.dp))
                OutlinedTextField(username, { username = it }, label = { Text("Usuario") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(name, { name = it }, label = { Text("Nombre completo") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(pass, { pass = it }, label = { Text("Clave") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                OutlinedTextField(confirm, { confirm = it }, label = { Text("Confirmar clave") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = admin, onCheckedChange = { admin = it })
                    Text("Crear como administrador")
                }
                if (msg.isNotBlank()) Text(msg, color = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(12.dp))
                Button(
                    onClick = {
                        val ok = store.registerUser(username, name, pass, confirm, if (admin) UserRole.ADMIN else UserRole.WORKER)
                        if (ok) onBack()
                    },
                    modifier = Modifier.fillMaxWidth()
                ) { Text("Crear usuario") }
                TextButton(onClick = onBack) { Text("Volver al login") }
            }
        }
    }
}

@Composable
fun MainContent(store: NexoStore) {
    val tab by store.selectedTab
    val user by store.currentUser
    val msg by store.appMessage

    Scaffold(
        topBar = {
            Surface(shadowElevation = 2.dp) {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text("Nexo ERP 1.2", fontWeight = FontWeight.Bold)
                            Text("${user?.displayName} • ${user?.role}")
                        }
                        TextButton(onClick = { store.logout() }) { Text("Salir") }
                    }
                    if (msg.isNotBlank()) AssistChip(onClick = {}, label = { Text(msg) })
                }
            }
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(tab == AppTab.DASHBOARD, { store.selectedTab.value = AppTab.DASHBOARD }, { Text("🏠") }, label = { Text("Inicio") })
                NavigationBarItem(tab == AppTab.INVENTORY, { store.selectedTab.value = AppTab.INVENTORY }, { Text("📦") }, label = { Text("Inventario") })
                if (store.isAdmin()) NavigationBarItem(tab == AppTab.PURCHASES, { store.selectedTab.value = AppTab.PURCHASES }, { Text("🧾") }, label = { Text("Compras") })
                NavigationBarItem(tab == AppTab.SALES, { store.selectedTab.value = AppTab.SALES }, { Text("💰") }, label = { Text("Ventas") })
                NavigationBarItem(tab == AppTab.AI, { store.selectedTab.value = AppTab.AI }, { Text("🤖") }, label = { Text("IA") })
                NavigationBarItem(tab == AppTab.REPORTS, { store.selectedTab.value = AppTab.REPORTS }, { Text("📊") }, label = { Text("Reportes") })
                if (store.isAdmin()) NavigationBarItem(tab == AppTab.USERS, { store.selectedTab.value = AppTab.USERS }, { Text("👥") }, label = { Text("Usuarios") })
                NavigationBarItem(tab == AppTab.SETTINGS, { store.selectedTab.value = AppTab.SETTINGS }, { Text("⚙️") }, label = { Text("Config") })
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding)) {
            when (tab) {
                AppTab.DASHBOARD -> DashboardScreen(store)
                AppTab.INVENTORY -> InventoryScreen(store)
                AppTab.PURCHASES -> PurchasesScreen(store)
                AppTab.SALES -> SalesScreen(store)
                AppTab.AI -> AiScreen(store)
                AppTab.REPORTS -> ReportsScreen(store)
                AppTab.USERS -> UsersScreen(store)
                AppTab.SETTINGS -> SettingsScreen(store)
            }
        }
    }
}

@Composable
fun Header(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(16.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(subtitle, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
fun MetricCard(title: String, value: String, emoji: String) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(emoji, style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun DashboardScreen(store: NexoStore) {
    LazyColumn {
        item { Header("Dashboard", "Resumen general de tu negocio") }
        item { MetricCard("Ventas registradas", cop(store.totalSales()), "💰") }
        item { MetricCard("Ganancia registrada", cop(store.totalProfit()), "📈") }
        item { MetricCard("Comisiones trabajador", cop(store.workerCommissions()), "👤") }
        item { MetricCard("Stock disponible", "${store.totalStock()} prendas", "📦") }
        item { MetricCard("Capital comprado", cop(store.purchasedCapital()), "🧾") }
        item { MetricCard("Capital en inventario", cop(store.investedCapital()), "🏦") }
        item { MetricCard("Capital recuperado", cop(store.recoveredCapital()), "✅") }
        item { MetricCard("Margen promedio", "%.1f%%".format(store.averageMargin()), "📊") }
        val lowStock = store.lowStockProducts()
        if (lowStock.isNotEmpty()) {
            item { Text("⚠️ Alertas de stock", Modifier.padding(16.dp), fontWeight = FontWeight.Bold) }
            items(lowStock) { product ->
                Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)) {
                    Text("Solo quedan ${product.stock}: ${product.name}", Modifier.padding(16.dp))
                }
            }
        }
    }
}

@Composable
fun InventoryScreen(store: NexoStore) {
    var showForm by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    LazyColumn {
        item { Header("Inventario", "Productos disponibles en Nexo Moda") }
        item { OutlinedTextField(query, { query = it }, label = { Text("Buscar producto") }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) }
        if (store.isAdmin()) {
            item {
                Button(onClick = { showForm = !showForm }, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp).fillMaxWidth()) {
                    Text(if (showForm) "Cerrar formulario" else "Agregar producto manual")
                }
            }
        } else item { Text("Modo trabajador: no verás costos ni ganancias.", Modifier.padding(16.dp)) }
        if (showForm && store.isAdmin()) item { AddProductForm(store) }
        items(store.filteredProducts(query)) { product -> ProductCard(product, store) }
    }
}

@Composable
fun AddProductForm(store: NexoStore) {
    var name by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Pijamas") }
    var cost by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var stock by remember { mutableStateOf("") }
    Card(Modifier.fillMaxWidth().padding(16.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text("Nuevo producto manual", fontWeight = FontWeight.Bold)
            OutlinedTextField(name, { name = it }, label = { Text("Nombre") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(category, { category = it }, label = { Text("Categoría") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(cost, { cost = it.filter { ch -> ch.isDigit() || ch == '.' } }, label = { Text("Costo real") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(price, { price = it.filter { ch -> ch.isDigit() || ch == '.' } }, label = { Text("Precio venta") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(stock, { stock = it.filter { ch -> ch.isDigit() } }, label = { Text("Stock") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Button(onClick = {
                val c = cost.toDoubleOrNull() ?: -1.0
                val p = price.toDoubleOrNull() ?: 0.0
                val s = stock.toIntOrNull() ?: -1
                if (store.addProduct(name, category, c, p, s)) { name = ""; cost = ""; price = ""; stock = "" }
            }, modifier = Modifier.fillMaxWidth()) { Text("Guardar producto") }
        }
    }
}

@Composable
fun ProductCard(product: Product, store: NexoStore) {
    val admin = store.isAdmin()
    val stockLabel = when {
        product.stock <= 0 -> "Agotado"
        product.stock <= product.minStock -> "Última unidad"
        product.stock <= 3 -> "Stock bajo"
        else -> "Disponible"
    }
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(product.name, fontWeight = FontWeight.Bold)
                AssistChip(onClick = {}, label = { Text(stockLabel) })
            }
            Text(product.category)
            Text("Precio venta: ${cop(product.salePrice)}")
            Text("Stock: ${product.stock}")
            if (admin) {
                Text("Costo real: ${cop(product.realCost)}")
                Text("Margen: ${"%.1f".format(product.marginPercent)}%")
                Text("Ganancia si vendes tú: ${cop(product.profitOwner)}")
                Text("Ganancia si vende trabajador: ${cop(product.profitWorker)}")
                Spacer(Modifier.height(8.dp))
                Row {
                    OutlinedButton(onClick = { store.adjustStock(product, 1, "Ajuste manual +1") }) { Text("+1") }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton(onClick = { store.adjustStock(product, -1, "Ajuste manual -1") }) { Text("-1") }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton(onClick = { store.deleteProduct(product) }) { Text("Eliminar") }
                }
            }
        }
    }
}

@Composable
fun PurchasesScreen(store: NexoStore) {
    var supplier by remember { mutableStateOf("") }
    var product by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Pijamas") }
    var qty by remember { mutableStateOf("") }
    var unitCost by remember { mutableStateOf("") }
    var shipping by remember { mutableStateOf("") }
    var salePrice by remember { mutableStateOf("") }

    LazyColumn {
        item { Header("Compras", "Registra pedidos a proveedores y sube stock") }
        item {
            Card(Modifier.fillMaxWidth().padding(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Nueva compra", fontWeight = FontWeight.Bold)
                    OutlinedTextField(supplier, { supplier = it }, label = { Text("Proveedor") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(product, { product = it }, label = { Text("Producto") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(category, { category = it }, label = { Text("Categoría") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(qty, { qty = it.filter { ch -> ch.isDigit() } }, label = { Text("Cantidad") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(unitCost, { unitCost = it.filter { ch -> ch.isDigit() || ch == '.' } }, label = { Text("Costo unitario proveedor") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(shipping, { shipping = it.filter { ch -> ch.isDigit() || ch == '.' } }, label = { Text("Envío total de esta compra") }, modifier = Modifier.fillMaxWidth())
                    OutlinedTextField(salePrice, { salePrice = it.filter { ch -> ch.isDigit() || ch == '.' } }, label = { Text("Precio de venta") }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = {
                        val q = qty.toIntOrNull() ?: 0
                        val c = unitCost.toDoubleOrNull() ?: 0.0
                        val e = shipping.toDoubleOrNull() ?: 0.0
                        val p = salePrice.toDoubleOrNull() ?: 0.0
                        if (store.registerPurchase(supplier, product, category, q, c, e, p)) {
                            supplier = ""; product = ""; qty = ""; unitCost = ""; shipping = ""; salePrice = ""
                        }
                    }, modifier = Modifier.fillMaxWidth()) { Text("Guardar compra y subir stock") }
                }
            }
        }
        item { Text("Historial de compras", Modifier.padding(16.dp), fontWeight = FontWeight.Bold) }
        items(store.purchases.reversed()) { p ->
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("#${p.id} ${p.productName}", fontWeight = FontWeight.Bold)
                    Text("Proveedor: ${p.supplier}")
                    Text("Cantidad: ${p.quantity}")
                    Text("Costo proveedor: ${cop(p.unitCost)}")
                    Text("Envío: ${cop(p.shippingCost)}")
                    Text("Costo real unitario: ${cop(p.realUnitCost)}")
                    Text("Total compra: ${cop(p.total)}")
                }
            }
        }
    }
}

@Composable
fun SalesScreen(store: NexoStore) {
    var query by remember { mutableStateOf("") }
    LazyColumn {
        item { Header("Ventas", "Registra ventas rápidas") }
        item { OutlinedTextField(query, { query = it }, label = { Text("Buscar producto para vender") }, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) }
        items(store.filteredProducts(query).filter { it.stock > 0 }) { product ->
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(product.name, fontWeight = FontWeight.Bold)
                    Text("Precio: ${cop(product.salePrice)}")
                    Text("Stock: ${product.stock}")
                    Spacer(Modifier.height(8.dp))
                    if (store.isAdmin()) {
                        Row {
                            Button(onClick = { store.registerSale(product, SellerType.OWNER) }) { Text("Vendí yo") }
                            Spacer(Modifier.width(8.dp))
                            OutlinedButton(onClick = { store.registerSale(product, SellerType.WORKER) }) { Text("Trabajador") }
                        }
                    } else {
                        Button(onClick = { store.registerSale(product, SellerType.WORKER) }, modifier = Modifier.fillMaxWidth()) { Text("Registrar mi venta") }
                    }
                }
            }
        }
        item { Text("Historial de ventas", Modifier.padding(16.dp), fontWeight = FontWeight.Bold) }
        items(store.sales.reversed()) { sale ->
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(sale.productName, fontWeight = FontWeight.Bold)
                    Text("Vendido por: ${if (sale.sellerType == SellerType.OWNER) "Yo" else "Trabajador"}")
                    Text("Precio: ${cop(sale.price)}")
                    if (store.isAdmin()) Text("Utilidad: ${cop(sale.profit)}")
                }
            }
        }
    }
}

@Composable
fun AiScreen(store: NexoStore) {
    val best = store.products.maxByOrNull { it.profitOwner }
    val low = store.lowStockProducts().firstOrNull()
    LazyColumn {
        item { Header("Nexo IA", "Recomendaciones comerciales") }
        item {
            Card(Modifier.fillMaxWidth().padding(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("¿Qué debo publicar hoy?", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(when {
                        low != null -> "Publica ${low.name} como ÚLTIMA UNIDAD para generar urgencia."
                        best != null -> "Publica ${best.name}, tiene una buena ganancia estimada."
                        else -> "Agrega productos al inventario para recibir recomendaciones."
                    })
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth().padding(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Prompt Veo 3 sugerido", fontWeight = FontWeight.Bold)
                    Text("Create a realistic vertical commercial video (9:16). Keep the product exactly the same. Professional fashion advertising for Nexo Moda.")
                }
            }
        }
    }
}

@Composable
fun ReportsScreen(store: NexoStore) {
    val clipboard = LocalClipboardManager.current
    var selectedReport by remember { mutableStateOf("Selecciona una opción para copiar un reporte.") }
    LazyColumn {
        item { Header("Reportes", "Exportación y resumen financiero") }
        item { MetricCard("Ventas", cop(store.totalSales()), "💰") }
        if (store.isAdmin()) {
            item { MetricCard("Capital comprado", cop(store.purchasedCapital()), "🧾") }
            item { MetricCard("Utilidad neta", cop(store.netProfit()), "📈") }
            item { MetricCard("Comisiones", cop(store.workerCommissions()), "👤") }
            item { MetricCard("Capital en inventario", cop(store.investedCapital()), "🏦") }
            item { MetricCard("Capital recuperado", cop(store.recoveredCapital()), "✅") }
        }
        item {
            Card(Modifier.fillMaxWidth().padding(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Exportar datos", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    if (store.isAdmin()) Button(onClick = { selectedReport = store.exportPurchasesCsv() }, modifier = Modifier.fillMaxWidth()) { Text("Generar CSV compras") }
                    Spacer(Modifier.height(8.dp))
                    if (store.isAdmin()) Button(onClick = { selectedReport = store.exportInventoryCsv() }, modifier = Modifier.fillMaxWidth()) { Text("Generar CSV inventario") }
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { selectedReport = store.exportSalesCsv() }, modifier = Modifier.fillMaxWidth()) { Text("Generar CSV ventas") }
                    Spacer(Modifier.height(8.dp))
                    if (store.isAdmin()) OutlinedButton(onClick = { selectedReport = store.backupText() }, modifier = Modifier.fillMaxWidth()) { Text("Generar copia de seguridad") }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { clipboard.setText(AnnotatedString(selectedReport)) }, modifier = Modifier.fillMaxWidth()) { Text("Copiar reporte") }
                }
            }
        }
        item { Card(Modifier.fillMaxWidth().padding(16.dp)) { Text(selectedReport, Modifier.padding(16.dp)) } }
    }
}

@Composable
fun UsersScreen(store: NexoStore) {
    var showForm by remember { mutableStateOf(false) }
    LazyColumn {
        item { Header("Usuarios", "Administradores y trabajadores") }
        item { Button(onClick = { showForm = !showForm }, modifier = Modifier.padding(16.dp).fillMaxWidth()) { Text(if (showForm) "Cerrar formulario" else "Crear usuario") } }
        if (showForm) item { CreateUserCard(store) }
        items(store.users) { user ->
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(user.displayName, fontWeight = FontWeight.Bold)
                    Text("Usuario: ${user.username}")
                    Text("Rol: ${user.role}")
                    Text("Estado: ${if (user.active) "Activo" else "Inactivo"}")
                    if (user.username != "admin") {
                        OutlinedButton(onClick = { store.toggleUser(user.username) }) {
                            Text(if (user.active) "Desactivar" else "Activar")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun CreateUserCard(store: NexoStore) {
    var username by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var admin by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth().padding(16.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text("Nuevo usuario", fontWeight = FontWeight.Bold)
            OutlinedTextField(username, { username = it }, label = { Text("Usuario") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(name, { name = it }, label = { Text("Nombre") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(pass, { pass = it }, label = { Text("Clave") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(confirm, { confirm = it }, label = { Text("Confirmar clave") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(admin, { admin = it })
                Text("Administrador")
            }
            Button(onClick = { store.registerUser(username, name, pass, confirm, if (admin) UserRole.ADMIN else UserRole.WORKER) }, modifier = Modifier.fillMaxWidth()) { Text("Crear usuario") }
        }
    }
}

@Composable
fun SettingsScreen(store: NexoStore) {
    LazyColumn {
        item { Header("Configuración", "Usuarios y opciones del sistema") }
        item {
            Card(Modifier.fillMaxWidth().padding(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Sesión activa", fontWeight = FontWeight.Bold)
                    Text("Usuario: ${store.currentUser.value?.displayName}")
                    Text("Rol: ${store.currentUser.value?.role}")
                    Text("Versión: 1.2.0")
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { store.logout() }, modifier = Modifier.fillMaxWidth()) { Text("Cerrar sesión") }
                }
            }
        }
        if (store.isAdmin()) {
            item {
                Card(Modifier.fillMaxWidth().padding(16.dp)) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Herramientas administrador", fontWeight = FontWeight.Bold)
                        Text("Reinicia productos, compras y ventas demo.")
                        Spacer(Modifier.height(8.dp))
                        OutlinedButton(onClick = { store.resetDemo() }, modifier = Modifier.fillMaxWidth()) { Text("Reiniciar demo") }
                    }
                }
            }
        }
    }
}

fun cop(value: Double): String = "$" + "%,.0f".format(value).replace(",", ".") + " COP"
