package com.nexoerp.ui

import android.content.Intent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.nexoerp.data.*

@Composable
fun NexoApp() {
    val context = LocalContext.current
    val store = remember { NexoStore(context) }
    val user by store.currentUser
    if (user == null) AuthScreen(store) else MainContent(store)
}

@Composable
fun AuthScreen(store: NexoStore) {
    var registerMode by remember { mutableStateOf(false) }
    if (registerMode) RegisterScreen(store) { registerMode = false }
    else LoginScreen(store) { registerMode = true }
}

@Composable
fun LoginScreen(store: NexoStore, onRegister: () -> Unit) {
    var username by remember { mutableStateOf("admin") }
    var password by remember { mutableStateOf("1234") }
    val error by store.loginError

    Surface(Modifier.fillMaxSize()) {
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text("Nexo Manager", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Text("Administra. Vende. Crece.")
            Spacer(Modifier.height(24.dp))
            OutlinedTextField(username, { username = it }, label = { Text("Usuario") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(password, { password = it }, label = { Text("Clave") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            if (error.isNotBlank()) Text(error, color = MaterialTheme.colorScheme.error)
            Spacer(Modifier.height(12.dp))
            Button(onClick = { store.login(username, password) }, modifier = Modifier.fillMaxWidth()) { Text("Entrar") }
            TextButton(onClick = onRegister) { Text("Crear usuario nuevo") }
        }
    }
}

@Composable
fun RegisterScreen(store: NexoStore, onBack: () -> Unit) {
    var username by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var admin by remember { mutableStateOf(false) }

    LazyColumn(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        item {
            Text("Crear usuario", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            OutlinedTextField(username, { username = it }, label = { Text("Usuario") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(name, { name = it }, label = { Text("Nombre") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(pass, { pass = it }, label = { Text("Clave") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(confirm, { confirm = it }, label = { Text("Confirmar") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(admin, { admin = it })
                Text("Administrador")
            }
            Button(
                onClick = {
                    if (store.registerUser(username, name, pass, confirm, if (admin) UserRole.ADMIN else UserRole.WORKER)) onBack()
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Crear") }
            TextButton(onClick = onBack) { Text("Volver") }
        }
    }
}

@Composable
fun MainContent(store: NexoStore) {
    val tab by store.selectedTab
    val user by store.currentUser
    val msg by store.appMessage

    Scaffold(
        topBar = {
            Surface(shadowElevation = 2.dp) {
                Column(Modifier.fillMaxWidth().padding(12.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text("Nexo Manager 2.7", fontWeight = FontWeight.Bold)
                            Text("${user?.displayName} • ${user?.role}")
                        }
                        TextButton(onClick = { store.logout() }) { Text("Salir") }
                    }
                    if (msg.isNotBlank()) AssistChip(onClick = {}, label = { Text(msg) })
                }
            }
        },
        bottomBar = {
            NavigationBar {
                NavigationBarItem(tab == AppTab.DASHBOARD, { store.selectedTab.value = AppTab.DASHBOARD }, { Text("🏠") }, label = { Text("Inicio") })
                NavigationBarItem(tab == AppTab.INVENTORY, { store.selectedTab.value = AppTab.INVENTORY }, { Text("📦") }, label = { Text("Inventario") })
                NavigationBarItem(tab == AppTab.SALES, { store.selectedTab.value = AppTab.SALES }, { Text("💰") }, label = { Text("Ventas") })
                if (store.isAdmin()) NavigationBarItem(tab == AppTab.COMMISSIONS, { store.selectedTab.value = AppTab.COMMISSIONS }, { Text("💵") }, label = { Text("Comis") })
                if (store.isAdmin()) NavigationBarItem(tab == AppTab.USERS, { store.selectedTab.value = AppTab.USERS }, { Text("👥") }, label = { Text("Usuarios") })
                NavigationBarItem(tab == AppTab.SETTINGS, { store.selectedTab.value = AppTab.SETTINGS }, { Text("⚙️") }, label = { Text("Config") })
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding)) {
            when (tab) {
                AppTab.DASHBOARD -> DashboardScreen(store)
                AppTab.INVENTORY -> InventoryScreen(store)
                AppTab.SALES -> SalesScreen(store)
                AppTab.COMMISSIONS -> CommissionsScreen(store)
                AppTab.USERS -> UsersScreen(store)
                AppTab.SETTINGS -> SettingsScreen(store)
            }
        }
    }
}

@Composable
fun Header(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().padding(16.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(subtitle)
    }
}

@Composable
fun MetricCard(title: String, value: String, emoji: String) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(emoji, style = MaterialTheme.typography.headlineMedium)
            Spacer(Modifier.width(12.dp))
            Column {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun DashboardScreen(store: NexoStore) {
    LazyColumn {
        item { Header("Dashboard", "Resumen general") }
        item { MetricCard("Ventas", cop(store.totalSales()), "💰") }
        item { MetricCard("Ganancia", cop(store.totalProfit()), "📈") }
        item { MetricCard("Comisiones pendientes", cop(store.workerCommissions()), "💵") }
        item { MetricCard("Stock", "${store.totalStock()} prendas", "📦") }
        item { MetricCard("Capital inventario", cop(store.investedCapital()), "🏦") }
        item { MetricCard("Capital recuperado", cop(store.recoveredCapital()), "✅") }

        val agotados = store.soldOutProducts()
        if (agotados.isNotEmpty()) {
            item { Text("🚨 Productos agotados", Modifier.padding(16.dp), fontWeight = FontWeight.Bold) }
            items(agotados) { Card(Modifier.fillMaxWidth().padding(16.dp)) { Text(it.name, Modifier.padding(16.dp)) } }
        }
    }
}

@Composable
fun InventoryScreen(store: NexoStore) {
    var query by remember { mutableStateOf("") }
    var form by remember { mutableStateOf(false) }

    LazyColumn {
        item { Header("Inventario", "Busca por nombre, código interno o código de barras") }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                label = { Text("Buscar producto o código") },
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            )
        }

        if (store.isAdmin()) {
            item {
                Button(onClick = { form = !form }, modifier = Modifier.padding(16.dp).fillMaxWidth()) {
                    Text(if (form) "Cerrar" else "Agregar producto")
                }
            }
        }

        if (form && store.isAdmin()) item { AddProductForm(store) }

        items(store.filteredProducts(query)) { product -> ProductCard(product, store) }
    }
}

@Composable
fun AddProductForm(store: NexoStore) {
    var name by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Pijamas") }
    var internal by remember { mutableStateOf("") }
    var barcode by remember { mutableStateOf("") }
    var cost by remember { mutableStateOf("") }
    var price by remember { mutableStateOf("") }
    var stock by remember { mutableStateOf("") }
    var photo by remember { mutableStateOf("") }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) photo = (photo.split(";;").filter { it.isNotBlank() } + uris.map { it.toString() }).joinToString(";;")
    }

    Card(Modifier.fillMaxWidth().padding(16.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text("Nuevo producto", fontWeight = FontWeight.Bold)
            OutlinedTextField(name, { name = it }, label = { Text("Producto") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(category, { category = it }, label = { Text("Categoría") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(internal, { internal = it }, label = { Text("Código interno") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(barcode, { barcode = it }, label = { Text("Código de barras") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(cost, { cost = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Costo real") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(price, { price = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Precio venta") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(stock, { stock = it.filter { c -> c.isDigit() } }, label = { Text("Stock") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(photo, { photo = it }, label = { Text("Fotos / referencias") }, modifier = Modifier.fillMaxWidth())
            Text("Fotos guardadas: ${photo.split(";;").count { it.isNotBlank() }}")
            Row {
                OutlinedButton(onClick = { imagePicker.launch("image/*") }) { Text("🖼 Agregar fotos") }
                Spacer(Modifier.width(8.dp))
                OutlinedButton(onClick = { photo = "" }) { Text("Limpiar") }
            }
            Button(
                onClick = {
                    if (store.addProduct(name, category, internal, barcode, cost.toDoubleOrNull() ?: -1.0, price.toDoubleOrNull() ?: 0.0, stock.toIntOrNull() ?: -1, photo)) {
                        name = ""; internal = ""; barcode = ""; cost = ""; price = ""; stock = ""; photo = ""
                    }
                },
                modifier = Modifier.fillMaxWidth()
            ) { Text("Guardar") }
        }
    }
}



fun firstPhotoUri(product: Product): String? {
    return product.photoUri.split(";;").firstOrNull { it.isNotBlank() }
}

fun photoCount(product: Product): Int {
    return product.photoUri.split(";;").count { it.isNotBlank() }
}

@Composable
fun ProductPhotoPreview(product: Product, modifier: Modifier = Modifier) {
    var expanded by remember { mutableStateOf(false) }
    val uri = firstPhotoUri(product)

    if (uri != null) {
        AsyncImage(
            model = uri,
            contentDescription = "Foto de ${product.name}",
            contentScale = ContentScale.Crop,
            modifier = modifier
                .fillMaxWidth()
                .height(190.dp)
                .clickable { expanded = true }
        )

        if (expanded) {
            AlertDialog(
                onDismissRequest = { expanded = false },
                confirmButton = {
                    Button(onClick = { expanded = false }) { Text("Cerrar") }
                },
                title = { Text(product.name) },
                text = {
                    Column {
                        AsyncImage(
                            model = uri,
                            contentDescription = "Foto ampliada",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxWidth().height(360.dp)
                        )
                        if (photoCount(product) > 1) {
                            Text("Foto principal 1 de ${photoCount(product)}")
                        }
                    }
                }
            )
        }
    }
}

@Composable
fun ProductCard(product: Product, store: NexoStore) {
    val label = when {
        product.stock <= 0 -> "🔴 Agotado"
        product.stock <= product.minStock -> "🟡 Última unidad"
        product.stock <= 3 -> "🟡 Stock bajo"
        else -> "🟢 Disponible"
    }

    var editMode by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }

    var name by remember(product.id, editMode) { mutableStateOf(product.name) }
    var category by remember(product.id, editMode) { mutableStateOf(product.category) }
    var internal by remember(product.id, editMode) { mutableStateOf(product.internalCode) }
    var barcode by remember(product.id, editMode) { mutableStateOf(product.barcode) }
    var cost by remember(product.id, editMode) { mutableStateOf(product.realCost.toString()) }
    var price by remember(product.id, editMode) { mutableStateOf(product.salePrice.toString()) }
    var stock by remember(product.id, editMode) { mutableStateOf(product.stock.toString()) }
    var photo by remember(product.id, editMode) { mutableStateOf(product.photoUri) }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        if (uris.isNotEmpty()) photo = (photo.split(";;").filter { it.isNotBlank() } + uris.map { it.toString() }).joinToString(";;")
    }

    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(product.name, fontWeight = FontWeight.Bold)
                AssistChip(onClick = {}, label = { Text(label) })
            }

            if (!editMode) {
                Text(product.category)
                if (product.internalCode.isNotBlank()) Text("Código interno: ${product.internalCode}")
                if (product.barcode.isNotBlank()) Text("Código barras: ${product.barcode}")
                Text("Precio: ${cop(product.salePrice)}")
                Text("Stock: ${product.stock}")
                if (product.photoUri.isNotBlank()) {
                    Spacer(Modifier.height(8.dp))
                    ProductPhotoPreview(product)
                    Text("Fotos guardadas: ${photoCount(product)}")
                }

                if (store.isAdmin()) {
                    Text("Costo: ${cop(product.realCost)}")
                    Text("Ganancia tú: ${cop(product.profitOwner)}")
                    Text("Ganancia trabajador: ${cop(product.profitWorker)}")
                    Spacer(Modifier.height(8.dp))
                    Row {
                        OutlinedButton(onClick = { store.adjustStock(product, 1) }) { Text("+1") }
                        Spacer(Modifier.width(8.dp))
                        OutlinedButton(onClick = { store.adjustStock(product, -1) }) { Text("-1") }
                        Spacer(Modifier.width(8.dp))
                        OutlinedButton(onClick = { editMode = true }) { Text("Editar") }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { confirmDelete = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("🗑 Eliminar producto")
                    }
                }

                Spacer(Modifier.height(8.dp))
                Button(onClick = { store.shareProduct(product) }, modifier = Modifier.fillMaxWidth()) {
                    Text("📲 Compartir producto")
                }
                Spacer(Modifier.height(6.dp))
                OutlinedButton(onClick = { store.shareProductOffer(product) }, modifier = Modifier.fillMaxWidth()) {
                    Text("🔥 Compartir oferta")
                }
                Spacer(Modifier.height(6.dp))
                OutlinedButton(onClick = { store.copyProductText(product) }, modifier = Modifier.fillMaxWidth()) {
                    Text("📋 Copiar texto")
                }
            } else {
                Text("Editar producto", fontWeight = FontWeight.Bold)
                OutlinedTextField(name, { name = it }, label = { Text("Producto") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(category, { category = it }, label = { Text("Categoría") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(internal, { internal = it }, label = { Text("Código interno") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(barcode, { barcode = it }, label = { Text("Código de barras") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(cost, { cost = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Costo") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(price, { price = it.filter { c -> c.isDigit() || c == '.' } }, label = { Text("Precio") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(stock, { stock = it.filter { c -> c.isDigit() } }, label = { Text("Stock") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(photo, { photo = it }, label = { Text("Fotos / referencias") }, modifier = Modifier.fillMaxWidth())
                Text("Fotos guardadas: ${photo.split(";;").count { it.isNotBlank() }}")
                Row {
                    OutlinedButton(onClick = { imagePicker.launch("image/*") }) { Text("🖼 Agregar fotos") }
                    Spacer(Modifier.width(8.dp))
                    OutlinedButton(onClick = { photo = "" }) { Text("Limpiar") }
                }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Button(onClick = {
                        val ok = store.updateProduct(product.id, name, category, internal, barcode, cost.toDoubleOrNull() ?: -1.0, price.toDoubleOrNull() ?: 0.0, stock.toIntOrNull() ?: -1, photo)
                        if (ok) editMode = false
                    }) { Text("Guardar") }
                    OutlinedButton(onClick = { editMode = false }) { Text("Cancelar") }
                }
            }
        }
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("Eliminar producto") },
            text = { Text("¿Deseas eliminar ${product.name}? Esta acción no se puede deshacer.") },
            confirmButton = { Button(onClick = { store.deleteProduct(product); confirmDelete = false }) { Text("Eliminar") } },
            dismissButton = { OutlinedButton(onClick = { confirmDelete = false }) { Text("Cancelar") } }
        )
    }
}

@Composable
fun SalesScreen(store: NexoStore) {
    var query by remember { mutableStateOf("") }

    LazyColumn {
        item { Header("Ventas", "Buscar y vender") }
        item {
            OutlinedTextField(query, { query = it }, label = { Text("Buscar producto o código") }, modifier = Modifier.fillMaxWidth().padding(16.dp))
        }

        items(store.filteredProducts(query).filter { it.stock > 0 }) { product ->
            Card(Modifier.fillMaxWidth().padding(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(product.name, fontWeight = FontWeight.Bold)
                    if (product.photoUri.isNotBlank()) {
                        Spacer(Modifier.height(8.dp))
                        ProductPhotoPreview(product, Modifier.fillMaxWidth().height(150.dp))
                    }
                    Text("Precio: ${cop(product.salePrice)}")
                    Text("Stock: ${product.stock}")

                    if (store.isAdmin()) {
                        Row {
                            Button(onClick = { store.registerSale(product, SellerType.OWNER) }) { Text("Vendí yo") }
                            Spacer(Modifier.width(8.dp))
                            OutlinedButton(onClick = { store.registerSale(product, SellerType.WORKER) }) { Text("Trabajador") }
                        }
                    } else {
                        Button(onClick = { store.registerSale(product, SellerType.WORKER) }, modifier = Modifier.fillMaxWidth()) {
                            Text("Registrar mi venta")
                        }
                    }
                }
            }
        }

        item { Text("Historial", Modifier.padding(16.dp), fontWeight = FontWeight.Bold) }

        items(store.sales.reversed()) { sale ->
            Card(Modifier.fillMaxWidth().padding(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Venta #${"%06d".format(sale.id)}", fontWeight = FontWeight.Bold)
                    Text("Producto: ${sale.productName}")
                    Text("Precio de venta: ${cop(sale.price)}")
                    Text("Vendido por: ${sale.sellerDisplayName}")
                    if (store.isAdmin()) {
                        Text("Costo real: ${cop(sale.realCost)}")
                        Text("Comisión: ${cop(sale.commission)}")
                        Text("Ganancia empresa: ${cop(sale.profit)}")
                        Text("Estado comisión: ${if (sale.commissionPaid) "Pagada" else "Pendiente"}")
                    }
                    Text("Fecha: ${sale.date}")
                }
            }
        }
    }
}

@Composable
fun CommissionsScreen(store: NexoStore) {
    LazyColumn {
        item { Header("Comisiones", "Pagos pendientes") }

        val users = store.commissionUsers()
        if (users.isEmpty()) item { Text("No hay comisiones pendientes", Modifier.padding(16.dp)) }

        items(users) { username ->
            Card(Modifier.fillMaxWidth().padding(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(store.sellerName(username), fontWeight = FontWeight.Bold)
                    Text("Ventas pendientes: ${store.commissionSales(username)}")
                    Text("Comisión: ${cop(store.commissionAmount(username))}")
                    Button(onClick = { store.payCommission(username) }, modifier = Modifier.fillMaxWidth()) {
                        Text("Pagar comisión")
                    }
                }
            }
        }
    }
}

@Composable
fun UsersScreen(store: NexoStore) {
    var form by remember { mutableStateOf(false) }

    LazyColumn {
        item { Header("Usuarios", "Administradores y trabajadores") }
        item { Button(onClick = { form = !form }, modifier = Modifier.padding(16.dp).fillMaxWidth()) { Text("Crear usuario") } }

        if (form) item { CreateUserCard(store) }

        items(store.users) { user ->
            Card(Modifier.fillMaxWidth().padding(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(user.displayName, fontWeight = FontWeight.Bold)
                    Text("Usuario: ${user.username}")
                    Text("Rol: ${user.role}")
                    Text("Estado: ${if (user.active) "Activo" else "Inactivo"}")
                    if (user.username != "admin") OutlinedButton(onClick = { store.toggleUser(user.username) }) {
                        Text(if (user.active) "Desactivar" else "Activar")
                    }
                }
            }
        }
    }
}

@Composable
fun CreateUserCard(store: NexoStore) {
    var username by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var admin by remember { mutableStateOf(false) }

    Card(Modifier.fillMaxWidth().padding(16.dp)) {
        Column(Modifier.padding(16.dp)) {
            OutlinedTextField(username, { username = it }, label = { Text("Usuario") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(name, { name = it }, label = { Text("Nombre") }, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(pass, { pass = it }, label = { Text("Clave") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            OutlinedTextField(confirm, { confirm = it }, label = { Text("Confirmar") }, visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(admin, { admin = it })
                Text("Administrador")
            }
            Button(onClick = { store.registerUser(username, name, pass, confirm, if (admin) UserRole.ADMIN else UserRole.WORKER) }, modifier = Modifier.fillMaxWidth()) {
                Text("Crear")
            }
        }
    }
}



@Composable
fun SettingsScreen(store: NexoStore) {
    val context = LocalContext.current

    val restoreTxtPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    store.restoreBackupFromInputStream(input)
                }
            } catch (_: Exception) {
                store.appMessage.value = "No se pudo abrir el respaldo"
            }
        }
    }

    val restoreSmartPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.openInputStream(uri)?.use { input ->
                    store.restoreSmartBackupFromInputStream(input)
                }
            } catch (_: Exception) {
                store.appMessage.value = "No se pudo abrir respaldo inteligente"
            }
        }
    }

    LazyColumn {
        item { Header("Configuración", "Sistema y respaldo inteligente") }
        item {
            Card(Modifier.fillMaxWidth().padding(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("Usuario: ${store.currentUser.value?.displayName}")
                    Text("Versión: 2.7.0")

                    Spacer(Modifier.height(12.dp))
                    Text("Respaldo inteligente", fontWeight = FontWeight.Bold)

                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { store.createSmartBackup() }, modifier = Modifier.fillMaxWidth()) {
                        Text("🧠 Crear respaldo inteligente")
                    }

                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { store.shareLatestSmartBackup() }, modifier = Modifier.fillMaxWidth()) {
                        Text("📤 Compartir respaldo inteligente")
                    }

                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { restoreSmartPicker.launch("*/*") }, modifier = Modifier.fillMaxWidth()) {
                        Text("📥 Restaurar respaldo inteligente")
                    }

                    Spacer(Modifier.height(16.dp))
                    Text("Compatibilidad anterior", fontWeight = FontWeight.Bold)

                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { store.createLocalBackup() }, modifier = Modifier.fillMaxWidth()) {
                        Text("📦 Crear respaldo TXT")
                    }

                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { store.shareLatestBackup() }, modifier = Modifier.fillMaxWidth()) {
                        Text("📤 Compartir respaldo TXT")
                    }

                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { restoreTxtPicker.launch("text/*") }, modifier = Modifier.fillMaxWidth()) {
                        Text("📥 Restaurar respaldo TXT")
                    }

                    Spacer(Modifier.height(8.dp))
                    Text("Importante: restaurar reemplaza los datos actuales por los del respaldo.", style = MaterialTheme.typography.bodySmall)

                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { store.logout() }, modifier = Modifier.fillMaxWidth()) {
                        Text("Cerrar sesión")
                    }
                }
            }
        }
    }
}

fun cop(value: Double): String = "$" + "%,.0f".format(value).replace(",", ".") + " COP"
