package com.nexoerp.data

data class Product(
    val id:Int,
    val name:String,
    val category:String,
    val realCost:Double,
    val salePrice:Double,
    val stock:Int,
    val minStock:Int=1,
    val barcode:String="",
    val photoUri:String=""
){
    val profitOwner:Double get()=salePrice-realCost
    val profitWorker:Double get()=salePrice-realCost-5000.0
    val marginPercent:Double get()=if(salePrice<=0.0)0.0 else ((salePrice-realCost)/salePrice)*100.0
}

data class Sale(
    val id:Int,
    val productName:String,
    val price:Double,
    val realCost:Double,
    val sellerType:SellerType,
    val profit:Double,
    val sellerUsername:String="",
    val sellerDisplayName:String="",
    val commission:Double=0.0,
    val commissionPaid:Boolean=false,
    val date:String=""
)

data class CommissionPayment(
    val id:Int,
    val workerUsername:String,
    val workerDisplayName:String,
    val amount:Double,
    val salesPaid:Int,
    val date:String,
    val paidBy:String
)

data class PurchaseLine(
    val id:Int,
    val batchId:Int,
    val supplier:String,
    val invoice:String,
    val productName:String,
    val category:String,
    val quantity:Int,
    val unitCost:Double,
    val shippingAssigned:Double,
    val realUnitCost:Double,
    val salePrice:Double,
    val total:Double,
    val barcode:String="",
    val photoUri:String="",
    val date:String=""
)

data class DraftItem(
    val productName:String,
    val category:String,
    val quantity:Int,
    val unitCost:Double,
    val salePrice:Double,
    val barcode:String="",
    val photoUri:String=""
)

data class SupplierSummary(val supplier:String,val totalInvested:Double,val totalUnits:Int,val purchasesCount:Int)

data class CommissionSummary(
    val workerUsername:String,
    val workerDisplayName:String,
    val salesCount:Int,
    val pendingAmount:Double
)

data class AppUser(val username:String,val displayName:String,val password:String,val role:UserRole,val active:Boolean=true)

enum class UserRole{ADMIN,WORKER}
enum class SellerType{OWNER,WORKER}
enum class AppTab{DASHBOARD,INVENTORY,PURCHASES,SUPPLIERS,SALES,COMMISSIONS,AI,REPORTS,USERS,SETTINGS}
