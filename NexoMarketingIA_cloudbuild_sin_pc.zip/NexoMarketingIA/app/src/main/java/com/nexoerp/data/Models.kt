package com.nexoerp.data

data class Product(
    val id: Int,
    val name: String,
    val category: String,
    val realCost: Double,
    val salePrice: Double,
    val stock: Int,
    val minStock: Int = 1
) {
    val profitOwner: Double get() = salePrice - realCost
    val profitWorker: Double get() = salePrice - realCost - 5000.0
    val marginPercent: Double get() = if (salePrice <= 0.0) 0.0 else ((salePrice - realCost) / salePrice) * 100.0
}

data class Sale(
    val id: Int,
    val productName: String,
    val price: Double,
    val realCost: Double,
    val sellerType: SellerType,
    val profit: Double
)

data class AppUser(
    val username: String,
    val displayName: String,
    val password: String,
    val role: UserRole,
    val active: Boolean = true
)

enum class UserRole { ADMIN, WORKER }
enum class SellerType { OWNER, WORKER }
enum class AppTab { DASHBOARD, INVENTORY, SALES, AI, REPORTS, USERS, SETTINGS }
