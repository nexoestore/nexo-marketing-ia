package com.nexo.marketingia;

import android.content.*;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent){
        if(context.getSharedPreferences("nexo_v4",Context.MODE_PRIVATE).getBoolean("reminders_active",false)){
            ReminderScheduler.scheduleDaily(context);
        }
    }
}
