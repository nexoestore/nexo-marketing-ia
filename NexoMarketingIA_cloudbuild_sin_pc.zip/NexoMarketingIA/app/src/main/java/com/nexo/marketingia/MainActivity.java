package com.nexo.marketingia;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout content;
    SharedPreferences prefs;
    final int BG=Color.rgb(4,7,8), PANEL=Color.rgb(16,26,29), TEAL=Color.rgb(22,242,226), WHITE=Color.rgb(244,255,255), MUTED=Color.rgb(150,167,170), DARK=Color.rgb(23,38,41);

    @Override public void onCreate(Bundle b){ super.onCreate(b); prefs=getSharedPreferences("nexo_v4",MODE_PRIVATE); seedProducts(); NotificationHelper.createChannel(this); askNotifications(); home(); }

    void shell(String title){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG); root.setPadding(18,22,18,18);
        ScrollView scroll=new ScrollView(this); content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); scroll.addView(content); root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        TextView h=tv("Nexo Marketing IA V4",25,TEAL,true); content.addView(h);
        TextView sub=tv("Respuestas · catálogo · prospectos · seguimiento · ventas",13,MUTED,false); sub.setPadding(0,4,0,14); content.addView(sub);
        TextView t=tv(title,22,WHITE,true); t.setPadding(0,0,0,12); content.addView(t);
        LinearLayout nav1=row(); addNav(nav1,"Hoy",v->home()); addNav(nav1,"IA",v->ai()); addNav(nav1,"Catálogo",v->catalog()); addNav(nav1,"Clientes",v->crm()); content.addView(nav1);
        LinearLayout nav2=row(); addNav(nav2,"Campaña",v->campaign()); addNav(nav2,"Ganancia",v->profit()); addNav(nav2,"Metas",v->goals()); content.addView(nav2);
        setContentView(root);
    }

    LinearLayout row(){ LinearLayout r=new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL); r.setGravity(Gravity.CENTER); return r; }
    void addNav(LinearLayout r,String label,android.view.View.OnClickListener l){ r.addView(btn(label,false,l),new LinearLayout.LayoutParams(0,-2,1)); }

    void home(){ shell("Panel de ventas");
        card("Hoy", box->{ box.addView(line("Publicaciones: "+prefs.getInt("pubs",0)+"/10",true)); box.addView(line("Ventas: "+prefs.getInt("sales",0)+"/2",true)); box.addView(line("Prospectos: "+list("prospects").size(),true)); box.addView(line("Seguimientos pendientes: "+pending(),true)); });
        card("Acciones que sí venden", box->{ box.addView(btn("Copiar catálogo completo",true,v->copy(catalogText()))); box.addView(btn("Responder cliente con IA rápida",false,v->ai())); box.addView(btn("Abrir Nexo E Store",false,v->open("https://www.nexoestore.com"))); box.addView(btn("Activar recordatorios diarios",false,v->{ activateReminders(); })); });
        card("Prueba de notificaciones", box->{ box.addView(line("Sirve para confirmar si Android deja mostrar notificaciones.",false)); box.addView(btn("Enviar notificación de prueba ahora",true,v->{ NotificationHelper.notifyNow(this,7777,"Prueba Nexo Marketing IA","Si ves esto, las notificaciones funcionan."); addHistory("Prueba enviada: "+nowText()); toast("Notificación de prueba enviada"); })); });
        card("Modo campaña diaria", box->{ box.addView(line("1. Copia una promoción.",false)); box.addView(line("2. Publica en grupos/estados.",false)); box.addView(line("3. Registra cada interesado.",false)); box.addView(line("4. Haz seguimiento en 24 horas.",false)); });
    }

    void ai(){ shell("IA Comercial rápida");
        card("Pega o escribe lo que preguntó el cliente", box->{ EditText q=input("Ejemplo: catálogo, precios, garantía, cómo compro, soy revendedor..."); box.addView(q); box.addView(btn("Generar y copiar respuesta",true,v->copy(smartReply(q.getText().toString())))); });
        card("Respuestas rápidas", box->{ box.addView(btn("Catálogo",true,v->copy(catalogText()))); box.addView(btn("Precios",true,v->copy(priceText()))); box.addView(btn("Cómo comprar",true,v->copy(howToBuyText()))); box.addView(btn("Garantía",true,v->copy(warrantyText()))); box.addView(btn("Revendedor",true,v->copy(resellerText()))); box.addView(btn("Cerrar venta",true,v->copy(closeSaleText()))); });
    }

    void catalog(){ shell("Catálogo editable");
        card("Agregar producto", box->{ EditText n=input("Producto"), p=input("Precio proveedor"), d=input("Descripción"); box.addView(n); box.addView(p); box.addView(d); box.addView(btn("Guardar producto",true,v->{ if(n.getText().toString().trim().isEmpty()){toast("Agrega producto"); return;} save("products",clean(n.getText())+"|"+clean(p.getText())+"|"+clean(d.getText())+"|Disponible"); catalog(); })); });
        ArrayList<String> ps=list("products"); for(int i=0;i<ps.size();i++){ final int idx=i; String[] p=parts(ps.get(i),4); card(p[0], box->{ box.addView(line("Precio: "+p[1],true)); box.addView(line("Estado: "+p[3],false)); box.addView(line(p[2],false)); box.addView(btn("Copiar promoción",true,v->copy(promo(p)))); box.addView(btn("Marcar agotado/disponible",false,v->{ updateProductStatus(idx, p[3].equals("Disponible")?"Agotado":"Disponible"); catalog(); })); }); }
    }

    void campaign(){ shell("Campaña diaria");
        card("Promoción recomendada", box->{ box.addView(line("Publica este texto en grupos, estados o Facebook.",false)); box.addView(btn("Copiar campaña corta",true,v->copy(shortCampaign()))); box.addView(btn("Copiar campaña para proveedores",true,v->copy(providerCampaign()))); box.addView(btn("Marcar publicación hecha",false,v->{ prefs.edit().putInt("pubs",prefs.getInt("pubs",0)+1).apply(); toast("Publicación sumada"); })); });
        card("Textos por canal", box->{ box.addView(btn("WhatsApp grupos",true,v->copy(whatsappGroupText()))); box.addView(btn("Facebook grupos",true,v->copy(facebookText()))); box.addView(btn("Estado WhatsApp",true,v->copy(statusText()))); box.addView(btn("Mensaje privado",true,v->copy(privateText()))); });
    }

    void crm(){ shell("Prospectos / seguimiento");
        card("Agregar prospecto", box->{ EditText name=input("Nombre"), phone=input("WhatsApp"), country=input("País"), product=input("Producto de interés"); box.addView(name); box.addView(phone); box.addView(country); box.addView(product); box.addView(btn("Guardar prospecto",true,v->{ if(name.getText().toString().trim().isEmpty()){toast("Agrega nombre"); return;} save("prospects",clean(name.getText())+"|"+clean(phone.getText())+"|"+clean(country.getText())+"|"+clean(product.getText())+"|Nuevo|"+today()); crm(); })); });
        ArrayList<String> items=list("prospects"); if(items.isEmpty()) card("Sin prospectos", box->box.addView(line("Guarda aquí cada persona interesada.",false)));
        for(int i=0;i<items.size();i++){ final int idx=i; String raw=items.get(i); String[] p=parts(raw,6); card(p[0], box->{ box.addView(line("Producto: "+p[3],false)); box.addView(line("País: "+p[2],false)); box.addView(line("Estado: "+p[4],true)); box.addView(line("Fecha: "+p[5],false)); box.addView(btn("Abrir WhatsApp",false,v->{ if(p[1].isEmpty())toast("Sin número"); else open("https://wa.me/"+p[1].replaceAll("\\D","")); })); box.addView(btn("Copiar seguimiento",true,v->copy(followupText(p[0],p[3])))); box.addView(btn("Marcar interesado",false,v->{ updateProspectStatus(idx,"Interesado"); crm(); })); box.addView(btn("Marcar compró",false,v->{ updateProspectStatus(idx,"Compró"); prefs.edit().putInt("sales",prefs.getInt("sales",0)+1).apply(); crm(); })); box.addView(btn("Marcar perdido",false,v->{ updateProspectStatus(idx,"Perdido"); crm(); })); }); }
    }

    void profit(){ shell("Calculadora de ganancia"); card("Calcular venta", box->{ EditText cost=input("Costo proveedor, ejemplo 2"), sale=input("Precio venta, ejemplo 3"); box.addView(cost); box.addView(sale); box.addView(btn("Calcular y copiar",true,v->{ double c=toD(cost.getText().toString()), s=toD(sale.getText().toString()); double g=s-c, m=s>0?(g/s)*100:0; copy("Ganancia estimada\n\nCosto: US$"+c+"\nVenta: US$"+s+"\nGanancia: US$"+String.format(Locale.US,"%.2f",g)+"\nMargen: "+String.format(Locale.US,"%.1f",m)+"%"); })); }); }
    void goals(){ shell("Metas y recordatorios"); card("Metas diarias", box->{ box.addView(line("Publicaciones: "+prefs.getInt("pubs",0)+"/10",true)); box.addView(line("Ventas: "+prefs.getInt("sales",0)+"/2",true)); box.addView(line("Seguimientos: "+pending()+"/5",true)); box.addView(btn("Reiniciar conteo del día",false,v->{ prefs.edit().putInt("pubs",0).putInt("sales",0).apply(); goals(); })); }); card("Notificaciones V4", box->{ box.addView(line("8:00 AM: publicar",false)); box.addView(line("2:00 PM: responder prospectos",false)); box.addView(line("8:00 PM: seguimiento nocturno",false)); box.addView(btn("Probar notificación ahora",true,v->{ NotificationHelper.notifyNow(this,7777,"Prueba Nexo Marketing IA","Notificación de prueba funcionando."); addHistory("Prueba enviada: "+nowText()); toast("Prueba enviada"); })); box.addView(btn("Activar recordatorios diarios",true,v->{ activateReminders(); })); box.addView(btn("Recordatorio en 1 minuto",false,v->{ ReminderScheduler.scheduleInMinutes(this,1,9001,"Recordatorio de prueba","Publica o registra un prospecto ahora."); addHistory("Recordatorio 1 minuto: "+nowText()); toast("Programado en 1 minuto"); })); box.addView(btn("Recordatorio cada hora",false,v->{ ReminderScheduler.scheduleHourly(this); addHistory("Cada hora activado: "+nowText()); toast("Cada hora activado"); })); }); card("Historial de notificaciones", box->{ ArrayList<String> h=list("notification_history"); if(h.isEmpty()) box.addView(line("Sin historial todavía.",false)); for(int i=0;i<h.size() && i<12;i++) box.addView(line(h.get(i),false)); }); }

    String smartReply(String raw){ String q=norm(raw); if(has(q,"catalogo,catálogo,productos,producto,servicios,servicio,que tienes,qué tienes,que manejas,qué manejas,stock,disponible,disponibles,lista,menu,menú,opciones,plataformas,apps,streaming,cuentas,cuenta,inventario,oferta,ofertas,paquete,paquetes"))return catalogText(); if(has(q,"precio,precios,costo,costos,tarifa,tarifas,valor,valores,cuanto,cuánto,sale,vale,barato,proveedor,mayorista,lista de precio,lista de precios,usd,dolar,dólar,dolares,dólares,promocion,promoción,rebaja,descuento,cuesta"))return priceText(); if(has(q,"comprar,compra,compro,pedido,orden,quiero,necesito,adquirir,pagar,pago,recarga,recargar,saldo,deposito,depósito,transferencia,validar,id,comprobante,proceso,como compro,cómo compro,como comprar,cómo comprar,link,enlace,pagina,página,web"))return howToBuyText(); if(has(q,"revendedor,revender,reventa,proveedor,mayorista,negocio,vendo,vender,cliente,clientes,panel,automatico,automático,stock propio,distribuidor,reseller,venta,ventas,latam,grupo,grupos,publicar"))return resellerText(); if(has(q,"garantia,garantía,garantias,garantías,soporte,ayuda,respaldo,seguro,confiable,confianza,reclamo,fallo,falla,cae,caida,caída,reposicion,reposición,cambio,reembolso,problema,soportan,reportar,daño,no funciona"))return warrantyText(); if(has(q,"si quiero,sí quiero,me interesa,dale,ok,listo,hagale,hágale,pasame link,pásame link,envia,envía,pasar,pruebo,probar,activar"))return closeSaleText(); if(has(q,"amazon,prime,prime video,amazon prime"))return productReply("Amazon Prime Video","US$2.00"); if(has(q,"disney,disney+,disney plus,premium disney,d+"))return productReply("Disney Premium","US$8.00"); if(has(q,"max,hbo,hbo max,platino,max platino"))return productReply("Max Platino 4K","US$4.50"); return generalText(); }
    boolean has(String q,String csv){ for(String k:csv.split(",")) if(q.contains(norm(k.trim()))) return true; return false; }

    String catalogText(){ StringBuilder sb=new StringBuilder("📺 Catálogo disponible\n\n"); for(String r:list("products")){ String[] p=parts(r,4); sb.append("✅ ").append(p[0]).append("\n💰 ").append(p[1]).append("\n").append(p[2]).append("\n\n"); } sb.append("🌐 Compra automática:\nwww.nexoestore.com\n\nRegistro gratuito • Entrega automática • Soporte por WhatsApp"); return sb.toString(); }
    String priceText(){ StringBuilder sb=new StringBuilder("💰 Lista de precios proveedor\n\n"); for(String r:list("products")){String[] p=parts(r,4); sb.append(p[0]).append(": ").append(p[1]).append("\n");} sb.append("\n🌐 www.nexoestore.com\nRegistro gratis y entrega automática."); return sb.toString(); }
    String howToBuyText(){ return "🛒 Cómo comprar\n\n1️⃣ Ingresa a www.nexoestore.com\n2️⃣ Regístrate gratis\n3️⃣ Recarga saldo\n4️⃣ Envíame el ID o comprobante\n5️⃣ Valido tu saldo\n6️⃣ Compras con entrega automática"; }
    String warrantyText(){ return "✅ Garantía y soporte\n\nTodas las compras tienen soporte por WhatsApp durante el horario de atención.\nLa garantía aplica cuando la cuenta presenta falla de acceso dentro del periodo contratado y el cliente reporta con evidencia clara.\n\n🌐 www.nexoestore.com"; }
    String resellerText(){ return "🚀 Para revendedores\n\nTenemos servicios streaming con compra automática desde panel web.\nPuedes registrarte gratis, recargar saldo y comprar cuando necesites sin esperar respuesta manual.\n\n🌐 www.nexoestore.com"; }
    String closeSaleText(){ return "Perfecto 😊\n\nRegístrate gratis en:\nwww.nexoestore.com\n\nLuego recarga saldo y envíame el ID o comprobante para validarlo. Después compras directamente desde la plataforma con entrega automática."; }
    String generalText(){ return "¡Hola! 😊 Tenemos servicios streaming disponibles.\n\nPuedes ver catálogo, precios y disponibilidad en:\nwww.nexoestore.com\n\n✅ Registro gratis\n✅ Recarga saldo\n✅ Entrega automática\n✅ Soporte por WhatsApp\n\n¿Lo deseas para uso personal o para reventa?"; }
    String productReply(String n,String p){ return "Sí, tenemos "+n+" disponible 😊\n\n💰 Precio proveedor: "+p+"\n✅ Entrega automática\n✅ Registro gratis\n✅ Compra desde la web\n\n🌐 www.nexoestore.com\n\n¿Lo deseas para ti o para revender?"; }
    String shortCampaign(){ return "🔥 Streaming para revendedores\n\nAmazon Prime · Max Platino · Disney Premium\n\n✅ Stock disponible\n✅ Entrega automática\n✅ Registro gratis\n\n🌐 www.nexoestore.com"; }
    String providerCampaign(){ return "🚀 Proveedor streaming\n\n✅ Amazon Prime\n✅ Max Platino 4K\n✅ Disney Premium\n\n⚡ Panel web\n⚡ Compra automática\n⚡ Registro gratuito\n\n🌐 www.nexoestore.com"; }
    String whatsappGroupText(){ return "🔥 Stock disponible para revendedores\n\n✅ Amazon Prime\n✅ Max Platino 4K\n✅ Disney Premium\n\nCompra automática:\nwww.nexoestore.com"; }
    String facebookText(){ return "¿Buscas proveedor estable para streaming?\n\n✔ Entrega automática\n✔ Plataforma propia\n✔ Stock disponible\n✔ Registro gratuito\n\n🌐 www.nexoestore.com"; }
    String statusText(){ return "📺 Streaming disponible\nAmazon Prime · Max · Disney\n\nCompra automática 24/7\nwww.nexoestore.com"; }
    String privateText(){ return "Hola 😊 te comparto mi plataforma de compra automática:\n\nwww.nexoestore.com\n\nTe registras gratis, recargas saldo y compras con entrega automática."; }
    String promo(String[] p){ return "🔥 "+p[0]+"\n\n💰 Precio proveedor: "+p[1]+"\n"+p[2]+"\n\n✅ Entrega automática\n✅ Registro gratis\n🌐 www.nexoestore.com"; }
    String followupText(String n,String p){ return "Hola "+n+" 😊 ¿aún deseas información sobre "+p+"? Puedes comprar con entrega automática desde www.nexoestore.com"; }

    void seedProducts(){ if(prefs.getBoolean("seeded",false))return; prefs.edit().putString("products","Amazon Prime Video|US$2.00|Cuenta 1 mes para streaming|Disponible\nMax Platino 4K|US$4.50|Cuenta 1 mes, calidad UHD según disponibilidad|Disponible\nDisney Premium|US$8.00|Cuenta premium 1 mes|Disponible").putBoolean("seeded",true).apply(); }
    void updateProductStatus(int i,String st){ ArrayList<String> l=list("products"); String[] p=parts(l.get(i),4); p[3]=st; l.set(i,String.join("|",p)); prefs.edit().putString("products",String.join("\n",l)).apply(); }
    void updateProspectStatus(int i,String st){ ArrayList<String> l=list("prospects"); String[] p=parts(l.get(i),6); p[4]=st; l.set(i,String.join("|",p)); prefs.edit().putString("prospects",String.join("\n",l)).apply(); }

    interface BoxBuild{ void apply(LinearLayout box); }
    void card(String title,BoxBuild build){ LinearLayout box=new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setBackgroundColor(PANEL); box.setPadding(18,18,18,18); TextView titlev=tv(title,18,WHITE,true); titlev.setPadding(0,0,0,8); box.addView(titlev); build.apply(box); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,16); content.addView(box,lp); }
    TextView tv(String s,int size,int color,boolean bold){ TextView v=new TextView(this); v.setText(s); v.setTextSize(size); v.setTextColor(color); if(bold)v.setTypeface(null,1); return v; }
    TextView line(String s,boolean strong){ TextView v=tv(s,15,strong?TEAL:WHITE,strong); v.setPadding(0,6,0,6); return v; }
    EditText input(String hint){ EditText e=new EditText(this); e.setHint(hint); e.setHintTextColor(MUTED); e.setTextColor(WHITE); e.setBackgroundColor(Color.rgb(6,17,19)); e.setPadding(14,12,14,12); return e; }
    Button btn(String label,boolean primary,android.view.View.OnClickListener l){ Button b=new Button(this); b.setText(label); b.setTextSize(13); b.setTextColor(primary?Color.BLACK:WHITE); b.setBackgroundColor(primary?TEAL:DARK); b.setOnClickListener(l); return b; }
    String norm(String s){ return s.toLowerCase(Locale.getDefault()).replace("á","a").replace("é","e").replace("í","i").replace("ó","o").replace("ú","u"); }
    String clean(CharSequence s){ return s.toString().replace("|"," ").replace("\n"," ").trim(); }
    ArrayList<String> list(String k){ String raw=prefs.getString(k,""); ArrayList<String> out=new ArrayList<>(); for(String x:raw.split("\n")) if(!x.trim().isEmpty()) out.add(x); return out; }
    void save(String k,String item){ ArrayList<String> l=list(k); l.add(0,item); prefs.edit().putString(k,String.join("\n",l)).apply(); }
    int pending(){ int c=0; for(String x:list("prospects")) if(x.contains("|Nuevo|")||x.contains("|Interesado|")) c++; return c; }
    String today(){ return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date()); }
    String[] parts(String raw,int n){ String[] a=raw.split("\\|",-1); String[] r=new String[n]; for(int i=0;i<n;i++) r[i]=i<a.length?a[i]:""; return r; }
    double toD(String s){ try{return Double.parseDouble(s.replace(",","."));}catch(Exception e){return 0;} }
    void toast(String s){ Toast.makeText(this,s,Toast.LENGTH_SHORT).show(); }
    void copy(String s){ ((ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Nexo",s)); toast("Copiado"); }
    void open(String url){ try{ startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }catch(Exception e){ toast("No se pudo abrir"); } }

    void activateReminders(){ ReminderScheduler.scheduleDaily(this); prefs.edit().putBoolean("reminders_active",true).apply(); NotificationHelper.notifyNow(this,7001,"Recordatorios activados","Nexo Daily quedó programado."); addHistory("Recordatorios activados: "+nowText()); toast("Recordatorios activados"); }
    void addHistory(String x){ ArrayList<String> l=list("notification_history"); l.add(0,x); while(l.size()>30) l.remove(l.size()-1); prefs.edit().putString("notification_history",String.join("\n",l)).apply(); }
    String nowText(){ return new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.US).format(new Date()); }
    void channel(){ if(Build.VERSION.SDK_INT>=26){ NotificationChannel c=new NotificationChannel("nexo_daily","Nexo Daily",NotificationManager.IMPORTANCE_DEFAULT); getSystemService(NotificationManager.class).createNotificationChannel(c); } }
    void askNotifications(){ if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},10); }
    void scheduleAll(){ ReminderScheduler.scheduleDaily(this); }
    void schedule(int h,int m,int id,String title,String body){ AlarmManager alarm=(AlarmManager)getSystemService(ALARM_SERVICE); Intent intent=new Intent(this,ReminderReceiver.class).putExtra("title",title).putExtra("body",body).putExtra("id",id); PendingIntent pi=PendingIntent.getBroadcast(this,id,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE); Calendar cal=Calendar.getInstance(); cal.set(Calendar.HOUR_OF_DAY,h); cal.set(Calendar.MINUTE,m); cal.set(Calendar.SECOND,0); if(cal.before(Calendar.getInstance()))cal.add(Calendar.DATE,1); alarm.setRepeating(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pi); }
}
