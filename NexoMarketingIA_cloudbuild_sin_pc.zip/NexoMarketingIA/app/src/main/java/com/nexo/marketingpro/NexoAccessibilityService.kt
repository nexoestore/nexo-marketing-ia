package com.nexo.marketingpro
import android.accessibilityservice.AccessibilityService
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
class NexoAccessibilityService : AccessibilityService() {
    companion object { var targetGroup: String = ""; var targetText: String = "" }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        val root = rootInActiveWindow ?: return
        if (targetGroup.isBlank()) return
        val nodes = root.findAccessibilityNodeInfosByText("Buscar")
        if (nodes.isNotEmpty()) {
            val n = nodes.first()
            n.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            val args = Bundle()
            args.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, targetGroup)
            n.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        }
    }
    override fun onInterrupt() {}
}
