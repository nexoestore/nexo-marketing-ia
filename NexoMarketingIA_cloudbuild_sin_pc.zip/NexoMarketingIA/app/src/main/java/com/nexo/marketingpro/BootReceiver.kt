package com.nexo.marketingpro
import android.content.*
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        ReminderScheduler.schedulePersistent(context)
    }
}
