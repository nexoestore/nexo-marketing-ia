package com.nexo.marketingia
import android.app.*
import android.content.*
import android.os.Build
object NotificationHelper {
    const val CHANNEL_ID = "nexo_daily"
    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= 26) {
            val c = NotificationChannel(CHANNEL_ID, "Nexo Daily", NotificationManager.IMPORTANCE_HIGH)
            c.description = "Recordatorios para publicar con constancia"
            context.getSystemService(NotificationManager::class.java).createNotificationChannel(c)
        }
    }
    fun notifyNow(context: Context, id: Int, title: String, body: String) {
        createChannel(context)
        val open = Intent(context, MainActivity::class.java)
        val pending = PendingIntent.getActivity(context, id, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val b = Notification.Builder(context).setContentTitle(title).setContentText(body).setSmallIcon(android.R.drawable.ic_dialog_info).setContentIntent(pending).setAutoCancel(true)
        if (Build.VERSION.SDK_INT >= 26) b.setChannelId(CHANNEL_ID)
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(id, b.build())
    }
}
