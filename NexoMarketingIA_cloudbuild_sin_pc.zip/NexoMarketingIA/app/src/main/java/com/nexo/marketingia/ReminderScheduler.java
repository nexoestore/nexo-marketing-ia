package com.nexo.marketingia;

import android.app.*;
import android.content.*;
import java.util.*;

public class ReminderScheduler {
    public static void scheduleDaily(Context context){
        scheduleAt(context,8,0,1001,"Hora de publicar","Meta de hoy: 10 publicaciones.");
        scheduleAt(context,14,0,1002,"Responder prospectos","Revisa clientes interesados.");
        scheduleAt(context,20,0,1003,"Seguimiento nocturno","Contacta a quienes preguntaron.");
    }
    public static void scheduleHourly(Context context){
        AlarmManager alarm=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        PendingIntent pi=pending(context,2001,"Publicación pendiente","Recuerda publicar o responder prospectos.");
        alarm.setRepeating(AlarmManager.RTC_WAKEUP,System.currentTimeMillis()+3600000L,3600000L,pi);
    }
    public static void scheduleInMinutes(Context context,int minutes,int id,String title,String body){
        AlarmManager alarm=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        alarm.set(AlarmManager.RTC_WAKEUP,System.currentTimeMillis()+minutes*60000L,pending(context,id,title,body));
    }
    private static void scheduleAt(Context context,int hour,int minute,int id,String title,String body){
        AlarmManager alarm=(AlarmManager)context.getSystemService(Context.ALARM_SERVICE);
        Calendar cal=Calendar.getInstance();
        cal.set(Calendar.HOUR_OF_DAY,hour); cal.set(Calendar.MINUTE,minute); cal.set(Calendar.SECOND,0);
        if(cal.before(Calendar.getInstance())) cal.add(Calendar.DATE,1);
        alarm.setRepeating(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),AlarmManager.INTERVAL_DAY,pending(context,id,title,body));
    }
    private static PendingIntent pending(Context context,int id,String title,String body){
        Intent intent=new Intent(context,ReminderReceiver.class);
        intent.putExtra("title",title); intent.putExtra("body",body); intent.putExtra("id",id);
        return PendingIntent.getBroadcast(context,id,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
}
