package com.nexo.marketingia;

import android.app.*;
import android.content.*;
import android.os.Build;

public class NotificationHelper {
    public static final String CHANNEL_ID = "nexo_daily";
    public static void createChannel(Context context){
        if(Build.VERSION.SDK_INT>=26){
            NotificationChannel c = new NotificationChannel(CHANNEL_ID,"Nexo Daily",NotificationManager.IMPORTANCE_HIGH);
            c.setDescription("Recordatorios para publicar, responder y hacer seguimiento");
            context.getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }
    public static void notifyNow(Context context, int id, String title, String body){
        createChannel(context);
        Intent open = new Intent(context, MainActivity.class);
        PendingIntent pending = PendingIntent.getActivity(context,id,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = new Notification.Builder(context)
            .setContentTitle(title)
            .setContentText(body)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pending)
            .setAutoCancel(true);
        if(Build.VERSION.SDK_INT>=26) b.setChannelId(CHANNEL_ID);
        ((NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE)).notify(id,b.build());
    }
}
