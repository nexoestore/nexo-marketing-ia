package com.nexo.marketingia

import android.app.*
import android.content.*
import android.os.Build

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "Nexo Marketing IA"
        val body = intent.getStringExtra("body") ?: "Tienes tareas pendientes."
        val id = intent.getIntExtra("id", 9000)
        val open = Intent(context, MainActivity::class.java)
        val pending = PendingIntent.getActivity(context, id, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val builder = Notification.Builder(context)
            .setContentTitle(title)
            .setContentText(body)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentIntent(pending)
            .setAutoCancel(true)
        if (Build.VERSION.SDK_INT >= 26) builder.setChannelId("nexo_daily")
        (context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager).notify(id, builder.build())
    }
}
