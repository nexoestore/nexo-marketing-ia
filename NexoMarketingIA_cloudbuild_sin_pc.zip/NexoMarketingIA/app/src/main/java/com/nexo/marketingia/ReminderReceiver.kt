package com.nexo.marketingia
import android.content.*
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        NotificationHelper.notifyNow(context, intent.getIntExtra("id", 9000), intent.getStringExtra("title") ?: "Nexo Marketing IA", intent.getStringExtra("body") ?: "Publica en tus grupos ahora.")
    }
}
