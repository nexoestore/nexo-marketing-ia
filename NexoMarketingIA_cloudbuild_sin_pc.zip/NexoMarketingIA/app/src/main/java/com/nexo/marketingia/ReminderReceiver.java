package com.nexo.marketingia;

import android.app.*;
import android.content.*;
import android.os.Build;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        String title=intent.getStringExtra("title"); if(title==null) title="Nexo Marketing IA";
        String body=intent.getStringExtra("body"); if(body==null) body="Tienes tareas pendientes.";
        int id=intent.getIntExtra("id",9000);
        Intent open=new Intent(context, MainActivity.class);
        PendingIntent pending=PendingIntent.getActivity(context,id,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=new Notification.Builder(context).setContentTitle(title).setContentText(body).setSmallIcon(android.R.drawable.ic_dialog_info).setContentIntent(pending).setAutoCancel(true);
        if(Build.VERSION.SDK_INT>=26) b.setChannelId("nexo_daily");
        ((NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE)).notify(id,b.build());
    }
}
