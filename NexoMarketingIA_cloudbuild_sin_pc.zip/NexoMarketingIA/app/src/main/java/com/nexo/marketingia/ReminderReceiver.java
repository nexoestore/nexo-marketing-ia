package com.nexo.marketingia;

import android.content.*;

public class ReminderReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent){
        String title=intent.getStringExtra("title"); if(title==null) title="Nexo Marketing IA";
        String body=intent.getStringExtra("body"); if(body==null) body="Tienes tareas pendientes.";
        int id=intent.getIntExtra("id",9000);
        NotificationHelper.notifyNow(context,id,title,body);
    }
}
