package com.nexo.marketingia
import android.content.*
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        ReminderScheduler.schedulePersistent(context)
    }
}
