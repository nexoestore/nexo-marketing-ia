package com.nexo.marketingia

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var content: LinearLayout
    private val prefs by lazy { getSharedPreferences("nexo_marketing_pro", MODE_PRIVATE) }

    private val bg = Color.rgb(4, 7, 8)
    private val panel = Color.rgb(16, 26, 29)
    private val teal = Color.rgb(22, 242, 226)
    private val white = Color.rgb(244, 255, 255)
    private val muted = Color.rgb(150, 167, 170)
    private val dark = Color.rgb(23, 38, 41)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        NotificationHelper.createChannel(this)
        askNotif()
        seed()
        home()
    }

    private fun shell(title: String) {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(bg)
        root.setPadding(18, 22, 18, 18)

        val scroll = ScrollView(this)
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        text("Nexo Marketing Pro", 25f, teal, true)
        text("Convierte publicaciones en clientes", 13f, muted, false)
        text(title, 22f, white, true)

        // Navegación limpia: solo lo esencial arriba.
        // Las funciones secundarias están en "Más" para no saturar el inicio.
        nav(listOf("Inicio" to { home() }, "Buscar" to { publisher() }, "Biblioteca" to { copies() }, "Más" to { more() }))

        setContentView(root)
    }

    private fun nav(items: List<Pair<String, () -> Unit>>) {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        items.forEach { (label, action) ->
            r.addView(btn(label, false, action), LinearLayout.LayoutParams(0, -2, 1f))
        }
        content.addView(r)
    }

    private fun text(s: String, size: Float, color: Int, bold: Boolean) {
        val v = TextView(this)
        v.text = s
        v.textSize = size
        v.setTextColor(color)
        if (bold) v.setTypeface(null, 1)
        v.setPadding(0, 4, 0, 8)
        content.addView(v)
    }

    private fun more() {
        shell("Más herramientas")

        card("Trabajo comercial") {
            addView(btn("👥 Prospectos", true) { crm() })
            addView(btn("🔔 Seguimientos", false) { followups() })
            addView(btn("💰 Clientes", false) { clients() })
            addView(btn("📊 Dashboard", false) { dashboard() })
        }

        card("Configuración y canales") {
            addView(btn("📢 Canales / grupos", true) { groups() })
            addView(btn("🎯 Metas", false) { goals() })
            addView(line("Las herramientas secundarias siguen disponibles aquí, pero ya no ocupan media pantalla.", false))
        }
    }

    private fun home() {
        shell("Inicio comercial")
        val prospectCount = list("prospects").size
        val clientCount = list("clients").size
        val doneToday = todayPublished().size
        val dueFollowups = dueFollowups().size
        val targetProspects = prefs.getInt("target_prospects", 30)
        val targetGroups = prefs.getInt("target_groups", 20)

        card("🎯 Objetivo del día") {
            addView(line("Contactar prospectos: $prospectCount/$targetProspects", true))
            addView(line("Publicar en grupos: $doneToday/$targetGroups", true))
            addView(line("Clientes registrados: $clientCount", true))
            addView(line("Seguimientos pendientes: $dueFollowups", true))
            addView(line("Progreso estimado: ${dailyProgress()}%", false))
            addView(btn("🚀 Empezar a conseguir clientes", true) { publisher() })
            addView(btn("✍ Biblioteca de copys", false) { copies() })
            addView(btn("👥 Prospectos", false) { crm() })
            addView(btn("☰ Más herramientas", false) { more() })
        }

        card("Plan rápido de hoy") {
            addView(line("1. Publica en grupos activos de WhatsApp y Telegram.", false))
            addView(line("2. Guarda cada persona interesada como prospecto.", false))
            addView(line("3. Usa seguimiento 24h si no responde.", false))
            addView(line("4. Convierte a cliente cuando compre.", false))
        }
    }

    // FASE 3: Publicador transformado en "Buscar clientes"
    // Conserva toda la información existente de grupos/canales y publicaciones del día.
    private fun publisher() {
        shell("🎯 Buscar clientes")

        val groups = list("groups")
        val published = todayPublished()
        val pending = groups.filter { !published.contains(groupName(it)) }
        val copyDay = copyOfDay()

        card("Plan comercial de hoy") {
            addView(line("Objetivo: conseguir conversaciones reales, no solo publicar.", true))
            addView(line("1. Copia un mensaje atractivo.", false))
            addView(line("2. Publica en grupos/canales donde haya personas buscando streaming.", false))
            addView(line("3. Guarda como prospecto a quien responda.", false))
            addView(line("4. Haz seguimiento mañana si no compra.", false))
            addView(btn("Copiar mensaje del día", true) { copy(copyDay) })
            addView(btn("Abrir WhatsApp", false) { openWhatsAppOrLink("") })
            addView(btn("Abrir Telegram", false) { openTelegramHome() })
            addView(btn("Agregar prospecto", false) { crm() })
        }

        card("Progreso de búsqueda") {
            addView(line("Canales guardados: ${groups.size}", true))
            addView(line("Publicados hoy: ${published.size}/${groups.size}", true))
            addView(line("Pendientes hoy: ${pending.size}", true))
            addView(line("Progreso: ${publishProgress(groups.size, published.size)}%", false))
            addView(btn("Siguiente canal pendiente", true) { nextPublishStep() })
            addView(btn("Agregar canal/grupo", false) { groups() })
            addView(btn("Reiniciar publicados de hoy", false) {
                prefs.edit().putString(todayKey(), "").apply()
                publisher()
            })
        }

        card("Mensaje recomendado") {
            addView(line(copyDay, false))
            addView(btn("Compartir a WhatsApp", true) { shareToPackage(copyDay, "com.whatsapp") })
            addView(btn("Compartir a Telegram", false) { shareToPackage(copyDay, "org.telegram.messenger") })
            addView(btn("Cambiar copy del día", false) { copies() })
        }

        card("Checklist manual") {
            val tasks = listOf(
                "Publicar estado de WhatsApp",
                "Publicar en 5 grupos de WhatsApp",
                "Publicar en 5 grupos de Telegram",
                "Escribir a 10 personas que pidieron streaming",
                "Guardar interesados como prospectos",
                "Hacer seguimiento a prospectos pendientes"
            )
            tasks.forEachIndexed { i, task ->
                val key = "task_${today()}_$i"
                val done = prefs.getBoolean(key, false)
                addView(btn("${if (done) "✅" else "□"} $task", done) {
                    prefs.edit().putBoolean(key, !done).apply()
                    publisher()
                })
            }
        }

        if (pending.isEmpty()) {
            card("Día completado") {
                addView(line("Terminaste todos los canales guardados por hoy.", true))
                addView(line("Ahora revisa respuestas y guarda prospectos.", false))
                addView(btn("Ir a Prospectos", true) { crm() })
                addView(btn("Sumar racha diaria", false) {
                    val key = "streak_day"
                    if (prefs.getString(key, "") != today()) {
                        prefs.edit().putInt("streak", prefs.getInt("streak", 0) + 1).putString(key, today()).apply()
                    }
                    home()
                })
            }
        } else {
            pending.forEach { raw ->
                val name = groupName(raw)
                val link = groupLink(raw)
                card("Pendiente: $name") {
                    addView(line(if (link.isBlank()) "Sin link guardado. Se abrirá WhatsApp." else "Link: $link", false))
                    addView(btn("1. Copiar texto", true) { copy(copyDay) })
                    addView(btn("2. Abrir canal/grupo", false) { openWhatsAppOrLink(link) })
                    addView(btn("Compartir a WhatsApp", false) { shareToPackage(copyDay, "com.whatsapp") })
                    addView(btn("Compartir a Telegram", false) { shareToPackage(copyDay, "org.telegram.messenger") })
                    addView(btn("3. Marcar como publicado", true) {
                        markPublished(name)
                        publisher()
                    })
                }
            }
        }
    }

    private fun publishProgress(total: Int, done: Int): Int {
        if (total <= 0) return 0
        return ((done.toFloat() / total.toFloat()) * 100).toInt().coerceIn(0, 100)
    }

    private fun nextPublishStep() {
        val next = list("groups").firstOrNull { !todayPublished().contains(groupName(it)) }
        if (next == null) {
            toast("Ya completaste todos los grupos")
            publisher()
            return
        }
        val name = groupName(next)
        copy(copyOfDay())
        NexoAccessibilityService.targetGroup = name
        NexoAccessibilityService.targetText = copyOfDay()
        openWhatsAppOrLink(groupLink(next))
        toast("Texto copiado. Publica en: $name")
    }

    private fun groups() {
        shell("Canales y grupos")
        card("Agregar canal o grupo") {
            val name = input("Nombre del grupo/canal")
            val link = input("Link opcional")
            addView(name)
            addView(link)
            addView(btn("Guardar canal/grupo", true) {
                if (name.text.isBlank()) return@btn toast("Agrega nombre")
                save("groups", "${clean(name.text)}|${clean(link.text)}")
                groups()
            })
        }

        card("Accesibilidad opcional") {
            addView(line("Solo ayuda a abrir WhatsApp y ubicar grupos. El envío final lo haces tú.", false))
            addView(btn("Abrir ajustes de accesibilidad", true) {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            })
        }

        list("groups").forEachIndexed { i, raw ->
            val name = groupName(raw)
            val link = groupLink(raw)
            card(name) {
                addView(line(if (link.isBlank()) "Sin link guardado" else link, false))
                addView(btn("Abrir", false) { openWhatsAppOrLink(link) })
                addView(btn("Eliminar", false) {
                    deleteItem("groups", i)
                    groups()
                })
            }
        }
    }

    // FASE 2: Biblioteca de copys editable + generador local sin IA
    private fun copies() {
        shell("Biblioteca de copys")

        card("⚡ Generador local sin IA") {
            val service = input("Servicio. Ej: Disney Premium")
            val price = input("Precio. Ej: 8.5 USD")
            val target = input("Objetivo. Ej: vender, revendedor, estado")
            addView(service)
            addView(price)
            addView(target)
            addView(btn("Generar 10 copys", true) {
                val generated = generateCopies(
                    service.text.toString().ifBlank { "servicios de streaming" },
                    price.text.toString().ifBlank { "" },
                    target.text.toString().ifBlank { "venta" }
                )
                generated.forEachIndexed { index, body ->
                    saveCopy("Generado ${index + 1}", target.text.toString().ifBlank { "Generados" }, body, false)
                }
                toast("Copys generados y guardados")
                copies()
            })
        }

        card("Agregar copy manual") {
            val title = input("Título")
            val category = input("Categoría. Ej: Disney, Prime, Telegram")
            val body = input("Texto del copy")
            body.minLines = 3
            addView(title)
            addView(category)
            addView(body)
            addView(btn("Guardar copy", true) {
                if (body.text.isBlank()) return@btn toast("Agrega texto")
                saveCopy(
                    title.text.toString().ifBlank { "Copy" },
                    category.text.toString().ifBlank { "General" },
                    body.text.toString(),
                    false
                )
                copies()
            })
        }

        card("Acciones rápidas") {
            addView(btn("Crear paquete Disney", true) { createPack("Disney Premium", "8.5 USD", "Disney") })
            addView(btn("Crear paquete Prime", false) { createPack("Amazon Prime", "2 USD", "Prime") })
            addView(btn("Crear paquete Max", false) { createPack("Max Platino", "4.5 USD", "Max") })
            addView(btn("Ver favoritos primero", false) {
                prefs.edit().putBoolean("favorites_first", !prefs.getBoolean("favorites_first", false)).apply()
                copies()
            })
        }

        val all = copyList().let { list ->
            if (prefs.getBoolean("favorites_first", false)) list.sortedByDescending { it.favorite } else list
        }

        val categories = all.map { it.category }.distinct().ifEmpty { listOf("Sin copys") }
        card("Categorías") {
            addView(line(categories.joinToString("  •  "), false))
            addView(line("Total copys: ${all.size}", true))
        }

        all.forEachIndexed { index, item ->
            card("${if (item.favorite) "⭐ " else ""}${item.title}  •  ${item.category}") {
                addView(line(item.body, false))
                addView(btn("Copiar", true) { copy(item.body) })
                addView(btn("Compartir WhatsApp", false) { shareToPackage(item.body, "com.whatsapp") })
                addView(btn("Compartir Telegram", false) { shareToPackage(item.body, "org.telegram.messenger") })
                addView(btn("Usar como copy del día", false) {
                    prefs.edit().putString("copy_day", item.body).apply()
                    toast("Copy del día actualizado")
                })
                addView(btn(if (item.favorite) "Quitar favorito" else "Favorito", false) {
                    updateCopy(index, item.copy(favorite = !item.favorite))
                    copies()
                })
                addView(btn("Duplicar", false) {
                    saveCopy("${item.title} copia", item.category, item.body, item.favorite)
                    copies()
                })

                val editTitle = input("Editar título")
                editTitle.setText(item.title)
                val editCategory = input("Editar categoría")
                editCategory.setText(item.category)
                val editBody = input("Editar texto")
                editBody.minLines = 3
                editBody.setText(item.body)
                addView(editTitle)
                addView(editCategory)
                addView(editBody)
                addView(btn("Actualizar copy", true) {
                    updateCopy(index, CopyItem(
                        clean(editTitle.text),
                        clean(editCategory.text).ifBlank { "General" },
                        editBody.text.toString(),
                        item.favorite
                    ))
                    copies()
                })
                addView(btn("Eliminar", false) {
                    deleteCopy(index)
                    copies()
                })
            }
        }
    }

    private fun createPack(service: String, price: String, category: String) {
        generateCopies(service, price, category).forEachIndexed { i, body ->
            saveCopy("$category ${i + 1}", category, body, false)
        }
        toast("Paquete $category creado")
        copies()
    }

    private fun generateCopies(service: String, price: String, target: String): List<String> {
        val priceText = if (price.isBlank()) "" else " por $price"
        val endings = listOf(
            "Escríbeme y te doy los detalles.",
            "Pregunta disponibilidad sin compromiso.",
            "Atención rápida por WhatsApp o Telegram.",
            "Ideal si buscas una opción rápida y económica.",
            "Te ayudo con el proceso paso a paso."
        )
        val starts = listOf(
            "🎬 $service disponible$priceText.",
            "✅ Disponible hoy: $service$priceText.",
            "¿Buscas $service? Lo tengo disponible$priceText.",
            "🔥 Opción disponible: $service$priceText.",
            "📢 Para quienes buscan streaming: $service disponible$priceText."
        )
        val cta = listOf(
            "¿Aún lo necesitas?",
            "¿Te interesa activarlo hoy?",
            "Escríbeme si quieres más información.",
            "Puedo ayudarte con el servicio.",
            "Disponible para clientes y revendedores."
        )

        val result = mutableListOf<String>()
        for (i in 0 until 10) {
            val s = starts[i % starts.size]
            val e = endings[(i + 2) % endings.size]
            val c = cta[(i + 4) % cta.size]
            val label = if (target.isNotBlank()) "[$target] " else ""
            result.add("$label$s\n$e\n$c")
        }
        return result
    }

    private fun crm() {
        shell("Prospectos")
        card("Agregar prospecto") {
            val name = input("Nombre o alias")
            val contact = input("WhatsApp o usuario Telegram")
            val group = input("Grupo de origen")
            val prod = input("Servicio interesado")
            val notes = input("Notas")
            addView(name); addView(contact); addView(group); addView(prod); addView(notes)
            addView(btn("Guardar prospecto", true) {
                if (name.text.isBlank()) return@btn toast("Agrega nombre")
                val item = listOf(
                    clean(name.text),
                    clean(contact.text),
                    clean(group.text),
                    clean(prod.text),
                    "Nuevo",
                    today(),
                    clean(notes.text)
                ).joinToString("|")
                save("prospects", item)
                crm()
            })
        }

        val prospects = list("prospects")
        card("Resumen") {
            addView(line("Total prospectos: ${prospects.size}", true))
            addView(line("Nuevos: ${prospects.count { field(it, 4) == "Nuevo" }}", false))
            addView(line("Interesados: ${prospects.count { field(it, 4) == "Interesado" }}", false))
            addView(line("Esperando: ${prospects.count { field(it, 4) == "Esperando" }}", false))
        }

        prospects.forEachIndexed { i, raw ->
            val name = field(raw, 0).ifBlank { "Prospecto" }
            val contact = field(raw, 1)
            val group = field(raw, 2)
            val prod = field(raw, 3)
            val status = field(raw, 4).ifBlank { "Nuevo" }
            val date = field(raw, 5)
            val notes = field(raw, 6)

            card("$name  •  $status") {
                addView(line("Servicio: ${prod.ifBlank { "Sin definir" }}", true))
                addView(line("Contacto: ${contact.ifBlank { "Sin contacto" }}", false))
                addView(line("Grupo: ${group.ifBlank { "Sin grupo" }}", false))
                addView(line("Fecha: $date", false))
                if (notes.isNotBlank()) addView(line("Notas: $notes", false))

                addView(btn("Copiar mensaje inicial", true) {
                    val serviceText = prod.ifBlank { "servicios de streaming" }
                    copy("Hola 😊 vi que buscas $serviceText. En Nexo E Store tengo opciones disponibles. ¿Aún lo necesitas?")
                })
                addView(btn("Copiar seguimiento 24h", false) {
                    val serviceText = prod.ifBlank { "el servicio" }
                    copy("Hola $name 😊 paso a confirmar si aún te interesa $serviceText. Estoy atento para ayudarte.")
                })
                addView(btn("Abrir WhatsApp", false) {
                    val digits = contact.replace(Regex("\\D"), "")
                    if (digits.isBlank()) toast("No hay número válido") else open("https://wa.me/$digits")
                })
                addView(btn("Abrir Telegram", false) {
                    val user = contact.replace("@", "").trim()
                    if (user.isBlank()) toast("No hay usuario Telegram") else open("https://t.me/$user")
                })
                addView(btn("Marcar interesado", false) { updateProspectStatus(i, "Interesado"); crm() })
                addView(btn("Marcar esperando", false) { updateProspectStatus(i, "Esperando"); crm() })
                addView(btn("Programar seguimiento 24h", true) {
                    saveFollowup(name, contact, prod, group, tomorrow(), "Pendiente", "Desde prospecto")
                    updateProspectStatus(i, "Esperando")
                    toast("Seguimiento creado para mañana")
                    crm()
                })
                addView(btn("Convertir en cliente", true) { convertProspectToClient(raw); updateProspectStatus(i, "Cliente"); crm() })
                addView(btn("Marcar perdido", false) { updateProspectStatus(i, "Perdido"); crm() })
                addView(btn("Eliminar prospecto", false) { deleteItem("prospects", i); crm() })
            }
        }
    }


    // FASE 4: Seguimientos sin perder información.
    // Usa una nueva clave "followups"; no modifica copys, grupos, prospectos ni clientes existentes.
    private fun followups() {
        shell("🔔 Seguimientos")

        val due = dueFollowups()
        val all = followupList()
        val prospects = list("prospects")

        card("Pendientes de hoy") {
            addView(line("Seguimientos vencidos o para hoy: ${due.size}", true))
            addView(line("Total programados: ${all.size}", false))
            addView(line("Consejo: escribe primero a quienes ya mostraron interés.", false))
            addView(btn("Crear seguimiento manual", false) { /* la tarjeta inferior queda visible */ })
        }

        card("Agregar seguimiento manual") {
            val name = input("Nombre o alias")
            val contact = input("WhatsApp o usuario Telegram")
            val service = input("Servicio. Ej: Disney Premium")
            val source = input("Grupo/origen")
            val notes = input("Notas")
            addView(name); addView(contact); addView(service); addView(source); addView(notes)
            addView(btn("Guardar para mañana", true) {
                if (name.text.isBlank()) return@btn toast("Agrega nombre")
                saveFollowup(
                    clean(name.text),
                    clean(contact.text),
                    clean(service.text),
                    clean(source.text),
                    tomorrow(),
                    "Pendiente",
                    clean(notes.text)
                )
                toast("Seguimiento guardado para mañana")
                followups()
            })
            addView(btn("Guardar para hoy", false) {
                if (name.text.isBlank()) return@btn toast("Agrega nombre")
                saveFollowup(
                    clean(name.text),
                    clean(contact.text),
                    clean(service.text),
                    clean(source.text),
                    today(),
                    "Pendiente",
                    clean(notes.text)
                )
                followups()
            })
        }

        if (due.isEmpty()) {
            card("Sin seguimientos vencidos") {
                addView(line("No tienes seguimientos pendientes para hoy.", true))
                addView(line("Puedes crear uno manualmente o programarlo desde Prospectos.", false))
            }
        }

        due.forEachIndexed { visibleIndex, raw ->
            val realIndex = all.indexOf(raw)
            drawFollowupCard(raw, realIndex)
        }

        card("Crear desde prospectos") {
            addView(line("Prospectos que no son cliente ni perdido:", true))
        }
        prospects.forEach { raw ->
            val status = field(raw, 4)
            if (status != "Cliente" && status != "Perdido") {
                val name = field(raw, 0).ifBlank { "Prospecto" }
                val contact = field(raw, 1)
                val group = field(raw, 2)
                val prod = field(raw, 3)
                card("Prospecto: $name") {
                    addView(line("Servicio: ${prod.ifBlank { "Sin definir" }}", false))
                    addView(line("Estado: ${status.ifBlank { "Nuevo" }}", false))
                    addView(btn("Programar seguimiento mañana", true) {
                        saveFollowup(name, contact, prod, group, tomorrow(), "Pendiente", "Creado desde Prospectos")
                        toast("Seguimiento creado")
                        followups()
                    })
                    addView(btn("Programar seguimiento hoy", false) {
                        saveFollowup(name, contact, prod, group, today(), "Pendiente", "Creado desde Prospectos")
                        followups()
                    })
                }
            }
        }

        if (all.isNotEmpty()) {
            card("Todos los seguimientos") {
                addView(line("Aquí puedes limpiar seguimientos ya realizados si lo necesitas.", false))
                addView(btn("Eliminar realizados", false) {
                    val kept = followupList().filter { field(it, 5) != "Realizado" }
                    prefs.edit().putString("followups", kept.joinToString("\n")).apply()
                    followups()
                })
            }
            all.forEachIndexed { i, raw ->
                if (!due.contains(raw)) drawFollowupCard(raw, i)
            }
        }
    }

    private fun drawFollowupCard(raw: String, index: Int) {
        val name = field(raw, 0).ifBlank { "Contacto" }
        val contact = field(raw, 1)
        val service = field(raw, 2).ifBlank { "el servicio" }
        val source = field(raw, 3)
        val dueDate = field(raw, 4).ifBlank { today() }
        val status = field(raw, 5).ifBlank { "Pendiente" }
        val notes = field(raw, 6)

        card("$name  •  $status  •  $dueDate") {
            addView(line("Interés: $service", true))
            if (contact.isNotBlank()) addView(line("Contacto: $contact", false))
            if (source.isNotBlank()) addView(line("Origen: $source", false))
            if (notes.isNotBlank()) addView(line("Notas: $notes", false))
            addView(btn("Copiar mensaje de seguimiento", true) {
                copy("Hola $name 😊 paso a confirmar si aún te interesa $service. Estoy atento para ayudarte.")
            })
            addView(btn("Abrir WhatsApp", false) {
                val digits = contact.replace(Regex("\\D"), "")
                if (digits.isBlank()) toast("No hay número válido") else open("https://wa.me/$digits")
            })
            addView(btn("Abrir Telegram", false) {
                val user = contact.replace("@", "").trim()
                if (user.isBlank()) toast("No hay usuario Telegram") else open("https://t.me/$user")
            })
            addView(btn("Marcar realizado", true) {
                updateFollowupStatus(index, "Realizado")
                followups()
            })
            addView(btn("Posponer mañana", false) {
                updateFollowupDate(index, tomorrow())
                followups()
            })
            addView(btn("Convertir en cliente", false) {
                save("clients", listOf(name, contact, service, today()).joinToString("|"))
                updateFollowupStatus(index, "Realizado")
                toast("Cliente guardado")
                followups()
            })
            addView(btn("Eliminar seguimiento", false) {
                deleteItem("followups", index)
                followups()
            })
        }
    }

    private fun clients() {
        shell("💰 Clientes")

        val clients = list("clients")
        val totalUsd = clients.sumOf { clientAmount(it) }

        card("Resumen de clientes") {
            addView(line("Clientes guardados: ${clients.size}", true))
            addView(line("Ventas registradas estimadas: ${formatUsd(totalUsd)} USD", true))
            addView(line("Entregados: ${clients.count { clientStatus(it) == "Entregado" }}", false))
            addView(line("Pendientes: ${clients.count { clientStatus(it) != "Entregado" }}", false))
            addView(btn("📊 Ver dashboard", true) { dashboard() })
            addView(btn("👥 Ver prospectos", false) { crm() })
        }

        card("Agregar cliente manual") {
            val name = input("Nombre o alias")
            val contact = input("WhatsApp o Telegram")
            val service = input("Servicio vendido. Ej: Disney Premium")
            val amount = input("Valor. Ej: 8.5")
            val payment = input("Método de pago. Ej: Nequi / Binance")
            val notes = input("Notas")
            addView(name); addView(contact); addView(service); addView(amount); addView(payment); addView(notes)
            addView(btn("Guardar cliente", true) {
                if (name.text.isBlank()) return@btn toast("Agrega nombre")
                saveClient(
                    clean(name.text),
                    clean(contact.text),
                    clean(service.text),
                    clean(amount.text),
                    clean(payment.text),
                    today(),
                    "",
                    "Pendiente",
                    clean(notes.text)
                )
                toast("Cliente guardado")
                clients()
            })
        }

        if (clients.isEmpty()) {
            card("Aún no hay clientes") {
                addView(line("Cuando un prospecto compre, conviértelo en cliente desde Prospectos o regístralo aquí.", false))
            }
        }

        clients.forEachIndexed { i, raw ->
            val name = clientName(raw).ifBlank { "Cliente" }
            val contact = clientContact(raw)
            val service = clientService(raw).ifBlank { "Servicio no definido" }
            val amount = clientAmount(raw)
            val payment = clientPayment(raw).ifBlank { "Sin método" }
            val date = clientDate(raw).ifBlank { today() }
            val status = clientStatus(raw).ifBlank { "Pendiente" }
            val notes = clientNotes(raw)

            card("$name  •  $status") {
                addView(line("Servicio: $service", true))
                addView(line("Valor: ${formatUsd(amount)} USD", true))
                addView(line("Pago: $payment", false))
                addView(line("Contacto: ${contact.ifBlank { "Sin contacto" }}", false))
                addView(line("Fecha: $date", false))
                if (notes.isNotBlank()) addView(line("Notas: $notes", false))

                val postventa = "Gracias por tu compra, $name 😊\nTu pedido de $service queda registrado. Cualquier novedad me escribes y te ayudo."
                val renewal = "Hola $name 😊 ¿Deseas renovar o consultar disponibilidad de $service? Estoy atento para ayudarte."

                addView(btn("Copiar postventa", true) { copy(postventa) })
                addView(btn("Compartir postventa WhatsApp", false) { shareToPackage(postventa, "com.whatsapp") })
                addView(btn("Compartir postventa Telegram", false) { shareToPackage(postventa, "org.telegram.messenger") })
                addView(btn("Copiar mensaje renovación", false) { copy(renewal) })
                addView(btn("Marcar entregado", false) { updateClientStatus(i, "Entregado"); clients() })
                addView(btn("Marcar pendiente", false) { updateClientStatus(i, "Pendiente"); clients() })
                addView(btn("Crear seguimiento postventa", false) {
                    saveFollowup(name, contact, service, "Cliente", tomorrow(), "Pendiente", "Seguimiento postventa")
                    toast("Seguimiento creado para mañana")
                    followups()
                })
                addView(btn("Eliminar cliente", false) { deleteItem("clients", i); clients() })
            }
        }
    }

    private fun dashboard() {
        shell("📊 Dashboard")

        val prospects = list("prospects")
        val clients = list("clients")
        val followups = followupList()
        val copies = list("copies")
        val groups = list("groups")
        val published = todayPublished()

        val interested = prospects.count { field(it, 4) == "Interesado" }
        val waiting = prospects.count { field(it, 4) == "Esperando" }
        val newProspects = prospects.count { field(it, 4).ifBlank { "Nuevo" } == "Nuevo" }
        val due = dueFollowups().size
        val totalSales = clients.sumOf { clientAmount(it) }
        val conversion = if (prospects.isNotEmpty()) ((clients.size.toFloat() / prospects.size) * 100).toInt() else 0

        card("Resumen de hoy") {
            addView(line("Prospectos: ${prospects.size}", true))
            addView(line("Clientes: ${clients.size}", true))
            addView(line("Conversión estimada: $conversion%", true))
            addView(line("Ventas estimadas: ${formatUsd(totalSales)} USD", true))
            addView(line("Seguimientos pendientes: $due", false))
            addView(line("Publicados hoy: ${published.size}/${groups.size}", false))
        }

        card("Embudo comercial") {
            addView(line("🟢 Nuevos: $newProspects", false))
            addView(line("🟡 Interesados: $interested", false))
            addView(line("🟠 Esperando: $waiting", false))
            addView(line("🔵 Clientes: ${clients.size}", false))
            addView(line("🔴 Perdidos: ${prospects.count { field(it, 4) == "Perdido" }}", false))
        }

        card("Servicios más vendidos") {
            val byService = clients.groupingBy { clientService(it).ifBlank { "Sin servicio" } }.eachCount()
            if (byService.isEmpty()) {
                addView(line("Aún no hay ventas registradas.", false))
            } else {
                byService.entries.sortedByDescending { it.value }.forEach {
                    addView(line("${it.key}: ${it.value}", true))
                }
            }
        }

        card("Productividad") {
            addView(line("Copys guardados: ${copies.size}", false))
            addView(line("Canales/grupos guardados: ${groups.size}", false))
            addView(line("Progreso diario: ${dailyProgress()}%", true))
            addView(btn("🚀 Empezar a conseguir clientes", true) { publisher() })
            addView(btn("👥 Agregar prospecto", false) { crm() })
            addView(btn("🔔 Ver seguimientos", false) { followups() })
        }

        card("Lectura rápida") {
            val msg = when {
                prospects.isEmpty() -> "Empieza guardando prospectos. Sin prospectos no hay ventas."
                due > 0 -> "Hoy tienes seguimientos pendientes. Escríbelos antes de buscar nuevos."
                clients.isEmpty() -> "Ya tienes prospectos. Enfócate en cerrar la primera venta."
                else -> "Sigue publicando, registrando prospectos y haciendo seguimiento diario."
            }
            addView(line(msg, true))
        }
    }

    private fun goals() {
        shell("Metas")
        card("Metas diarias") {
            val prospects = input("Meta prospectos")
            prospects.setText(prefs.getInt("target_prospects", 30).toString())
            val groups = input("Meta grupos")
            groups.setText(prefs.getInt("target_groups", 20).toString())
            addView(prospects)
            addView(groups)
            addView(btn("Guardar metas", true) {
                prefs.edit()
                    .putInt("target_prospects", prospects.text.toString().toIntOrNull() ?: 30)
                    .putInt("target_groups", groups.text.toString().toIntOrNull() ?: 20)
                    .apply()
                toast("Metas guardadas")
                home()
            })
        }
        card("Notificaciones") {
            addView(btn("Notificación de prueba", true) {
                NotificationHelper.notifyNow(this@MainActivity, 7777, "Prueba", "Notificaciones funcionando.")
            })
            addView(btn("Recordatorio en 1 minuto", false) {
                ReminderScheduler.scheduleInMinutes(this@MainActivity, 1, 9001, "Publicación pendiente", "Abre la app y publica en el siguiente grupo.")
                toast("Programado en 1 minuto")
            })
            addView(btn("Recordatorio persistente cada 30 min", false) {
                ReminderScheduler.schedulePersistent(this@MainActivity)
                toast("Recordatorio persistente activado")
            })
        }
    }

    private fun dailyProgress(): Int {
        val p = list("prospects").size
        val g = todayPublished().size
        val tp = prefs.getInt("target_prospects", 30).coerceAtLeast(1)
        val tg = prefs.getInt("target_groups", 20).coerceAtLeast(1)
        val value = ((p.toFloat() / tp) * 50 + (g.toFloat() / tg) * 50).toInt()
        return value.coerceIn(0, 100)
    }

    private fun copyOfDay() = prefs.getString(
        "copy_day",
        "🔥 Streaming disponible\n\n✅ Amazon Prime 2 USD\n✅ Max Platino 4.5 USD\n✅ Disney Premium 8.5 USD\n\nEscríbeme y te ayudo con disponibilidad."
    ) ?: ""

    private fun seed() {
        if (prefs.getBoolean("seeded_v2", false)) return
        prefs.edit()
            .putString("groups", "PUBLICIDAD STREAMING LATAM|\nPROVEEDORES STREAMING|\nSTREAMING REVENDEDORES|")
            .putString(
                "copies",
                listOf(
                    encodeCopy(CopyItem("Disney directo", "Disney", "🎬 Disney Premium disponible por 8.5 USD.\nEscríbeme y te doy los detalles.", false)),
                    encodeCopy(CopyItem("Prime económico", "Prime", "✅ Amazon Prime disponible por 2 USD.\nBuena opción si buscas streaming económico.", false)),
                    encodeCopy(CopyItem("Max Platino", "Max", "🍿 Max Platino disponible por 4.5 USD.\nPregunta disponibilidad sin compromiso.", false)),
                    encodeCopy(CopyItem("Estado WhatsApp", "Estados", "Disponible hoy ✅\nAmazon Prime, Max Platino y Disney Premium.\nEscríbeme si necesitas alguno.", true))
                ).joinToString("\n")
            )
            .putBoolean("seeded_v2", true)
            .apply()
    }

    data class CopyItem(val title: String, val category: String, val body: String, val favorite: Boolean)

    private fun copyList(): MutableList<CopyItem> {
        return list("copies").map { decodeCopy(it) }.toMutableList()
    }

    private fun saveCopy(title: String, category: String, body: String, favorite: Boolean) {
        save("copies", encodeCopy(CopyItem(safe(title), safe(category), body, favorite)))
    }

    private fun updateCopy(index: Int, item: CopyItem) {
        val l = list("copies")
        if (index in l.indices) {
            l[index] = encodeCopy(item)
            prefs.edit().putString("copies", l.joinToString("\n")).apply()
        }
    }

    private fun deleteCopy(index: Int) {
        deleteItem("copies", index)
    }

    private fun encodeCopy(item: CopyItem): String {
        return listOf(
            safe(item.title),
            safe(item.category),
            item.body.replace("|", " ").replace("\n", "\\n"),
            if (item.favorite) "1" else "0"
        ).joinToString("|")
    }

    private fun decodeCopy(raw: String): CopyItem {
        val p = raw.split("|")
        return CopyItem(
            p.getOrElse(0) { "Copy" },
            p.getOrElse(1) { "General" },
            p.getOrElse(2) { "" }.replace("\\n", "\n"),
            p.getOrElse(3) { "0" } == "1"
        )
    }

    private fun safe(s: String) = s.replace("|", " ").replace("\n", " ").trim()


    private fun saveClient(
        name: String,
        contact: String,
        service: String,
        amount: String,
        payment: String,
        date: String,
        renewal: String,
        status: String,
        notes: String
    ) {
        save("clients", listOf(
            safe(name),
            safe(contact),
            safe(service),
            safe(amount),
            safe(payment),
            safe(date),
            safe(renewal),
            safe(status),
            safe(notes)
        ).joinToString("|"))
    }

    private fun clientParts(raw: String): List<String> = raw.split("|")

    private fun clientName(raw: String) = field(raw, 0)
    private fun clientContact(raw: String) = field(raw, 1)
    private fun clientService(raw: String) = field(raw, 2)

    private fun clientAmount(raw: String): Double {
        val p = clientParts(raw)
        val value = if (p.size >= 9) p.getOrElse(3) { "" } else ""
        return value.replace("USD", "", true).replace(",", ".").trim().toDoubleOrNull() ?: 0.0
    }

    private fun clientPayment(raw: String): String {
        val p = clientParts(raw)
        return if (p.size >= 9) p.getOrElse(4) { "" } else ""
    }

    private fun clientDate(raw: String): String {
        val p = clientParts(raw)
        return if (p.size >= 9) p.getOrElse(5) { "" } else field(raw, 3)
    }

    private fun clientStatus(raw: String): String {
        val p = clientParts(raw)
        return if (p.size >= 9) p.getOrElse(7) { "Pendiente" } else "Pendiente"
    }

    private fun clientNotes(raw: String): String {
        val p = clientParts(raw)
        return if (p.size >= 9) p.getOrElse(8) { "" } else ""
    }

    private fun formatUsd(value: Double): String {
        return if (value % 1.0 == 0.0) value.toInt().toString() else String.format(Locale.US, "%.2f", value)
    }

    private fun updateClientStatus(index: Int, status: String) {
        val l = list("clients")
        if (index !in l.indices) return
        val p = l[index].split("|").toMutableList()

        if (p.size < 9) {
            val oldName = p.getOrElse(0) { "" }
            val oldContact = p.getOrElse(1) { "" }
            val oldService = p.getOrElse(2) { "" }
            val oldDate = p.getOrElse(3) { today() }
            while (p.size < 9) p.add("")
            p[0] = oldName
            p[1] = oldContact
            p[2] = oldService
            p[3] = ""
            p[4] = ""
            p[5] = oldDate
            p[6] = ""
            p[7] = status
            p[8] = ""
        } else {
            p[7] = status
        }

        l[index] = p.joinToString("|")
        prefs.edit().putString("clients", l.joinToString("\n")).apply()
    }

    private fun convertProspectToClient(raw: String) {
        val name = field(raw, 0)
        val contact = field(raw, 1)
        val prod = field(raw, 3)
        val notes = field(raw, 6)
        saveClient(name, contact, prod, "", "", today(), "", "Pendiente", notes)
        toast("Cliente guardado")
    }

    private fun updateProspectStatus(i: Int, status: String) {
        val l = list("prospects")
        if (i !in l.indices) return
        val p = l[i].split("|").toMutableList()
        while (p.size < 7) p.add("")
        p[4] = status
        l[i] = p.joinToString("|")
        prefs.edit().putString("prospects", l.joinToString("\n")).apply()
    }


    private fun followupList(): MutableList<String> = list("followups")

    private fun saveFollowup(name: String, contact: String, service: String, source: String, dueDate: String, status: String, notes: String) {
        val item = listOf(
            safe(name),
            safe(contact),
            safe(service),
            safe(source),
            safe(dueDate),
            safe(status),
            safe(notes)
        ).joinToString("|")
        save("followups", item)
    }

    private fun dueFollowups(): List<String> {
        val todayValue = today()
        return followupList().filter {
            val status = field(it, 5)
            val due = field(it, 4).ifBlank { todayValue }
            status != "Realizado" && due <= todayValue
        }
    }

    private fun updateFollowupStatus(index: Int, status: String) {
        val l = followupList()
        if (index !in l.indices) return
        val p = l[index].split("|").toMutableList()
        while (p.size < 7) p.add("")
        p[5] = status
        l[index] = p.joinToString("|")
        prefs.edit().putString("followups", l.joinToString("\n")).apply()
    }

    private fun updateFollowupDate(index: Int, dueDate: String) {
        val l = followupList()
        if (index !in l.indices) return
        val p = l[index].split("|").toMutableList()
        while (p.size < 7) p.add("")
        p[4] = dueDate
        p[5] = "Pendiente"
        l[index] = p.joinToString("|")
        prefs.edit().putString("followups", l.joinToString("\n")).apply()
    }

    private fun shareToPackage(text: String, packageName: String) {
        // Siempre abre el selector de aplicaciones.
        // Así puedes elegir WhatsApp, Telegram, Facebook, Estados, grupos, etc.
        try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
            }
            startActivity(Intent.createChooser(intent, "Compartir copy"))
        } catch (e: Exception) {
            copy(text)
            toast("No se pudo abrir el selector. Texto copiado.")
        }
    }

    private fun openTelegramHome() {
        val i = packageManager.getLaunchIntentForPackage("org.telegram.messenger")
        if (i != null) startActivity(i) else open("https://t.me/")
    }

    private fun openWhatsAppOrLink(link: String) {
        if (link.startsWith("http")) {
            open(link)
        } else {
            val i = packageManager.getLaunchIntentForPackage("com.whatsapp")
            if (i != null) startActivity(i) else open("https://wa.me/")
        }
    }

    private fun groupName(raw: String) = field(raw, 0).ifBlank { "Grupo" }
    private fun groupLink(raw: String) = field(raw, 1)
    private fun todayKey() = "published_${today()}"
    private fun todayPublished() = list(todayKey()).toSet()

    private fun markPublished(name: String) {
        val l = list(todayKey())
        if (!l.contains(name)) l.add(name)
        prefs.edit().putString(todayKey(), l.joinToString("\n")).apply()
    }

    private fun card(title: String, build: LinearLayout.() -> Unit) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setBackgroundColor(panel)
        box.setPadding(18, 18, 18, 18)
        val tv = TextView(this)
        tv.text = title
        tv.textSize = 18f
        tv.setTextColor(white)
        tv.setTypeface(null, 1)
        box.addView(tv)
        box.build()
        val lp = LinearLayout.LayoutParams(-1, -2)
        lp.setMargins(0, 0, 0, 16)
        content.addView(box, lp)
    }

    private fun line(s: String, strong: Boolean): TextView {
        val v = TextView(this)
        v.text = s
        v.textSize = 15f
        v.setTextColor(if (strong) teal else white)
        if (strong) v.setTypeface(null, 1)
        v.setPadding(0, 6, 0, 6)
        return v
    }

    private fun input(h: String): EditText {
        val e = EditText(this)
        e.hint = h
        e.setHintTextColor(muted)
        e.setTextColor(white)
        e.setBackgroundColor(Color.rgb(6, 17, 19))
        e.setPadding(14, 12, 14, 12)
        return e
    }

    private fun btn(label: String, primary: Boolean, action: () -> Unit): Button {
        val b = Button(this)
        b.text = label
        b.textSize = 13f
        b.setTextColor(if (primary) Color.BLACK else white)
        b.setBackgroundColor(if (primary) teal else dark)
        b.setOnClickListener { action() }
        return b
    }

    private fun clean(x: CharSequence) = x.toString().replace("|", " ").replace("\n", " ").trim()

    private fun list(k: String): MutableList<String> {
        return (prefs.getString(k, "") ?: "").split("\n").filter { it.isNotBlank() }.toMutableList()
    }

    private fun save(k: String, item: String) {
        val l = list(k)
        l.add(0, item)
        prefs.edit().putString(k, l.joinToString("\n")).apply()
    }

    private fun deleteItem(k: String, i: Int) {
        val l = list(k)
        if (i in l.indices) {
            l.removeAt(i)
            prefs.edit().putString(k, l.joinToString("\n")).apply()
        }
    }

    private fun field(raw: String, index: Int): String = raw.split("|").getOrElse(index) { "" }

    private fun today() = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    private fun tomorrow(): String {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, 1)
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun copy(s: String) {
        (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Nexo", s))
        toast("Copiado")
    }

    private fun open(url: String) {
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: Exception) {
            toast("No se pudo abrir")
        }
    }

    private fun askNotif() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 10)
        }
    }
}
