package com.nexo.marketingia

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var content: LinearLayout
    private val prefs by lazy { getSharedPreferences("nexo_v2", MODE_PRIVATE) }
    private val bg = Color.rgb(4,7,8)
    private val panel = Color.rgb(16,26,29)
    private val teal = Color.rgb(22,242,226)
    private val white = Color.rgb(244,255,255)
    private val muted = Color.rgb(150,167,170)

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        channel()
        askNotifications()
        home()
    }

    private fun shell(title: String) {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(bg)
        root.setPadding(20,24,20,20)

        val scroll = ScrollView(this)
        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))

        val h = TextView(this)
        h.text = "Nexo Marketing IA"
        h.textSize = 26f
        h.setTextColor(teal)
        h.setTypeface(null,1)
        content.addView(h)

        val s = TextView(this)
        s.text = "Publicar · prospectos · seguimiento · ventas"
        s.setTextColor(muted)
        s.setPadding(0,4,0,16)
        content.addView(s)

        val t = TextView(this)
        t.text = title
        t.textSize = 22f
        t.setTextColor(white)
        t.setTypeface(null,1)
        t.setPadding(0,0,0,12)
        content.addView(t)

        val nav = LinearLayout(this)
        nav.orientation = LinearLayout.HORIZONTAL
        nav.gravity = Gravity.CENTER
        listOf("Hoy" to {home()}, "Publicar" to {publish()}, "Clientes" to {crm()}, "IA" to {ai()}, "Metas" to {goals()}).forEach { (label, action) ->
            nav.addView(button(label,false){ action() }, LinearLayout.LayoutParams(0,-2,1f))
        }
        content.addView(nav)
        setContentView(root)
    }

    private fun home() {
        shell("Panel de hoy")
        card("Resumen") {
            addView(line("Publicaciones hoy: ${prefs.getInt("pubs",0)}/10", true))
            addView(line("Ventas hoy: ${prefs.getInt("sales",0)}/2", true))
            addView(line("Prospectos guardados: ${list("prospects").size}", true))
            addView(line("Seguimientos pendientes: ${pending()}", true))
        }
        card("Acciones rápidas") {
            addView(button("Copiar publicación del día", true){ copy(defaultPromo()) })
            addView(button("Abrir Nexo E Store", false){ open("https://www.nexoestore.com") })
            addView(button("Activar recordatorios", false){ scheduleAll(); toast("Recordatorios activados") })
        }
        card("Plan recomendado") {
            addView(line("1. Publica 10 veces en grupos o estados.", false))
            addView(line("2. Registra cada interesado.", false))
            addView(line("3. Responde con IA comercial.", false))
            addView(line("4. Haz seguimiento en la noche.", false))
        }
    }

    private fun publish() {
        shell("Publicaciones")
        listOf("Amazon Prime" to "US$2.00", "Max Platino 4K" to "US$4.50", "Disney Premium" to "US$8.00", "Combo Streaming" to "Consultar").forEach { (p, price) ->
            card(p) {
                addView(line("Precio proveedor: $price", true))
                addView(button("Copiar promoción", true){ copy(promo(p, price)) })
                addView(button("Compartir WhatsApp", false){ share(promo(p, price)) })
                addView(button("Marcar publicado", false){
                    prefs.edit().putInt("pubs", prefs.getInt("pubs",0)+1).apply()
                    toast("Publicación marcada")
                })
            }
        }
    }

    private fun crm() {
        shell("Clientes / CRM")
        card("Agregar prospecto") {
            val name = input("Nombre")
            val phone = input("WhatsApp")
            val product = input("Producto")
            addView(name); addView(phone); addView(product)
            addView(button("Guardar prospecto", true){
                if(name.text.isBlank()) return@button toast("Agrega nombre")
                save("prospects", "${name.text}|${phone.text}|${product.text}|Nuevo|${today()}")
                crm()
            })
        }
        val items = list("prospects")
        if(items.isEmpty()) card("Sin prospectos") { addView(line("Guarda aquí cada persona interesada.", false)) }
        items.forEachIndexed { i, raw ->
            val parts = raw.split("|")
            val name = parts.getOrElse(0){"Cliente"}
            val phone = parts.getOrElse(1){""}
            val prod = parts.getOrElse(2){""}
            val status = parts.getOrElse(3){"Nuevo"}
            card(name) {
                addView(line("Producto: $prod", false))
                addView(line("Estado: $status", true))
                addView(button("Abrir WhatsApp", false){ if(phone.isBlank()) toast("Sin número") else open("https://wa.me/${phone.replace(Regex("\\D"),"")}") })
                addView(button("Copiar seguimiento", true){ copy("Hola $name 😊 ¿aún deseas información sobre $prod? Puedes comprar con entrega automática en www.nexoestore.com") })
                addView(button("Marcar compró", false){ updateStatus(i, raw, "Compró"); prefs.edit().putInt("sales", prefs.getInt("sales",0)+1).apply(); crm() })
                addView(button("Marcar perdido", false){ updateStatus(i, raw, "Perdido"); crm() })
            }
        }
    }

    private fun ai() {
        shell("IA Comercial rápida")
        card("Generar respuesta") {
            val q = input("¿Qué preguntó el cliente?")
            addView(q)
            addView(button("Generar y copiar", true){
                val t = q.text.toString().lowercase()
                val service = when {
                    "prime" in t || "amazon" in t -> "Amazon Prime Video"
                    "max" in t || "hbo" in t -> "Max Platino 4K"
                    "disney" in t -> "Disney Premium"
                    else -> "servicios streaming"
                }
                copy("¡Hola! 😊 Sí, tenemos $service disponible.\n\nCompra desde www.nexoestore.com\n\n✅ Registro gratis\n✅ Recarga saldo\n✅ Entrega automática\n✅ Soporte por WhatsApp\n\n¿Lo deseas para ti o para revender?")
            })
        }
        card("Respuestas rápidas") {
            addView(button("Cómo registrarse", true){ copy("Ingresa a www.nexoestore.com, crea tu cuenta gratis, recarga saldo y envíame el ID o comprobante para validarlo.") })
            addView(button("Beneficios PRO", true){ copy("El Plan PRO incluye 30% de descuento en compras de servicios streaming a precio proveedor y prioridad en soporte por WhatsApp durante horario de atención.") })
            addView(button("Stock en web", true){ copy("Todo el stock disponible está en www.nexoestore.com. La compra se realiza desde la web y la entrega es automática.") })
        }
    }

    private fun goals() {
        shell("Metas y recordatorios")
        card("Metas diarias") {
            addView(line("Publicaciones: ${prefs.getInt("pubs",0)}/10", true))
            addView(line("Ventas: ${prefs.getInt("sales",0)}/2", true))
            addView(line("Seguimientos: ${pending()}/5", true))
            addView(button("Reiniciar conteo", false){ prefs.edit().putInt("pubs",0).putInt("sales",0).apply(); goals() })
        }
        card("Notificaciones") {
            addView(line("8:00 AM: publicar", false))
            addView(line("2:00 PM: responder prospectos", false))
            addView(line("8:00 PM: seguimiento", false))
            addView(button("Activar recordatorios", true){ scheduleAll(); toast("Recordatorios activados") })
        }
    }

    private fun card(title:String, build: LinearLayout.()->Unit) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setBackgroundColor(panel)
        box.setPadding(18,18,18,18)
        val tv = TextView(this)
        tv.text = title
        tv.textSize = 18f
        tv.setTextColor(white)
        tv.setTypeface(null,1)
        box.addView(tv)
        box.build()
        val lp = LinearLayout.LayoutParams(-1,-2)
        lp.setMargins(0,0,0,16)
        content.addView(box, lp)
    }

    private fun line(s:String, strong:Boolean): TextView {
        val v = TextView(this)
        v.text = s
        v.textSize = 15f
        v.setTextColor(if(strong) teal else white)
        if(strong) v.setTypeface(null,1)
        v.setPadding(0,6,0,6)
        return v
    }

    private fun input(hint:String): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setHintTextColor(muted)
        e.setTextColor(white)
        e.setBackgroundColor(Color.rgb(6,17,19))
        e.setPadding(14,12,14,12)
        return e
    }

    private fun button(label:String, primary:Boolean, action:()->Unit): Button {
        val b = Button(this)
        b.text = label
        b.textSize = 13f
        b.setTextColor(if(primary) Color.BLACK else white)
        b.setBackgroundColor(if(primary) teal else Color.rgb(23,38,41))
        b.setOnClickListener { action() }
        return b
    }

    private fun promo(p:String, price:String) = "🔥 Stock disponible para revendedores\n\n✅ $p\n💰 Precio proveedor: $price\n\n⚡ Entrega automática\n⚡ Registro gratis\n⚡ Compra directa desde la web\n\n🌐 www.nexoestore.com"
    private fun defaultPromo() = promo("Amazon Prime · Max Platino · Disney Premium", "Desde US$2")
    private fun copy(s:String){ (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Nexo",s)); toast("Copiado") }
    private fun share(s:String){ try{ startActivity(Intent(Intent.ACTION_SEND).apply{ type="text/plain"; setPackage("com.whatsapp"); putExtra(Intent.EXTRA_TEXT,s) }) }catch(e:Exception){ copy(s); toast("WhatsApp no disponible, texto copiado") } }
    private fun open(url:String){ try{ startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }catch(e:Exception){ toast("No se pudo abrir") } }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
    private fun list(k:String)=prefs.getString(k,"")!!.split("\n").filter{it.isNotBlank()}.toMutableList()
    private fun save(k:String, item:String){ val l=list(k); l.add(0,item); prefs.edit().putString(k,l.joinToString("\n")).apply() }
    private fun updateStatus(i:Int, raw:String, st:String){ val l=list("prospects"); val p=raw.split("|").toMutableList(); while(p.size<5)p.add(""); p[3]=st; l[i]=p.joinToString("|"); prefs.edit().putString("prospects",l.joinToString("\n")).apply() }
    private fun pending()=list("prospects").count{it.contains("|Nuevo|")||it.contains("|Interesado|")}
    private fun today()=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date())

    private fun channel(){ if(Build.VERSION.SDK_INT>=26){ val c=NotificationChannel("nexo_daily","Nexo Daily",NotificationManager.IMPORTANCE_DEFAULT); getSystemService(NotificationManager::class.java).createNotificationChannel(c) } }
    private fun askNotifications(){ if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),10) }
    private fun scheduleAll(){ schedule(8,0,1001,"Hora de publicar","Meta: 10 publicaciones hoy."); schedule(14,0,1002,"Responder prospectos","Revisa clientes interesados."); schedule(20,0,1003,"Seguimiento nocturno","Contacta a quienes preguntaron.") }
    private fun schedule(h:Int,m:Int,id:Int,title:String,body:String){ val alarm=getSystemService(ALARM_SERVICE) as AlarmManager; val intent=Intent(this,ReminderReceiver::class.java).putExtra("title",title).putExtra("body",body).putExtra("id",id); val pi=PendingIntent.getBroadcast(this,id,intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE); val cal=Calendar.getInstance(); cal.set(Calendar.HOUR_OF_DAY,h); cal.set(Calendar.MINUTE,m); cal.set(Calendar.SECOND,0); if(cal.before(Calendar.getInstance())) cal.add(Calendar.DATE,1); alarm.setRepeating(AlarmManager.RTC_WAKEUP,cal.timeInMillis,AlarmManager.INTERVAL_DAY,pi) }
}
