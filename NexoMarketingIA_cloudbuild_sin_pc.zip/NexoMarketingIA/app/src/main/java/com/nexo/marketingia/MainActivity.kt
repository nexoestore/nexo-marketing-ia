package com.nexo.marketingia

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
    private lateinit var content: LinearLayout
    private val prefs by lazy { getSharedPreferences("nexo_v5", MODE_PRIVATE) }
    private val bg=Color.rgb(4,7,8); private val panel=Color.rgb(16,26,29)
    private val teal=Color.rgb(22,242,226); private val white=Color.rgb(244,255,255)
    private val muted=Color.rgb(150,167,170); private val dark=Color.rgb(23,38,41)

    override fun onCreate(b: Bundle?) { super.onCreate(b); NotificationHelper.createChannel(this); askNotif(); seed(); home() }

    private fun shell(title:String){
        val root=LinearLayout(this); root.orientation=LinearLayout.VERTICAL; root.setBackgroundColor(bg); root.setPadding(18,22,18,18)
        val scroll=ScrollView(this); content=LinearLayout(this); content.orientation=LinearLayout.VERTICAL; scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        text("Nexo Marketing IA V5",25f,teal,true); text("Modo publicador diario para WhatsApp",13f,muted,false)
        text(title,22f,white,true)
        nav(listOf("Hoy" to {home()},"Publicador" to {publisher()},"Grupos" to {groups()},"Copys" to {copies()}))
        nav(listOf("Clientes" to {crm()},"IA" to {ai()},"Metas" to {goals()}))
        setContentView(root)
    }
    private fun nav(items:List<Pair<String,()->Unit>>){ val r=LinearLayout(this); r.orientation=LinearLayout.HORIZONTAL; items.forEach{(l,a)->r.addView(btn(l,false,a),LinearLayout.LayoutParams(0,-2,1f))}; content.addView(r) }
    private fun text(s:String,size:Float,color:Int,bold:Boolean){ val v=TextView(this); v.text=s; v.textSize=size; v.setTextColor(color); if(bold)v.setTypeface(null,1); v.setPadding(0,4,0,8); content.addView(v) }

    private fun home(){ shell("Misión diaria"); val total=list("groups").size; val done=todayPublished().size
        card("Tu misión de hoy"){ addView(line("Meta: publicar en ${maxOf(10,total)} lugares",true)); addView(line("Completado: $done/$total grupos",true)); addView(line("Racha: ${prefs.getInt("streak",0)} días",true)); addView(btn("Empezar siguiente publicación",true){nextPublishStep()}); addView(btn("Copiar campaña del día",false){copy(copyOfDay())}) }
        card("Recordatorios inteligentes"){ addView(btn("Probar notificación ahora",true){NotificationHelper.notifyNow(this@MainActivity,7001,"Prueba Nexo","Si ves esto, las notificaciones funcionan.")}); addView(btn("Activar recordatorios persistentes",false){ReminderScheduler.schedulePersistent(this@MainActivity); prefs.edit().putBoolean("reminders_active",true).apply(); NotificationHelper.notifyNow(this@MainActivity,7002,"Recordatorios activos","Te avisaré cada 30 minutos para publicar.")})}
        card("Flujo"){ addView(line("1. La app te muestra el siguiente grupo pendiente.",false)); addView(line("2. Copia el texto correcto.",false)); addView(line("3. Abre WhatsApp.",false)); addView(line("4. Tú publicas y marcas como publicado.",false)) }
    }
    private fun publisher(){ shell("Publicador diario"); val groups=list("groups"); val published=todayPublished(); val pending=groups.filter{!published.contains(groupName(it))}
        card("Progreso"){ addView(line("Publicados: ${published.size}/${groups.size}",true)); addView(line("Pendientes: ${pending.size}",true)); addView(btn("Siguiente grupo pendiente",true){nextPublishStep()}); addView(btn("Reiniciar publicados de hoy",false){prefs.edit().putString("published_${today()}","").apply(); publisher()})}
        if(pending.isEmpty()) card("Día completado"){ addView(line("Terminaste todos los grupos de hoy.",true)); addView(btn("Sumar racha diaria",true){ val k="streak_day"; if(prefs.getString(k,"")!=today()) prefs.edit().putInt("streak",prefs.getInt("streak",0)+1).putString(k,today()).apply(); home()})}
        else pending.forEach{ raw-> val name=groupName(raw); val link=groupLink(raw); card(name){ addView(line("Estado: pendiente",true)); addView(btn("Copiar texto",true){copy(copyOfDay())}); addView(btn("Abrir WhatsApp",false){openWhatsAppOrLink(link)}); addView(btn("Preparar con accesibilidad",false){NexoAccessibilityService.targetGroup=name; NexoAccessibilityService.targetText=copyOfDay(); copy(copyOfDay()); openWhatsAppOrLink(link); toast("Texto copiado. Busca: $name")}); addView(btn("Marcar publicado",false){markPublished(name); publisher()})}}
    }
    private fun nextPublishStep(){ val next=list("groups").firstOrNull{!todayPublished().contains(groupName(it))}; if(next==null){toast("Ya completaste todos los grupos"); publisher(); return}; val name=groupName(next); copy(copyOfDay()); NexoAccessibilityService.targetGroup=name; NexoAccessibilityService.targetText=copyOfDay(); openWhatsAppOrLink(groupLink(next)); toast("Texto copiado. Publica en: $name") }
    private fun groups(){ shell("Grupos de WhatsApp"); card("Agregar grupo"){ val name=input("Nombre exacto del grupo"); val link=input("Link opcional"); addView(name); addView(link); addView(btn("Guardar grupo",true){ if(name.text.isBlank()) return@btn toast("Agrega nombre"); save("groups","${clean(name.text)}|${clean(link.text)}"); groups()})}
        card("Accesibilidad experimental"){ addView(line("Activa el servicio de accesibilidad de Nexo Marketing IA.",false)); addView(btn("Abrir ajustes de accesibilidad",true){startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))})}
        list("groups").forEachIndexed{i,raw-> val name=groupName(raw); val link=groupLink(raw); card(name){ addView(line(if(link.isBlank())"Sin link guardado" else link,false)); addView(btn("Abrir",false){openWhatsAppOrLink(link)}); addView(btn("Eliminar",false){val l=list("groups"); l.removeAt(i); prefs.edit().putString("groups",l.joinToString("\n")).apply(); groups()})}}
    }
    private fun copies(){ shell("Copys"); card("Agregar copy"){ val title=input("Título"); val body=input("Texto"); addView(title); addView(body); addView(btn("Guardar copy",true){ if(body.text.isBlank()) return@btn toast("Agrega texto"); save("copies","${clean(title.text)}|${body.text.toString().replace("|"," ")}"); copies()})}
        list("copies").forEach{ raw-> val p=raw.split("|"); val title=p.getOrElse(0){"Copy"}; val body=p.getOrElse(1){""}; card(title){ addView(line(body,false)); addView(btn("Copiar",true){copy(body)}); addView(btn("Usar como copy del día",false){prefs.edit().putString("copy_day",body).apply(); toast("Copy del día actualizado")})}}
    }
    private fun crm(){ shell("Clientes / CRM"); card("Agregar prospecto"){ val name=input("Nombre"); val phone=input("WhatsApp"); val prod=input("Producto"); addView(name); addView(phone); addView(prod); addView(btn("Guardar prospecto",true){ if(name.text.isBlank()) return@btn toast("Agrega nombre"); save("prospects","${clean(name.text)}|${clean(phone.text)}|${clean(prod.text)}|Nuevo|${today()}"); crm()})}
        list("prospects").forEachIndexed{i,raw-> val p=raw.split("|"); val name=p.getOrElse(0){"Cliente"}; val phone=p.getOrElse(1){""}; val prod=p.getOrElse(2){""}; val status=p.getOrElse(3){"Nuevo"}; card(name){ addView(line("Producto: $prod",false)); addView(line("Estado: $status",true)); addView(btn("Abrir WhatsApp",false){ if(phone.isBlank()) toast("Sin número") else open("https://wa.me/${phone.replace(Regex("\\D"),"")}")}); addView(btn("Copiar seguimiento",true){copy("Hola $name 😊 ¿aún deseas información sobre $prod? Puedes comprar con entrega automática desde www.nexoestore.com")}); addView(btn("Marcar compró",false){updateProspect(i,raw,"Compró"); crm()}); addView(btn("Marcar perdido",false){updateProspect(i,raw,"Perdido"); crm()})}}
    }
    private fun ai(){ shell("IA Comercial rápida"); card("Generar respuesta"){ val q=input("Qué preguntó el cliente"); addView(q); addView(btn("Generar y copiar",true){copy(smartReply(q.text.toString()))})}; card("Respuestas rápidas"){ addView(btn("Catálogo",true){copy(catalogText())}); addView(btn("Cómo comprar",true){copy(howToBuyText())}); addView(btn("Cerrar venta",true){copy(closeSaleText())})}}
    private fun goals(){ shell("Metas"); card("Metas"){ addView(line("Publicaciones hoy: ${todayPublished().size}/${list("groups").size}",true)); addView(line("Racha diaria: ${prefs.getInt("streak",0)}",true))}; card("Notificaciones"){ addView(btn("Notificación de prueba",true){NotificationHelper.notifyNow(this@MainActivity,7777,"Prueba","Notificaciones funcionando.")}); addView(btn("Recordatorio en 1 minuto",false){ReminderScheduler.scheduleInMinutes(this@MainActivity,1,9001,"Publicación pendiente","Abre la app y publica en el siguiente grupo."); toast("Programado en 1 minuto")}); addView(btn("Recordatorio persistente cada 30 min",false){ReminderScheduler.schedulePersistent(this@MainActivity); toast("Recordatorio persistente activado")})}}
    private fun smartReply(raw:String):String{ val q=raw.lowercase(); return when{ listOf("catalogo","catálogo","productos","stock","disponible","lista").any{q.contains(it)} -> catalogText(); listOf("precio","precios","cuanto","cuánto","costo","valor").any{q.contains(it)} -> "💰 Precios proveedor\n\nAmazon Prime: US$2.00\nMax Platino: US$4.50\nDisney Premium: US$8.00\n\n🌐 www.nexoestore.com"; listOf("comprar","compro","recarga","saldo","pago").any{q.contains(it)} -> howToBuyText(); else -> "¡Hola! 😊 Tenemos servicios streaming disponibles.\n\nConsulta catálogo y disponibilidad en www.nexoestore.com\n\n✅ Registro gratis\n✅ Recarga saldo\n✅ Entrega automática\n✅ Soporte WhatsApp"}}
    private fun catalogText()="📺 Catálogo disponible\n\n✅ Amazon Prime Video — US$2.00\n✅ Max Platino 4K — US$4.50\n✅ Disney Premium — US$8.00\n\n🌐 Compra automática:\nwww.nexoestore.com"
    private fun howToBuyText()="🛒 Cómo comprar\n\n1️⃣ Ingresa a www.nexoestore.com\n2️⃣ Regístrate gratis\n3️⃣ Recarga saldo\n4️⃣ Envíame el ID o comprobante\n5️⃣ Valido tu saldo\n6️⃣ Compra con entrega automática"
    private fun closeSaleText()="Perfecto 😊\n\nRegístrate gratis en:\nwww.nexoestore.com\n\nRecarga saldo y envíame el ID o comprobante para validar. Luego compras con entrega automática."
    private fun copyOfDay()=prefs.getString("copy_day","🔥 Streaming para revendedores\n\n✅ Amazon Prime\n✅ Max Platino 4K\n✅ Disney Premium\n\n⚡ Entrega automática\n⚡ Registro gratis\n⚡ Compra directa desde la web\n\n🌐 www.nexoestore.com")?:""
    private fun groupName(raw:String)=raw.split("|").getOrElse(0){"Grupo"}; private fun groupLink(raw:String)=raw.split("|").getOrElse(1){""}
    private fun todayKey()="published_${today()}"; private fun todayPublished()=list(todayKey()).toSet()
    private fun markPublished(name:String){ val l=list(todayKey()); if(!l.contains(name)) l.add(name); prefs.edit().putString(todayKey(),l.joinToString("\n")).apply() }
    private fun seed(){ if(prefs.getBoolean("seeded",false)) return; prefs.edit().putString("groups","PUBLICIDAD STREAMING LATAM|\nPROVEEDORES STREAMING|\nSTREAMING REVENDEDORES|").putString("copies","Copy proveedor|🔥 Stock disponible para revendedores\\n\\n✅ Amazon Prime\\n✅ Max Platino\\n✅ Disney Premium\\n\\n🌐 www.nexoestore.com").putBoolean("seeded",true).apply() }
    private fun openWhatsAppOrLink(link:String){ if(link.startsWith("http")) open(link) else { val i=packageManager.getLaunchIntentForPackage("com.whatsapp"); if(i!=null) startActivity(i) else open("https://wa.me/") } }
    private fun card(title:String, build:LinearLayout.()->Unit){ val box=LinearLayout(this); box.orientation=LinearLayout.VERTICAL; box.setBackgroundColor(panel); box.setPadding(18,18,18,18); val tv=TextView(this); tv.text=title; tv.textSize=18f; tv.setTextColor(white); tv.setTypeface(null,1); box.addView(tv); box.build(); val lp=LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,0,0,16); content.addView(box,lp) }
    private fun line(s:String,strong:Boolean):TextView{ val v=TextView(this); v.text=s; v.textSize=15f; v.setTextColor(if(strong)teal else white); if(strong)v.setTypeface(null,1); v.setPadding(0,6,0,6); return v }
    private fun input(h:String):EditText{ val e=EditText(this); e.hint=h; e.setHintTextColor(muted); e.setTextColor(white); e.setBackgroundColor(Color.rgb(6,17,19)); e.setPadding(14,12,14,12); return e }
    private fun btn(label:String,primary:Boolean,action:()->Unit):Button{ val b=Button(this); b.text=label; b.textSize=13f; b.setTextColor(if(primary) Color.BLACK else white); b.setBackgroundColor(if(primary)teal else dark); b.setOnClickListener{action()}; return b }
    private fun clean(x:CharSequence)=x.toString().replace("|"," ").replace("\n"," ").trim()
    private fun list(k:String)=prefs.getString(k,"")!!.split("\n").filter{it.isNotBlank()}.toMutableList()
    private fun save(k:String,item:String){ val l=list(k); l.add(0,item); prefs.edit().putString(k,l.joinToString("\n")).apply() }
    private fun updateProspect(i:Int,raw:String,status:String){ val l=list("prospects"); val p=raw.split("|").toMutableList(); while(p.size<5)p.add(""); p[3]=status; l[i]=p.joinToString("|"); prefs.edit().putString("prospects",l.joinToString("\n")).apply() }
    private fun today()=SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
    private fun copy(s:String){ (getSystemService(CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Nexo",s)); toast("Copiado") }
    private fun open(url:String){ try{ startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) }catch(e:Exception){ toast("No se pudo abrir") } }
    private fun askNotif(){ if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS),10) }
}
