package com.nexo.marketingpro
import android.app.*
import android.content.*
object ReminderScheduler {
    fun schedulePersistent(context: Context) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = pending(context, 3001, "Publicación pendiente", "Abre Nexo Marketing Pro y publica en el siguiente grupo.")
        alarm.setRepeating(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + 1800000L, 1800000L, pi)
    }
    fun scheduleInMinutes(context: Context, minutes: Int, id: Int, title: String, body: String) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.set(AlarmManager.RTC_WAKEUP, System.currentTimeMillis() + minutes * 60000L, pending(context, id, title, body))
    }
    private fun pending(context: Context, id: Int, title: String, body: String): PendingIntent {
        val intent = Intent(context, ReminderReceiver::class.java)
        intent.putExtra("title", title); intent.putExtra("body", body); intent.putExtra("id", id)
        return PendingIntent.getBroadcast(context, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
}
