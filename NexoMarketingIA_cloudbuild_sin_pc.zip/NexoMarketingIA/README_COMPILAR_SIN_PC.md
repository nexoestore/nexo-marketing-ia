# Compilar APK sin PC

1. Sube todos los archivos del ZIP descomprimidos al repositorio.
2. En GitHub entra a Actions.
3. Ejecuta Construir APK Android.
4. Espera que termine en verde.
5. Abre el run y descarga el artifact APK.
