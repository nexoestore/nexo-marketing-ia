# Nexo Marketing IA V5

Versión enfocada en constancia real publicando en grupos de WhatsApp.

Incluye:
- Modo publicador diario
- Checklist de grupos pendientes
- Copiar texto del día
- Abrir WhatsApp
- Marcar publicado
- Racha diaria
- Recordatorios persistentes cada 30 minutos
- Notificación de prueba
- CRM simple
- IA comercial rápida
- Servicio de accesibilidad experimental

La app NO envía mensajes automáticamente. Te guía, copia el texto, abre WhatsApp y registra progreso. El envío final lo haces tú.
