# Nexo Manager v1.8 - Generación 26

Inventario profesional:
- Recupera eliminar producto.
- Confirmación antes de eliminar.
- Editar producto completo.
- Ajustar stock con +1 y -1.
- Mantiene buscador por código y compartir por WhatsApp.

Usuario inicial:
- admin / 1234
- trabajador / 1234

## Actualización de identidad

- Nombre actualizado a **Nexo Manager**.
- Ícono personalizado agregado en todos los tamaños Android.
- `android:label`, `android:icon` y `android:roundIcon` actualizados.

## Generación 27 / Nexo Manager 1.9

Galería y WhatsApp Pro:

- Cada producto ahora puede guardar varias fotos.
- Botón **Agregar foto** en creación y edición.
- Botón **Limpiar fotos**.
- Muestra cantidad de fotos guardadas.
- WhatsApp comparte el texto y, cuando hay imagen guardada, intenta adjuntar la primera imagen.
- Si WhatsApp no acepta la imagen, usa compartir texto como respaldo.

## Generación 28 / Nexo Manager 2.0

Actualización visual de productos:

- Ahora las fotos guardadas se muestran en la tarjeta de inventario.
- También se muestran en la pantalla de ventas.
- Si hay varias fotos, se muestra la primera como foto principal.
- Se indica cuántas fotos tiene el producto.
- Al tocar la imagen se abre una vista ampliada.
- Se mantiene compartir por WhatsApp con imagen + texto.

## Nexo Manager 2.1 - Marketing Pro

- Mensaje de WhatsApp más comercial.
- Se elimina código interno y código de barras del mensaje al cliente.
- Mantiene imagen principal al compartir.
- Botón Compartir oferta.
- Botón Copiar texto.

## Nexo Manager 2.2 - Imágenes seguras y respaldo

Actualización crítica:

- Al seleccionar fotos, la app copia cada imagen a una carpeta propia y estable.
- Ya no depende de permisos temporales de Android.
- Las fotos se mantienen después de cerrar o reiniciar la app.
- WhatsApp comparte la copia estable de la foto.
- Nuevo botón en Configuración: crear respaldo local.
- El respaldo exporta productos, ventas, usuarios y rutas de fotos en formato texto.

## Nexo Manager 2.3 - Restaurar copia de seguridad

Actualización de respaldo:

- Nuevo botón **📥 Restaurar respaldo**.
- Abre el administrador de archivos para escoger un archivo `.txt` de respaldo.
- Restaura productos, ventas y usuarios desde el respaldo.
- Mantiene las rutas de fotos guardadas.
- Limpia los datos actuales antes de restaurar para evitar duplicados.

Nota: esta versión restaura el formato `.txt` creado por Nexo Manager 2.2.

## Nexo Manager 2.4 - Respaldos visibles y WhatsApp con foto

Correcciones importantes:

- El respaldo ahora se crea en **Descargas/Nexo Manager** para que puedas encontrarlo.
- Nuevo botón **Compartir último respaldo** para enviarlo por WhatsApp, Drive o archivos.
- WhatsApp ahora comparte la foto usando FileProvider, no una ruta privada.
- Si la imagen falla, la app envía el texto como respaldo.

## Nexo Manager 2.5 - Respaldo inteligente

Actualización crítica sin eliminar funciones existentes:

- Nuevo respaldo inteligente en archivo `.nmb`.
- El respaldo incluye:
  - productos,
  - ventas,
  - usuarios,
  - rutas de fotos,
  - copias reales de las imágenes.
- El archivo se guarda en **Descargas/Nexo Manager**.
- Nuevo botón **Restaurar respaldo inteligente**.
- Al restaurar, recupera datos e imágenes dentro de la carpeta segura de la app.
- Mantiene el respaldo `.txt` anterior por compatibilidad.

## Nexo Manager 2.6 - WhatsApp imagen real

Corrección enfocada únicamente en WhatsApp:

- El mensaje ya no incluye enlace `wa.me` para evitar vista previa del perfil de WhatsApp.
- Se comparte la foto del producto como archivo adjunto real.
- El texto queda como descripción/caption.
- Si la imagen falla, se envía solo el texto y la app avisa.
- No se modifican inventario, ventas, respaldo inteligente ni comisiones.

## Nexo Manager 2.7 - Compartir Profesional

Actualización enfocada solo en el mensaje comercial:

- No muestra código interno.
- No muestra código de barras.
- Mantiene la foto del producto al compartir.
- El enlace de WhatsApp se genera automáticamente con el nombre del producto.
- El mensaje precargado para el cliente queda así:
  `Hola, me interesa Nombre del Producto. ¿Sigue disponible?`
- No se modifican inventario, ventas, comisiones ni respaldo inteligente.

## Nexo Manager 2.8 - Personalización de mensajes

Nueva sección en Configuración sin modificar inventario, ventas, comisiones ni respaldos:

- Nombre de tienda editable.
- Número de WhatsApp editable.
- Texto de envío editable.
- Texto de confianza editable.
- Mostrar/ocultar precio.
- Mostrar/ocultar disponibilidad.
- Incluir/ocultar enlace WhatsApp.
- Activar/desactivar imagen al compartir.
- Vista previa del mensaje.

## Nexo Manager 2.9 - Restaurar controles de inventario

- Recupera +1 y -1 de stock.
- Recupera Editar producto.
- Recupera Eliminar producto con confirmación.
- Mantiene compartir producto, compartir oferta y copiar texto.
- Mantiene personalización de mensajes.
- Mantiene respaldo inteligente.
- Corrige el caso donde `admin` aparecía como WORKER después de restaurar respaldos antiguos.

## Nexo Manager 3.0 - Respaldo inteligente automático

Agregado sin eliminar lo construido:

- Crea respaldo inteligente automático después de cada guardado importante.
- Conserva los últimos 10 respaldos automáticos.
- Carpeta: `Descargas/Nexo Manager/Automaticos`.
- Incluye datos e imágenes reales.
- Antes de restaurar, crea un respaldo automático de seguridad.
- Mantiene inventario, ventas, comisiones, personalización de mensajes y respaldo manual.

## Nexo Manager 3.1 - Persistencia total

Corrección crítica:

- Cerrar sesión ahora guarda antes de salir y no borra datos.
- Se reemplazó guardado asíncrono por guardado confirmado (`commit`).
- La app ya no sobrescribe datos con productos demo si detecta datos guardados.
- Carga de datos más robusta y compatible con formatos anteriores.
- Protege al usuario `admin` para que siempre conserve rol ADMIN.
- Mantiene respaldo automático, respaldo inteligente, mensajes personalizados e inventario.

## Nexo Manager 3.2 - WhatsApp configurable

Actualización agregada sin eliminar funciones existentes:

- Campo claro para poner el número de WhatsApp desde Configuración.
- Acepta número local colombiano como `3052154226`.
- También acepta número internacional como `573052154226`.
- Si escribes 10 dígitos, la app agrega automáticamente `57`.
- Todos los enlaces de productos compartidos usan ese número.
- Mantiene inventario, ventas, comisiones, imágenes, respaldo inteligente, respaldo automático y personalización de mensajes.

## Nexo Manager 3.3 - Recuperar agregar producto

Corrección mínima sin tocar lo que ya funciona:

- Recupera el botón **Agregar producto** en Inventario.
- Recupera el formulario para crear productos nuevos.
- Mantiene editar, eliminar, +1/-1, fotos, compartir, WhatsApp configurable, respaldo inteligente y persistencia.

## Nexo Moda 3.5 — Controles de inventario recuperados

Corrección mínima, sin reemplazar pantallas ni eliminar funciones:

- Conserva Compartir producto, Compartir oferta y Copiar texto.
- Vuelve a mostrar al propietario los controles +1, -1, Editar y Eliminar producto.
- Recupera también Agregar producto para el propietario.
- Corrige respaldos antiguos donde David Benavides podía quedar guardado como WORKER.
- Mantiene fotos, ventas, WhatsApp configurable, persistencia y respaldos.

## Nexo Moda 3.6 — Código público y catálogo HTML

Se añadieron funciones sin eliminar las anteriores:

- Cada producto recibe un Código público único y permanente: `WEB-000001`, `WEB-000002`, etc.
- Los productos existentes reciben el código automáticamente una sola vez.
- El código se conserva al cerrar sesión, respaldar y restaurar.
- La imagen web esperada se construye así:
  `https://nexoestore.com/pijamas/web-000001.jpg`
- Nuevo botón **Crear catálogo HTML** en Inventario.
- El botón guarda `catalogo_nexo_moda.html` en Descargas/Nexo Manager y copia todo el HTML al portapapeles.
- El catálogo incluye solo productos con stock mayor que cero.
- Mantiene Agregar, +1, -1, Editar, Eliminar, fotos, ventas, WhatsApp y respaldos.

## Nexo Moda 3.7 — Catálogo Systeme.io corregido

- Genera fragmento compatible con Systeme.io: sin DOCTYPE, html, head ni body.
- 4 productos por fila en computador.
- 2 productos por fila en celular.
- Se eliminó el salto automático a 3 columnas.
- Al tocar una foto se abre ampliada en pantalla completa.
- Se quitaron emojis y tildes problemáticas de los textos fijos para evitar caracteres dañados.
- Conserva todos los productos, precios, disponibilidad y enlaces individuales de WhatsApp.
- No elimina funciones anteriores de inventario, ventas, respaldo ni publicación.

## Nexo Moda 3.8 — Corrección Crear catálogo HTML

- Corrige el error al crear el catálogo en Android moderno.
- Ya no intenta escribir directamente en Descargas sin permiso.
- Guarda una copia segura dentro del almacenamiento privado de la aplicación.
- Copia automáticamente todo el HTML al portapapeles.
- Muestra el detalle real del error si algo vuelve a fallar.
- Conserva 4 columnas en computador, 2 en celular y ampliación de imágenes.
- No elimina ninguna función anterior.
