# Nexo Marketing IA V2 Personal

App Android personal para publicar, responder, registrar prospectos, hacer seguimiento y recibir recordatorios.

Incluye:
- Panel de hoy
- Publicaciones por producto
- Copiar textos
- Compartir por WhatsApp
- CRM de prospectos
- IA comercial rápida
- Respuestas rápidas
- Metas diarias
- Notificaciones locales: 8 AM, 2 PM y 8 PM
- Datos guardados en el teléfono
