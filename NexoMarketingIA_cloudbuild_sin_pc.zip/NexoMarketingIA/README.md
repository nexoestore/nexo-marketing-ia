# Nexo Marketing Pro

**Convierte publicaciones en clientes.**

Nexo Marketing Pro es una aplicación Android para organizar prospección manual, publicaciones, copys, prospectos, seguimientos, clientes y dashboard comercial para Nexo E Store.

## Qué incluye esta versión

- Inicio comercial con objetivos diarios.
- Buscar clientes con checklist diario.
- Biblioteca de copys editable sin IA.
- Compartir textos a WhatsApp y Telegram.
- Prospectos con estados comerciales.
- Seguimientos diarios.
- Clientes y ventas estimadas.
- Dashboard de embudo comercial.
- Icono nuevo de Nexo Marketing Pro.
- Package Android actualizado a `com.nexo.marketingpro`.

## Filosofía de uso

La app **no envía spam automático**. Te ayuda a organizar el trabajo manual:

1. Crear o elegir un copy.
2. Publicar en grupos relevantes.
3. Guardar prospectos interesados.
4. Hacer seguimiento.
5. Convertir prospectos en clientes.

## Compilar sin PC con GitHub Actions

1. Sube este ZIP al repositorio con el nombre exacto:

```text
NexoMarketingIA_cloudbuild_sin_pc.zip
```

2. Ve a:

```text
Actions → Construir APK desde ZIP → Run workflow
```

3. Descarga el artifact generado.

## Datos locales

La versión actual conserva datos en almacenamiento local simple para mantener compatibilidad con las versiones anteriores. Es suficiente para un MVP y pruebas reales. Para una versión grande con miles de registros, el siguiente paso recomendado es migrar el almacenamiento a Room/SQLite.

## Nombre visible

La app ya usa:

```text
Nexo Marketing Pro
```

## Package

```text
com.nexo.marketingpro
```

## Próximas mejoras recomendadas

- Migrar datos a Room/SQLite.
- Exportar/importar backup.
- Filtros avanzados en prospectos.
- Estadísticas por grupo y por copy.
- Icono adaptativo por densidades.
