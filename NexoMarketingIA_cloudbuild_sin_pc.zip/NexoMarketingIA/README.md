# Nexo ERP v1.1 - Generación 19

Se agregó registro y administración local de usuarios sin perder las 18 generaciones.

## Usuarios iniciales
- admin / 1234
- trabajador / 1234

## Nuevo
- Botón Crear usuario nuevo en login.
- Crear administradores o trabajadores.
- Panel Usuarios para administrador.
- Activar/desactivar trabajadores.
- Trabajador no ve costos ni ganancias.
- Usuarios guardados localmente.

Sube este ZIP con nombre exacto: NexoMarketingIA_cloudbuild_sin_pc.zip
