# Nexo ERP v1.5 - Generación 23

Actualización enfocada en vendedores, comisiones y trazabilidad de ventas.

## Nuevo

- Cada venta guarda:
  - número de venta,
  - producto,
  - precio de venta,
  - costo real,
  - comisión,
  - ganancia empresa,
  - usuario vendedor,
  - fecha,
  - estado de comisión.

- Nuevo módulo **Comisiones**.
- Comisión pendiente por trabajador.
- Botón **Pagar comisión**.
- Historial de pagos de comisiones.
- Ventas asociadas al usuario que inició sesión.
- El historial de ventas muestra datos claros para administración.

## Usuario inicial

- admin / 1234
- trabajador / 1234

## Importante

Sube el ZIP con nombre exacto:

NexoMarketingIA_cloudbuild_sin_pc.zip
