# Nexo ERP v1.7 - Generación 25

Nueva versión creada para mantener la idea del ERP y agregar las dos actualizaciones pedidas.

## Nuevo

- Buscador por nombre, categoría, código interno y código de barras.
- Campo **Código interno** separado del código de barras.
- Botón **Compartir por WhatsApp** en cada producto.
- Mensaje automático con nombre, precio, disponibilidad y enlace de WhatsApp.
- Si el producto tiene referencia de imagen, el sistema prepara el texto indicando que el producto tiene imagen.
- Se elimina la idea de cámara para buscar código: ahora es búsqueda por texto.
- Mantiene inventario, ventas, compras, proveedores, usuarios y comisiones de forma local.

## Usuario inicial

- admin / 1234
- trabajador / 1234

## GitHub Actions

Sube este ZIP con el nombre exacto:

`NexoMarketingIA_cloudbuild_sin_pc.zip`
