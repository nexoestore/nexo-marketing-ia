# Nexo Marketing IA Personal

App Android personal para publicar con constancia, copiar promociones, gestionar grupos y hacer seguimiento de clientes.

## Funciones
- Dashboard de tareas de hoy
- Catálogo con promociones copiables
- Biblioteca de copys editable
- Gestor de grupos con abrir enlace
- CRM personal de clientes
- Respuestas rápidas
- Datos guardados en el celular con SharedPreferences

## Compilar sin PC
Sube este proyecto completo a GitHub y ve a Actions > Construir APK Android > Run workflow.

El APK se descarga desde Artifacts al terminar.
