# Nexo Manager v1.8 - Generación 26

Inventario profesional:
- Recupera eliminar producto.
- Confirmación antes de eliminar.
- Editar producto completo.
- Ajustar stock con +1 y -1.
- Mantiene buscador por código y compartir por WhatsApp.

Usuario inicial:
- admin / 1234
- trabajador / 1234

## Actualización de identidad

- Nombre actualizado a **Nexo Manager**.
- Ícono personalizado agregado en todos los tamaños Android.
- `android:label`, `android:icon` y `android:roundIcon` actualizados.

## Generación 27 / Nexo Manager 1.9

Galería y WhatsApp Pro:

- Cada producto ahora puede guardar varias fotos.
- Botón **Agregar foto** en creación y edición.
- Botón **Limpiar fotos**.
- Muestra cantidad de fotos guardadas.
- WhatsApp comparte el texto y, cuando hay imagen guardada, intenta adjuntar la primera imagen.
- Si WhatsApp no acepta la imagen, usa compartir texto como respaldo.

## Generación 28 / Nexo Manager 2.0

Actualización visual de productos:

- Ahora las fotos guardadas se muestran en la tarjeta de inventario.
- También se muestran en la pantalla de ventas.
- Si hay varias fotos, se muestra la primera como foto principal.
- Se indica cuántas fotos tiene el producto.
- Al tocar la imagen se abre una vista ampliada.
- Se mantiene compartir por WhatsApp con imagen + texto.

## Nexo Manager 2.1 - Marketing Pro

- Mensaje de WhatsApp más comercial.
- Se elimina código interno y código de barras del mensaje al cliente.
- Mantiene imagen principal al compartir.
- Botón Compartir oferta.
- Botón Copiar texto.
