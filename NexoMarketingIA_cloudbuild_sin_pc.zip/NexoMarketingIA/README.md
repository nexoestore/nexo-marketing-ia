# Nexo ERP v1.6 - Generación 24

Corrección importante sobre código de barras e imagen.

## Nuevo

- El botón de imagen ahora abre el selector real de archivos/galería de Android.
- La app guarda la URI real de la imagen seleccionada.
- El botón de código ya no se presenta como escaneo real si solo genera un código demo.
- Se mantiene el campo manual de código de barras.
- Se conserva Generación 23:
  - ventas por usuario,
  - comisiones,
  - pago de comisiones,
  - compras completas,
  - proveedores,
  - inventario.

## Nota

El escáner real de código de barras con cámara requiere integrar ML Kit o ZXing.
Esta versión deja correcto el selector real de imagen y evita confundir el botón de código.

Usuario inicial:
- admin / 1234
- trabajador / 1234

Sube este ZIP con nombre exacto:
NexoMarketingIA_cloudbuild_sin_pc.zip
