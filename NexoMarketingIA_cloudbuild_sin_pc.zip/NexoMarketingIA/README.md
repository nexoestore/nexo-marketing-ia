# Nexo ERP v1.2 - Generación 20

Esta versión agrega **Compras e Inventario Profesional**.

## Nuevo en Generación 20

- Módulo **Compras**.
- Registrar compra a proveedor.
- Agregar cantidad comprada.
- Registrar costo unitario.
- Registrar envío de la compra.
- El envío se distribuye automáticamente por unidad.
- Al guardar una compra, el stock sube automáticamente.
- Capital comprado / invertido desde compras reales.
- Capital en inventario.
- Capital recuperado.
- Historial de compras.
- Movimientos de inventario.
- Ajuste de stock manual:
  - +1
  - -1
- Eliminar producto.
- El trabajador no ve costos ni ganancias.

## Usuario inicial

Administrador:
- Usuario: `admin`
- Clave: `1234`

Trabajador:
- Usuario: `trabajador`
- Clave: `1234`

## Importante para GitHub Actions

Sube el ZIP con este nombre exacto:

`NexoMarketingIA_cloudbuild_sin_pc.zip`
