# Nexo ERP v1.0 - Compatible con GitHub Actions

Este ZIP conserva el avance de las 18 generaciones y está adaptado al flujo que ya tienes en GitHub.

## Muy importante

El archivo ZIP debe llamarse exactamente:

`NexoMarketingIA_cloudbuild_sin_pc.zip`

Tu workflow actual intenta descomprimir ese nombre. Si subes el ZIP con otro nombre, fallará antes de compilar.

## Usuarios demo

Administrador:
- Usuario: `admin`
- Clave: `1234`

Trabajador:
- Usuario: `trabajador`
- Clave: `1234`

## Funciones incluidas

- Login local.
- Roles: administrador y trabajador.
- Dashboard.
- Inventario.
- Buscador de productos.
- Agregar productos.
- Ventas.
- Comisión trabajador.
- Reportes.
- Exportar CSV como texto.
- Copia de seguridad textual.
- Nexo IA base.
- Configuración.
- Persistencia local con SharedPreferences.
- GitHub Actions compatible con tu flujo actual.
