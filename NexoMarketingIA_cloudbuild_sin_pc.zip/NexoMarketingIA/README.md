# Nexo Marketing IA V4

Mejoras:
- Notificación inmediata de prueba.
- Recordatorios diarios 8 AM, 2 PM, 8 PM.
- Recordatorio en 1 minuto para prueba.
- Recordatorio cada hora opcional.
- Historial de notificaciones.
- Reactivación de recordatorios al reiniciar.
- IA comercial por intenciones, catálogo editable, CRM y calculadora.
