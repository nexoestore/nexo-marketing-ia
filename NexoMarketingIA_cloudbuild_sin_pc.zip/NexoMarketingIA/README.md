# Nexo Marketing Pro

Proyecto base transformado para la nueva arquitectura comercial.


## Ajuste UX v2
- Menú superior reducido a Inicio, Buscar, Biblioteca y Más.
- Las herramientas secundarias se movieron a Más para no saturar la pantalla.
- Compartir ahora abre el selector de apps de Android en lugar de intentar abrir una app fija.
