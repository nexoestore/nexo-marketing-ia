# Nexo Marketing IA V3

Mejoras:
- IA comercial por intenciones
- Más de 100 palabras clave comerciales agrupadas
- Catálogo editable
- Productos disponibles / agotados
- Campañas por canal
- CRM de prospectos
- Seguimientos
- Calculadora de ganancia
- Recordatorios diarios
- Se eliminó Plan PRO de respuestas rápidas
