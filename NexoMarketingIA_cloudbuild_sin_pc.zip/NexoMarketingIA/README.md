# Nexo Manager v1.8 - Generación 26

Inventario profesional:
- Recupera eliminar producto.
- Confirmación antes de eliminar.
- Editar producto completo.
- Ajustar stock con +1 y -1.
- Mantiene buscador por código y compartir por WhatsApp.

Usuario inicial:
- admin / 1234
- trabajador / 1234

## Actualización de identidad

- Nombre actualizado a **Nexo Manager**.
- Ícono personalizado agregado en todos los tamaños Android.
- `android:label`, `android:icon` y `android:roundIcon` actualizados.
