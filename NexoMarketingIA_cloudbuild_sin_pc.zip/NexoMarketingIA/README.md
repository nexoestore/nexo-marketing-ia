# Nexo ERP v1.3 - Generación 21

Actualización de compras e inventario profesional.

Incluye:
- Compra con varios productos antes de guardar.
- Distribución automática del envío.
- Stock automático por compra.
- Código de barras por producto.
- Campo de foto/referencia de imagen.
- Búsqueda rápida por nombre/categoría/código.
- Proveedores con historial.
- Total invertido por proveedor.
- Editar cantidad de compra (+1 / -1).
- Eliminar productos de una compra.
- Alertas de agotados y última unidad.

Usuario inicial:
- admin / 1234
- trabajador / 1234

Sube el ZIP con nombre exacto:
NexoMarketingIA_cloudbuild_sin_pc.zip
