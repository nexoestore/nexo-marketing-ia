# Generación 21

Esta versión mejora el flujo real de compras:
1. Crear compra por proveedor.
2. Agregar varios productos.
3. Guardar todo junto.
4. Subir stock automáticamente.
5. Consultar historial por proveedor.
6. Editar cantidades o eliminar líneas de compra.

El botón de escaneo es una base demo. En la siguiente evolución puede conectarse a cámara con ML Kit o ZXing.
