# Generación 20 - Compras e Inventario Profesional

Objetivo: permitir administrar compras al proveedor y stock real.

## Flujo

1. Ir a Compras.
2. Registrar proveedor, producto, cantidad, costo unitario, envío y precio de venta.
3. Guardar compra.
4. El sistema:
   - Sube stock.
   - Calcula costo real por unidad.
   - Registra capital comprado.
   - Crea movimiento de inventario.
   - Actualiza dashboard.

## Limitación actual

La compra registra un producto por vez para mantener la app ligera.
La siguiente evolución puede permitir múltiples productos en una misma factura.
