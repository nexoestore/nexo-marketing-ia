# Historial preservado - Generaciones 1 a 18

Este proyecto consolida el trabajo realizado en las 18 generaciones:

1. Base inicial del proyecto.
2. Arquitectura MVVM e inventario base.
3. Inventario ampliado.
4. Compras base.
5. Ventas base.
6. Dashboard financiero.
7. Clientes CRM base.
8. Trabajadores y comisiones.
9. Finanzas y reportes.
10. Nexo IA base.
11. Navegación y estructura visual.
12. Proyecto Android real con Compose.
13. Persistencia local simple.
14. Login y roles.
15. Marketing IA base.
16. Reportes y exportación.
17. Validaciones, búsqueda y mejoras.
18. Consolidación v1.0.

Esta versión está adaptada para compilar con el workflow:
`Construir APK desde ZIP`.
