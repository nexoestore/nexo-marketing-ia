# Generación 25

Objetivo:
- Buscar productos por código escrito.
- Compartir productos a WhatsApp.

El buscador no abre cámara. Busca por texto entre:
- Nombre
- Categoría
- Código interno
- Código de barras

El botón WhatsApp genera un mensaje listo para vender.
