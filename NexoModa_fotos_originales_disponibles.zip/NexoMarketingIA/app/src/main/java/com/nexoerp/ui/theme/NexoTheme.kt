package com.nexoerp.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Colors = lightColorScheme(
    primary = Color(0xFF0F172A),
    secondary = Color(0xFF2563EB),
    tertiary = Color(0xFFEC4899),
    background = Color(0xFFF8FAFC),
    surface = Color.White,
    error = Color(0xFFDC2626)
)

@Composable
fun NexoTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = Colors, content = content)
}
