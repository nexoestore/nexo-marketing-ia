package com.nexoerp.data

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.content.pm.PackageManager
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.net.URLEncoder
import java.io.FileInputStream
import java.util.zip.ZipOutputStream
import java.util.zip.ZipFile
import java.util.zip.ZipEntry
import androidx.core.content.FileProvider
import android.os.Environment
import java.io.FileOutputStream
import java.io.InputStream
import java.io.File

data class ShareSettings(
    val storeName: String = "Nexo Moda",
    val whatsappNumber: String = "573052154226",
    val shippingText: String = "Envíos a todo Colombia.",
    val trustText: String = "Compra con confianza. Atención personalizada y garantía en cada pedido.",
    val showPrice: Boolean = true,
    val showAvailability: Boolean = true,
    val includeWhatsappLink: Boolean = true,
    val shareImage: Boolean = true
)

class NexoStore(private val context: Context) {
    private val prefs = context.getSharedPreferences("nexo_manager_gen27", Context.MODE_PRIVATE)

    val products = mutableStateListOf<Product>()
    val sales = mutableStateListOf<Sale>()
    val users = mutableStateListOf<AppUser>()

    val selectedTab = mutableStateOf(AppTab.DASHBOARD)
    val currentUser = mutableStateOf<AppUser?>(null)
    val loginError = mutableStateOf("")
    val appMessage = mutableStateOf("")
    val shareSettings = mutableStateOf(loadShareSettings())
    private var autoBackupEnabled = true

    init {
        autoBackupEnabled = false

        val hadSavedProducts = prefs.contains("products")
        val hadSavedUsers = prefs.contains("users")
        loadAll()

        var needsInitialSave = false

        if (users.isEmpty() && !hadSavedUsers) {
            users.add(AppUser("admin", "Administrador", "1234", UserRole.ADMIN, true))
            users.add(AppUser("trabajador", "Trabajador", "1234", UserRole.WORKER, true))
            needsInitialSave = true
        }

        if (products.isEmpty() && !hadSavedProducts) {
            products.add(Product(1, "Pijama Stitch Azul", "Pijamas", "P118", "770000000118", 30694.0, 42000.0, 16, ""))
            products.add(Product(2, "Pijama Daisy Rosada", "Pijamas", "P119", "770000000119", 34694.0, 45000.0, 1, ""))
            products.add(Product(3, "Pijama Garfield", "Pijamas", "P120", "770000000120", 31694.0, 40000.0, 0, ""))
            needsInitialSave = true
        }

        if (users.none { it.username.equals("admin", ignoreCase = true) }) {
            users.add(0, AppUser("admin", "Administrador", "1234", UserRole.ADMIN, true))
            needsInitialSave = true
        }

        autoBackupEnabled = true

        if (needsInitialSave) {
            saveAll()
        }
    }

    private fun now(): String = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())

    fun login(username: String, password: String): Boolean {
        val user = users.firstOrNull {
            it.username.equals(username.trim(), ignoreCase = true) && it.password == password && it.active
        }

        return if (user != null) {
            currentUser.value = if (user.username.equals("admin", ignoreCase = true)) user.copy(role = UserRole.ADMIN, displayName = "Administrador") else user
            loginError.value = ""
            appMessage.value = "Bienvenido ${user.displayName}"
            true
        } else {
            loginError.value = "Usuario, clave incorrectos o usuario inactivo"
            false
        }
    }

    fun logout() {
        saveAll()
        currentUser.value = null
        selectedTab.value = AppTab.DASHBOARD
    }

    fun isAdmin(): Boolean = currentUser.value?.role == UserRole.ADMIN
    fun isWorker(): Boolean = currentUser.value?.role == UserRole.WORKER

    fun registerUser(username: String, name: String, pass: String, confirm: String, role: UserRole): Boolean {
        val clean = username.trim().lowercase()
        if (clean.length < 3) { appMessage.value = "Usuario mínimo 3 caracteres"; return false }
        if (name.trim().length < 3) { appMessage.value = "Nombre mínimo 3 caracteres"; return false }
        if (pass.length < 4) { appMessage.value = "Clave mínimo 4 caracteres"; return false }
        if (pass != confirm) { appMessage.value = "Las claves no coinciden"; return false }
        if (users.any { it.username == clean }) { appMessage.value = "Ese usuario ya existe"; return false }

        users.add(AppUser(clean, name.trim(), pass, role, true))
        saveAll()
        appMessage.value = "Usuario creado"
        return true
    }

    fun toggleUser(username: String) {
        if (!isAdmin()) return
        val i = users.indexOfFirst { it.username == username }
        if (i >= 0 && users[i].username != "admin") {
            users[i] = users[i].copy(active = !users[i].active)
            saveAll()
        }
    }

    fun addProduct(
        name: String,
        category: String,
        internalCode: String,
        barcode: String,
        cost: Double,
        price: Double,
        stock: Int,
        photo: String
    ): Boolean {
        if (!isAdmin()) { appMessage.value = "Solo administrador"; return false }
        if (name.trim().length < 3 || price <= 0 || cost < 0 || stock < 0) {
            appMessage.value = "Revisa los datos"
            return false
        }

        val id = (products.maxOfOrNull { it.id } ?: 0) + 1
        val safePhotos = copyProductImagesToAppStorage(photo)
        products.add(Product(id, name.trim(), category.ifBlank { "General" }, internalCode.trim(), barcode.trim(), cost, price, stock, safePhotos))
        saveAll()
        appMessage.value = "Producto guardado"
        return true
    }

    fun filteredProducts(query: String): List<Product> {
        val q = query.trim().lowercase()
        if (q.isBlank()) return products

        return products.filter {
            it.name.lowercase().contains(q) ||
            it.category.lowercase().contains(q) ||
            it.internalCode.lowercase().contains(q) ||
            it.barcode.lowercase().contains(q)
        }
    }


    fun updateProduct(id: Int, name: String, category: String, internalCode: String, barcode: String, cost: Double, price: Double, stock: Int, photo: String): Boolean {
        if (!isAdmin()) { appMessage.value = "Solo administrador"; return false }
        if (name.trim().length < 3 || price <= 0 || cost < 0 || stock < 0) { appMessage.value = "Revisa los datos"; return false }
        val i = products.indexOfFirst { it.id == id }
        if (i < 0) { appMessage.value = "Producto no encontrado"; return false }
        val safePhotos = copyProductImagesToAppStorage(photo)
        products[i] = products[i].copy(name = name.trim(), category = category.ifBlank { "General" }, internalCode = internalCode.trim(), barcode = barcode.trim(), realCost = cost, salePrice = price, stock = stock, photoUri = safePhotos)
        saveAll()
        appMessage.value = "Producto actualizado"
        return true
    }

    fun adjustStock(product: Product, amount: Int): Boolean {
        if (!isAdmin()) { appMessage.value = "Solo administrador"; return false }
        val i = products.indexOfFirst { it.id == product.id }
        if (i < 0) return false
        products[i] = products[i].copy(stock = (products[i].stock + amount).coerceAtLeast(0))
        saveAll()
        appMessage.value = "Stock actualizado"
        return true
    }

    fun deleteProduct(product: Product): Boolean {
        if (!isAdmin()) { appMessage.value = "Solo administrador"; return false }
        products.removeAll { it.id == product.id }
        saveAll()
        appMessage.value = "Producto eliminado"
        return true
    }

    fun registerSale(product: Product, seller: SellerType): Boolean {
        if (product.stock <= 0) { appMessage.value = "No hay stock"; return false }

        val current = currentUser.value
        val type = if (isWorker()) SellerType.WORKER else seller
        val commission = if (type == SellerType.WORKER) 5000.0 else 0.0
        val sellerName = when {
            isWorker() -> current?.displayName ?: "Trabajador"
            type == SellerType.WORKER -> "Trabajador"
            else -> current?.displayName ?: "Administrador"
        }
        val sellerUser = when {
            isWorker() -> current?.username ?: "trabajador"
            type == SellerType.WORKER -> "trabajador"
            else -> current?.username ?: "admin"
        }

        sales.add(
            Sale(
                id = (sales.maxOfOrNull { it.id } ?: 0) + 1,
                productName = product.name,
                price = product.salePrice,
                realCost = product.realCost,
                sellerType = type,
                sellerDisplayName = sellerName,
                sellerUsername = sellerUser,
                commission = commission,
                commissionPaid = false,
                profit = product.salePrice - product.realCost - commission,
                date = now()
            )
        )

        val i = products.indexOfFirst { it.id == product.id }
        if (i >= 0) products[i] = products[i].copy(stock = (products[i].stock - 1).coerceAtLeast(0))

        saveAll()
        appMessage.value = "Venta registrada"
        return true
    }

    fun payCommission(workerUsername: String): Boolean {
        if (!isAdmin()) return false

        val pending = sales.filter {
            it.sellerUsername == workerUsername && it.sellerType == SellerType.WORKER && !it.commissionPaid
        }

        if (pending.isEmpty()) {
            appMessage.value = "Sin comisión pendiente"
            return false
        }

        pending.forEach { sale ->
            val i = sales.indexOfFirst { it.id == sale.id }
            if (i >= 0) sales[i] = sales[i].copy(commissionPaid = true)
        }

        saveAll()
        appMessage.value = "Comisión pagada"
        return true
    }

    fun commissionUsers(): List<String> =
        sales.filter { it.sellerType == SellerType.WORKER && !it.commissionPaid }
            .map { it.sellerUsername }
            .distinct()

    fun commissionAmount(username: String): Double =
        sales.filter { it.sellerUsername == username && it.sellerType == SellerType.WORKER && !it.commissionPaid }
            .sumOf { it.commission }

    fun commissionSales(username: String): Int =
        sales.count { it.sellerUsername == username && it.sellerType == SellerType.WORKER && !it.commissionPaid }

    fun sellerName(username: String): String =
        sales.firstOrNull { it.sellerUsername == username }?.sellerDisplayName ?: username


    fun copyProductImagesToAppStorage(photoText: String): String {
        val uris = photoText.split(";;").filter { it.isNotBlank() }
        if (uris.isEmpty()) return ""

        val productDir = File(context.filesDir, "products")
        if (!productDir.exists()) productDir.mkdirs()

        val saved = mutableListOf<String>()

        uris.forEachIndexed { index, raw ->
            try {
                if (raw.startsWith("file:") || raw.startsWith(context.filesDir.absolutePath)) {
                    saved.add(raw)
                } else {
                    val uri = Uri.parse(raw)
                    val name = "product_${System.currentTimeMillis()}_${index}.jpg"
                    val outFile = File(productDir, name)

                    context.contentResolver.openInputStream(uri)?.use { input ->
                        FileOutputStream(outFile).use { output ->
                            input.copyTo(output)
                        }
                    }

                    if (outFile.exists() && outFile.length() > 0L) {
                        saved.add(outFile.absolutePath)
                    }
                }
            } catch (_: Exception) {
                // Si una imagen falla, no bloquea el guardado del producto.
            }
        }

        return saved.joinToString(";;")
    }

    fun createLocalBackup(): String {
        val publicDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Nexo Manager")
        val backupDir = if (publicDir.exists() || publicDir.mkdirs()) {
            publicDir
        } else {
            File(context.filesDir, "backups").apply { if (!exists()) mkdirs() }
        }

        val file = File(backupDir, "nexo_manager_backup_${System.currentTimeMillis()}.txt")
        val content = buildString {
            appendLine("NEXO MANAGER BACKUP")
            appendLine("Fecha: ${java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault()).format(java.util.Date())}")
            appendLine()
            appendLine("PRODUCTOS")
            products.forEach {
                appendLine("${it.id}|${it.name}|${it.category}|${it.internalCode}|${it.barcode}|${it.realCost}|${it.salePrice}|${it.stock}|${it.photoUri}")
            }
            appendLine()
            appendLine("VENTAS")
            sales.forEach {
                appendLine("${it.id}|${it.productName}|${it.price}|${it.realCost}|${it.sellerDisplayName}|${it.commission}|${it.profit}|${it.date}")
            }
            appendLine()
            appendLine("USUARIOS")
            users.forEach {
                appendLine("${it.username}|${it.displayName}|${it.role}|${it.active}")
            }
        }

        file.writeText(content)
        appMessage.value = "Respaldo creado en Descargas/Nexo Manager: ${file.name}"
        return file.absolutePath
    }

    fun shareLatestBackup() {
        val publicDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Nexo Manager")
        val internalDir = File(context.filesDir, "backups")
        val latest = listOf(publicDir, internalDir)
            .filter { it.exists() }
            .flatMap { it.listFiles()?.toList() ?: emptyList() }
            .filter { it.name.endsWith(".txt") && it.name.startsWith("nexo_manager_backup_") }
            .maxByOrNull { it.lastModified() }

        if (latest == null) {
            appMessage.value = "Primero crea un respaldo"
            return
        }

        try {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", latest)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, "Respaldo Nexo Manager: ${latest.name}")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val chooser = Intent.createChooser(intent, "Compartir respaldo")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
        } catch (_: Exception) {
            appMessage.value = "No se pudo compartir el respaldo"
        }
    }

    fun restoreBackupFromText(text: String): Boolean {
        try {
            val newProducts = mutableListOf<Product>()
            val newSales = mutableListOf<Sale>()
            val newUsers = mutableListOf<AppUser>()

            var section = ""

            text.lines().forEach { rawLine ->
                val line = rawLine.trim()
                if (line.isBlank()) return@forEach

                when (line) {
                    "PRODUCTOS" -> { section = "PRODUCTOS"; return@forEach }
                    "VENTAS" -> { section = "VENTAS"; return@forEach }
                    "USUARIOS" -> { section = "USUARIOS"; return@forEach }
                }

                if (line.startsWith("NEXO MANAGER BACKUP") || line.startsWith("Fecha:")) return@forEach

                val a = line.split("|")
                when (section) {
                    "PRODUCTOS" -> {
                        if (a.size >= 9) {
                            newProducts.add(
                                Product(
                                    id = a[0].toIntOrNull() ?: ((newProducts.maxOfOrNull { it.id } ?: 0) + 1),
                                    name = a[1],
                                    category = a[2],
                                    internalCode = a[3],
                                    barcode = a[4],
                                    realCost = a[5].toDoubleOrNull() ?: 0.0,
                                    salePrice = a[6].toDoubleOrNull() ?: 0.0,
                                    stock = a[7].toIntOrNull() ?: 0,
                                    photoUri = a[8]
                                )
                            )
                        }
                    }
                    "VENTAS" -> {
                        if (a.size >= 8) {
                            newSales.add(
                                Sale(
                                    id = a[0].toIntOrNull() ?: ((newSales.maxOfOrNull { it.id } ?: 0) + 1),
                                    productName = a[1],
                                    price = a[2].toDoubleOrNull() ?: 0.0,
                                    realCost = a[3].toDoubleOrNull() ?: 0.0,
                                    sellerType = SellerType.WORKER,
                                    sellerDisplayName = a[4],
                                    sellerUsername = a[4].lowercase().replace(" ", "_"),
                                    commission = a[5].toDoubleOrNull() ?: 0.0,
                                    commissionPaid = false,
                                    profit = a[6].toDoubleOrNull() ?: 0.0,
                                    date = a[7]
                                )
                            )
                        }
                    }
                    "USUARIOS" -> {
                        if (a.size >= 4) {
                            val role = try { UserRole.valueOf(a[2]) } catch (_: Exception) { UserRole.WORKER }
                            newUsers.add(
                                AppUser(
                                    username = a[0],
                                    displayName = a[1],
                                    password = if (a[0] == "admin") "1234" else "1234",
                                    role = role,
                                    active = a[3].toBooleanStrictOrNull() ?: true
                                )
                            )
                        }
                    }
                }
            }

            if (newProducts.isEmpty() && newSales.isEmpty() && newUsers.isEmpty()) {
                appMessage.value = "El respaldo no tiene datos válidos"
                return false
            }

            createAutomaticSmartBackup("Antes de restaurar respaldo")

            products.clear()
            products.addAll(newProducts)

            sales.clear()
            sales.addAll(newSales)

            users.clear()
            if (newUsers.none { it.username == "admin" }) {
                users.add(AppUser("admin", "Administrador", "1234", UserRole.ADMIN, true))
            }
            users.addAll(newUsers.distinctBy { it.username })

            saveAll()
            appMessage.value = "Respaldo restaurado correctamente"
            return true
        } catch (_: Exception) {
            appMessage.value = "No se pudo restaurar el respaldo"
            return false
        }
    }

    fun restoreBackupFromInputStream(inputStream: InputStream): Boolean {
        val text = inputStream.bufferedReader().use { it.readText() }
        return restoreBackupFromText(text)
    }


    private fun backupDataText(): String {
        return buildString {
            appendLine("NEXO MANAGER SMART BACKUP")
            appendLine("VERSION|2.5.0")
            appendLine("Fecha|${java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault()).format(java.util.Date())}")
            appendLine()
            appendLine("PRODUCTOS")
            products.forEach {
                appendLine("${it.id}|${it.name}|${it.category}|${it.internalCode}|${it.barcode}|${it.realCost}|${it.salePrice}|${it.stock}|${it.photoUri}|${it.minStock}")
            }
            appendLine()
            appendLine("VENTAS")
            sales.forEach {
                appendLine("${it.id}|${it.productName}|${it.price}|${it.realCost}|${it.sellerType}|${it.sellerDisplayName}|${it.sellerUsername}|${it.commission}|${it.commissionPaid}|${it.profit}|${it.date}")
            }
            appendLine()
            appendLine("USUARIOS")
            users.forEach {
                appendLine("${it.username}|${it.displayName}|${it.password}|${it.role}|${it.active}")
            }
        }
    }


    private fun createAutomaticSmartBackup(reason: String = "Guardado automático") {
        try {
            val baseDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Nexo Manager/Automaticos")
            val backupDir = if (baseDir.exists() || baseDir.mkdirs()) {
                baseDir
            } else {
                File(context.filesDir, "auto_backups").apply { if (!exists()) mkdirs() }
            }

            val file = File(backupDir, "Auto_NexoManager_${System.currentTimeMillis()}.nmb")

            ZipOutputStream(FileOutputStream(file)).use { zip ->
                zip.putNextEntry(ZipEntry("respaldo.txt"))
                val content = buildString {
                    appendLine("NEXO MANAGER SMART BACKUP")
                    appendLine("VERSION|3.0.0")
                    appendLine("MOTIVO|$reason")
                    appendLine("Fecha|${java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault()).format(java.util.Date())}")
                    appendLine()
                    appendLine("PRODUCTOS")
                    products.forEach {
                        appendLine("${it.id}|${it.name}|${it.category}|${it.internalCode}|${it.barcode}|${it.realCost}|${it.salePrice}|${it.stock}|${it.photoUri}|${it.minStock}")
                    }
                    appendLine()
                    appendLine("VENTAS")
                    sales.forEach {
                        appendLine("${it.id}|${it.productName}|${it.price}|${it.realCost}|${it.sellerType}|${it.sellerDisplayName}|${it.sellerUsername}|${it.commission}|${it.commissionPaid}|${it.profit}|${it.date}")
                    }
                    appendLine()
                    appendLine("USUARIOS")
                    users.forEach {
                        appendLine("${it.username}|${it.displayName}|${it.password}|${it.role}|${it.active}")
                    }
                }
                zip.write(content.toByteArray(Charsets.UTF_8))
                zip.closeEntry()

                val added = mutableSetOf<String>()
                products.forEach { product ->
                    product.photoUri.split(";;").filter { it.isNotBlank() }.forEach { raw ->
                        try {
                            val imageFile = when {
                                raw.startsWith("file:") -> File(Uri.parse(raw).path ?: "")
                                raw.startsWith("content://") -> null
                                else -> File(raw)
                            }

                            if (imageFile != null && imageFile.exists() && imageFile.isFile && added.add(imageFile.absolutePath)) {
                                zip.putNextEntry(ZipEntry("fotos/${imageFile.name}"))
                                FileInputStream(imageFile).use { input -> input.copyTo(zip) }
                                zip.closeEntry()
                            }
                        } catch (_: Exception) {}
                    }
                }
            }

            val backups = backupDir.listFiles()
                ?.filter { it.name.startsWith("Auto_NexoManager_") && it.name.endsWith(".nmb") }
                ?.sortedByDescending { it.lastModified() }
                ?: emptyList()

            backups.drop(10).forEach { old -> try { old.delete() } catch (_: Exception) {} }
        } catch (_: Exception) {
            // El respaldo automático nunca debe bloquear la app.
        }
    }

    fun createSmartBackup(): String {
        try {
            val publicDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Nexo Manager")
            val backupDir = if (publicDir.exists() || publicDir.mkdirs()) {
                publicDir
            } else {
                File(context.filesDir, "backups").apply { if (!exists()) mkdirs() }
            }

            val file = File(backupDir, "NexoManager_Backup_${System.currentTimeMillis()}.nmb")

            ZipOutputStream(FileOutputStream(file)).use { zip ->
                zip.putNextEntry(ZipEntry("respaldo.txt"))
                zip.write(backupDataText().toByteArray(Charsets.UTF_8))
                zip.closeEntry()

                val added = mutableSetOf<String>()
                products.forEach { product ->
                    product.photoUri.split(";;").filter { it.isNotBlank() }.forEach { raw ->
                        try {
                            val imageFile = when {
                                raw.startsWith("file:") -> File(Uri.parse(raw).path ?: "")
                                raw.startsWith("content://") -> null
                                else -> File(raw)
                            }

                            if (imageFile != null && imageFile.exists() && imageFile.isFile && added.add(imageFile.absolutePath)) {
                                zip.putNextEntry(ZipEntry("fotos/${imageFile.name}"))
                                FileInputStream(imageFile).use { input -> input.copyTo(zip) }
                                zip.closeEntry()
                            }
                        } catch (_: Exception) {}
                    }
                }
            }

            appMessage.value = "Respaldo inteligente creado: ${file.name}"
            return file.absolutePath
        } catch (_: Exception) {
            appMessage.value = "No se pudo crear respaldo inteligente"
            return ""
        }
    }

    fun shareLatestSmartBackup() {
        val publicDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "Nexo Manager")
        val internalDir = File(context.filesDir, "backups")
        val latest = listOf(publicDir, internalDir)
            .filter { it.exists() }
            .flatMap { it.listFiles()?.toList() ?: emptyList() }
            .filter { it.name.endsWith(".nmb") && it.name.startsWith("NexoManager_Backup_") }
            .maxByOrNull { it.lastModified() }

        if (latest == null) {
            appMessage.value = "Primero crea respaldo inteligente"
            return
        }

        try {
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", latest)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/zip"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, "Respaldo inteligente Nexo Manager: ${latest.name}")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val chooser = Intent.createChooser(intent, "Compartir respaldo inteligente")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
        } catch (_: Exception) {
            appMessage.value = "No se pudo compartir respaldo inteligente"
        }
    }

    fun restoreSmartBackupFromInputStream(inputStream: InputStream): Boolean {
        return try {
            val tempFile = File(context.cacheDir, "restore_${System.currentTimeMillis()}.nmb")
            FileOutputStream(tempFile).use { output -> inputStream.copyTo(output) }

            val productDir = File(context.filesDir, "products")
            if (!productDir.exists()) productDir.mkdirs()

            var respaldoText = ""

            ZipFile(tempFile).use { zip ->
                val entries = zip.entries()
                while (entries.hasMoreElements()) {
                    val entry = entries.nextElement()
                    if (entry.name == "respaldo.txt") {
                        respaldoText = zip.getInputStream(entry).bufferedReader().use { it.readText() }
                    } else if (entry.name.startsWith("fotos/") && !entry.isDirectory) {
                        val outFile = File(productDir, File(entry.name).name)
                        zip.getInputStream(entry).use { input ->
                            FileOutputStream(outFile).use { output -> input.copyTo(output) }
                        }
                    }
                }
            }

            if (respaldoText.isBlank()) {
                appMessage.value = "Respaldo inteligente inválido"
                false
            } else {
                restoreBackupFromText(respaldoText)
            }
        } catch (_: Exception) {
            appMessage.value = "No se pudo restaurar respaldo inteligente"
            false
        }
    }

    fun productAvailabilityText(product: Product): String {
        return when {
            product.stock <= 0 -> "Agotado por el momento"
            product.stock <= 1 -> "Última unidad disponible"
            else -> "Disponible para entrega inmediata"
        }
    }


    private fun loadShareSettings(): ShareSettings {
        return ShareSettings(
            storeName = prefs.getString("share_store_name", "Nexo Moda") ?: "Nexo Moda",
            whatsappNumber = prefs.getString("share_whatsapp", "573052154226") ?: "573052154226",
            shippingText = prefs.getString("share_shipping", "Envíos a todo Colombia.") ?: "Envíos a todo Colombia.",
            trustText = prefs.getString("share_trust", "Compra con confianza. Atención personalizada y garantía en cada pedido.") ?: "Compra con confianza. Atención personalizada y garantía en cada pedido.",
            showPrice = prefs.getBoolean("share_show_price", true),
            showAvailability = prefs.getBoolean("share_show_availability", true),
            includeWhatsappLink = prefs.getBoolean("share_include_link", true),
            shareImage = prefs.getBoolean("share_image", true)
        )
    }

    fun updateShareSettings(
        storeName: String,
        whatsappNumber: String,
        shippingText: String,
        trustText: String,
        showPrice: Boolean,
        showAvailability: Boolean,
        includeWhatsappLink: Boolean,
        shareImage: Boolean
    ) {
        val clean = ShareSettings(
            storeName = storeName.ifBlank { "Nexo Moda" },
            whatsappNumber = whatsappNumber.filter { it.isDigit() }.ifBlank { "573052154226" },
            shippingText = shippingText.ifBlank { "Envíos a todo Colombia." },
            trustText = trustText.ifBlank { "Compra con confianza. Atención personalizada y garantía en cada pedido." },
            showPrice = showPrice,
            showAvailability = showAvailability,
            includeWhatsappLink = includeWhatsappLink,
            shareImage = shareImage
        )
        prefs.edit()
            .putString("share_store_name", clean.storeName)
            .putString("share_whatsapp", clean.whatsappNumber)
            .putString("share_shipping", clean.shippingText)
            .putString("share_trust", clean.trustText)
            .putBoolean("share_show_price", clean.showPrice)
            .putBoolean("share_show_availability", clean.showAvailability)
            .putBoolean("share_include_link", clean.includeWhatsappLink)
            .putBoolean("share_image", clean.shareImage)
            .apply()
        shareSettings.value = clean
        appMessage.value = "Configuración de mensaje guardada"
    }

    fun previewShareMessage(product: Product? = products.firstOrNull()): String {
        return product?.let { whatsappMessage(it) } ?: "Agrega un producto para ver la vista previa."
    }

    private fun productOrderLink(product: Product): String {
        val settings = shareSettings.value
        val cleanName = product.name.trim()
        val text = URLEncoder.encode("Hola, me interesa $cleanName. ¿Sigue disponible?", "UTF-8")
        return "https://wa.me/${settings.whatsappNumber}?text=$text"
    }

    fun whatsappMessage(product: Product): String {
        val settings = shareSettings.value
        return buildString {
            appendLine("✨ ${settings.storeName}")
            appendLine()
            appendLine("🛍 ${product.name}")
            appendLine()
            if (settings.showPrice) {
                appendLine("💰 ${cop(product.salePrice)}")
                appendLine()
            }
            if (settings.showAvailability) {
                appendLine("📦 ${productAvailabilityText(product)}")
                appendLine()
            }
            appendLine("🚚 ${settings.shippingText}")
            appendLine()
            if (settings.includeWhatsappLink) {
                appendLine("📲 Pedir este producto:")
                appendLine(productOrderLink(product))
                appendLine()
            } else {
                appendLine("📲 Escríbenos para realizar tu pedido.")
                appendLine()
            }
            appendLine("🛡 ${settings.trustText}")
        }.trim()
    }

    fun whatsappOfferMessage(product: Product): String {
        val settings = shareSettings.value
        val urgency = when {
            product.stock <= 0 -> "Producto agotado por el momento"
            product.stock <= 1 -> "¡Última unidad disponible!"
            else -> "Disponible para entrega inmediata"
        }

        return buildString {
            appendLine("🔥 OFERTA ESPECIAL 🔥")
            appendLine()
            appendLine("✨ ${settings.storeName}")
            appendLine()
            appendLine("🛍 ${product.name}")
            appendLine()
            if (settings.showPrice) {
                appendLine("💰 Solo ${cop(product.salePrice)}")
                appendLine()
            }
            if (settings.showAvailability) {
                appendLine("📦 $urgency")
                appendLine()
            }
            appendLine("🚚 ${settings.shippingText}")
            appendLine()
            if (settings.includeWhatsappLink) {
                appendLine("📲 Pedir este producto:")
                appendLine(productOrderLink(product))
                appendLine()
            } else {
                appendLine("📲 Escríbenos para realizar tu pedido.")
                appendLine()
            }
            appendLine("🛡 ${settings.trustText}")
        }.trim()
    }

    fun shareProduct(product: Product) {
        shareProductWithMessage(product, whatsappMessage(product))
    }

    fun shareProductOffer(product: Product) {
        shareProductWithMessage(product, whatsappOfferMessage(product))
    }

    fun copyProductText(product: Product) {
        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("Producto Nexo Moda", whatsappMessage(product)))
        appMessage.value = "Texto copiado"
    }

    private fun productImageUriForShare(raw: String): Uri? {
        return try {
            when {
                raw.startsWith("content://") -> Uri.parse(raw)
                raw.startsWith("file:") -> {
                    val file = File(Uri.parse(raw).path ?: return null)
                    if (!file.exists()) null else FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
                }
                else -> {
                    val file = File(raw)
                    if (!file.exists()) null else FileProvider.getUriForFile(context, "${context.packageName}.provider", file)
                }
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun shareProductWithMessage(product: Product, message: String) {
        val firstPhoto = if (shareSettings.value.shareImage) product.photoUri.split(";;").firstOrNull { it.isNotBlank() } else null
        val imageUri = firstPhoto?.let { productImageUriForShare(it) }

        if (imageUri != null) {
            val imageIntent = Intent(Intent.ACTION_SEND).apply {
                type = "image/*"
                putExtra(Intent.EXTRA_STREAM, imageUri)
                putExtra(Intent.EXTRA_TEXT, message)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                clipData = ClipData.newUri(context.contentResolver, "Foto producto Nexo Moda", imageUri)
                setPackage("com.whatsapp")
            }

            try {
                context.startActivity(imageIntent)
                appMessage.value = "Compartiendo foto del producto"
                return
            } catch (_: Exception) {
                try {
                    val noPackage = Intent(Intent.ACTION_SEND).apply {
                        type = "image/*"
                        putExtra(Intent.EXTRA_STREAM, imageUri)
                        putExtra(Intent.EXTRA_TEXT, message)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        clipData = ClipData.newUri(context.contentResolver, "Foto producto Nexo Moda", imageUri)
                    }
                    val chooser = Intent.createChooser(noPackage, "Compartir producto con foto")
                    chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(chooser)
                    return
                } catch (_: Exception) {
                    // Sigue al respaldo de texto.
                }
            }
        }

        val textIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, message)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            setPackage("com.whatsapp")
        }

        try {
            context.startActivity(textIntent)
            appMessage.value = "Compartiendo solo texto: no se pudo adjuntar foto"
        } catch (_: Exception) {
            val fallback = Intent.createChooser(textIntent.apply { setPackage(null) }, "Compartir producto")
            fallback.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(fallback)
        }
    }

    fun totalSales(): Double = sales.sumOf { it.price }
    fun totalProfit(): Double = sales.sumOf { it.profit }
    fun totalStock(): Int = products.sumOf { it.stock }
    fun investedCapital(): Double = products.sumOf { it.realCost * it.stock }
    fun recoveredCapital(): Double = sales.sumOf { it.realCost }
    fun workerCommissions(): Double = sales.filter { !it.commissionPaid }.sumOf { it.commission }
    fun soldOutProducts(): List<Product> = products.filter { it.stock <= 0 }
    fun lowStockProducts(): List<Product> = products.filter { it.stock in 1..it.minStock }

    private fun cop(value: Double): String = "$" + "%,.0f".format(value).replace(",", ".") + " COP"

    private fun cleanStorageValue(value: String): String {
        return value.replace("|", " ").replace("\n", " ").replace("\r", " ").trim()
    }

    private fun saveAll() {
        val saved = prefs.edit()
            .putString("products", products.joinToString("\n") {
                listOf(
                    it.id,
                    cleanStorageValue(it.name),
                    cleanStorageValue(it.category),
                    cleanStorageValue(it.internalCode),
                    cleanStorageValue(it.barcode),
                    it.realCost,
                    it.salePrice,
                    it.stock,
                    cleanStorageValue(it.photoUri),
                    it.minStock
                ).joinToString("|")
            })
            .putString("sales", sales.joinToString("\n") {
                listOf(
                    it.id,
                    cleanStorageValue(it.productName),
                    it.price,
                    it.realCost,
                    it.sellerType.name,
                    cleanStorageValue(it.sellerDisplayName),
                    cleanStorageValue(it.sellerUsername),
                    it.commission,
                    it.commissionPaid,
                    it.profit,
                    cleanStorageValue(it.date)
                ).joinToString("|")
            })
            .putString("users", users.joinToString("\n") {
                listOf(
                    cleanStorageValue(it.username),
                    cleanStorageValue(it.displayName),
                    cleanStorageValue(it.password),
                    it.role.name,
                    it.active
                ).joinToString("|")
            })
            .putLong("last_save_time", System.currentTimeMillis())
            .commit()

        if (saved && autoBackupEnabled) {
            createAutomaticSmartBackup("Guardado automático")
        }

        if (!saved) {
            appMessage.value = "No se pudo guardar en almacenamiento"
        }
    }

    private fun loadAll() {
        products.clear()
        sales.clear()
        users.clear()

        val savedProducts = prefs.getString("products", "") ?: ""
        savedProducts.lines().filter { it.isNotBlank() }.forEach {
            val a = it.split("|")
            try {
                if (a.size >= 8) {
                    products.add(
                        Product(
                            id = a[0].toInt(),
                            name = a[1],
                            category = a[2],
                            internalCode = a.getOrNull(3) ?: "",
                            barcode = a.getOrNull(4) ?: "",
                            realCost = a.getOrNull(5)?.toDoubleOrNull() ?: 0.0,
                            salePrice = a.getOrNull(6)?.toDoubleOrNull() ?: 0.0,
                            stock = a.getOrNull(7)?.toIntOrNull() ?: 0,
                            photoUri = a.getOrNull(8) ?: "",
                            minStock = a.getOrNull(9)?.toIntOrNull() ?: 1
                        )
                    )
                }
            } catch (_: Exception) {}
        }

        val savedSales = prefs.getString("sales", "") ?: ""
        savedSales.lines().filter { it.isNotBlank() }.forEach {
            val a = it.split("|")
            try {
                if (a.size >= 10) {
                    sales.add(
                        Sale(
                            id = a[0].toInt(),
                            productName = a[1],
                            price = a[2].toDoubleOrNull() ?: 0.0,
                            realCost = a[3].toDoubleOrNull() ?: 0.0,
                            sellerType = try { SellerType.valueOf(a[4]) } catch (_: Exception) { SellerType.WORKER },
                            sellerDisplayName = a.getOrNull(5) ?: "Trabajador",
                            sellerUsername = a.getOrNull(6) ?: "trabajador",
                            commission = a.getOrNull(7)?.toDoubleOrNull() ?: 0.0,
                            commissionPaid = a.getOrNull(8)?.toBoolean() ?: false,
                            profit = a.getOrNull(9)?.toDoubleOrNull() ?: 0.0,
                            date = a.getOrNull(10) ?: ""
                        )
                    )
                }
            } catch (_: Exception) {}
        }

        val savedUsers = prefs.getString("users", "") ?: ""
        savedUsers.lines().filter { it.isNotBlank() }.forEach {
            val a = it.split("|")
            try {
                if (a.size >= 5) {
                    val role = try { UserRole.valueOf(a[3]) } catch (_: Exception) { UserRole.WORKER }
                    users.add(AppUser(a[0], a[1], a[2], role, a[4].toBoolean()))
                }
            } catch (_: Exception) {}
        }

        val adminIndex = users.indexOfFirst { it.username.equals("admin", ignoreCase = true) }
        if (adminIndex >= 0 && users[adminIndex].role != UserRole.ADMIN) {
            users[adminIndex] = users[adminIndex].copy(role = UserRole.ADMIN, displayName = "Administrador", active = true)
        }
    }

}
