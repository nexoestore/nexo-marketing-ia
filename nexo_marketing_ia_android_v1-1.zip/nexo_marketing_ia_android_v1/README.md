# Nexo Marketing IA Android V1

App Android real con React Native + Expo.

## Funciones
- Dashboard diario
- Biblioteca de copys
- Botón copiar
- Gestor de grupos
- Abrir enlaces de grupos
- CRM de prospectos
- Abrir WhatsApp
- Respuestas rápidas
- Guardado local con AsyncStorage

## Probar
```bash
npm install
npx expo start
```

## Crear APK
```bash
npm install -g eas-cli
eas login
eas build -p android --profile preview
```
